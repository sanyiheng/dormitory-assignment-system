package com.dormitory.management.service.impl;

import com.dormitory.management.common.Constants;
import com.dormitory.management.entity.*;
import com.dormitory.management.exception.BusinessException;
import com.dormitory.management.mapper.*;
import com.dormitory.management.service.AssignmentService;
import com.dormitory.management.vo.AssignmentResultVO;
import com.mybatisflex.core.query.QueryWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.dormitory.management.entity.table.DormAssignTableDef.DORM_ASSIGN;
import static com.dormitory.management.entity.table.DormitoryTableDef.DORMITORY;
import static com.dormitory.management.entity.table.StudentQuestionnaireTableDef.STUDENT_QUESTIONNAIRE;
import static com.dormitory.management.entity.table.StudentTableDef.STUDENT;
import static com.dormitory.management.entity.table.SystemConfigTableDef.SYSTEM_CONFIG;

/**
 * 宿舍分配服务实现类
 *
 * 核心算法：冲突规避矩阵 + 约束满足问题（CSP）
 *
 * 核心思想：
 * 1. 不追求"找到最合拍的人"，而是"强力排除最不能忍受的雷点"
 * 2. 将"完全不能忍受"设为硬约束（Hard Constraint）
 * 3. 使用贪心+回溯的启发式搜索进行分配
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AssignmentServiceImpl implements AssignmentService {

    private final StudentMapper studentMapper;
    private final DormitoryMapper dormitoryMapper;
    private final DormAssignMapper dormAssignMapper;
    private final StudentQuestionnaireMapper studentQuestionnaireMapper;
    private final BuildingMapper buildingMapper;
    private final SystemConfigMapper systemConfigMapper;

    /**
     * 宿舍容量
     */
    private static final int ROOM_CAPACITY = 6;

    /**
     * 执行自动分配
     * @return 成功分配的学生数量
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int executeAssignment() {
        // 检查分配算法开关
        SystemConfig config = systemConfigMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(SYSTEM_CONFIG.CONFIG_KEY.eq("ASSIGN_SWITCH"))
        );
        if (config != null && "OFF".equals(config.getConfigValue())) {
            throw new BusinessException("分配功能暂未开放");
        }

        log.info("========== 开始执行宿舍智能分配 ==========");

        // 1. 获取所有已填问卷且未删除的学生
        List<Student> allStudents = getStudentsWhoSubmittedQuestionnaire();

        if (allStudents.isEmpty()) {
            throw new BusinessException("没有已填写问卷的学生");
        }

        log.info("符合条件的学生总数：{}", allStudents.size());

        // 2. 获取所有可用宿舍（状态正常且未满）
        List<Dormitory> availableDormitories = getAvailableDormitories();

        if (availableDormitories.isEmpty()) {
            throw new BusinessException("没有可用宿舍");
        }

        log.info("可用宿舍数量：{}", availableDormitories.size());

        // 3. 按专业分组（同专业才能分同一宿舍）
        Map<String, List<Student>> studentsByMajor = allStudents.stream()
                .collect(Collectors.groupingBy(s ->
                        s.getMajor() != null ? s.getMajor() : "未知专业"));

        int totalAssigned = 0;

        // 4. 对每个专业的学生进行分配
        for (Map.Entry<String, List<Student>> entry : studentsByMajor.entrySet()) {
            String major = entry.getKey();
            List<Student> students = entry.getValue();

            // 按性别分组（男女分开）
            Map<Integer, List<Student>> studentsByGender = students.stream()
                    .collect(Collectors.groupingBy(s ->
                            s.getGender() != null ? s.getGender() : Constants.GENDER_MALE));

            for (Map.Entry<Integer, List<Student>> genderEntry : studentsByGender.entrySet()) {
                Integer gender = genderEntry.getKey();
                List<Student> genderStudents = genderEntry.getValue();

                // 按班级排序（尽量同班级分一起）
                genderStudents.sort(Comparator.comparing(
                        s -> s.getClassName() != null ? s.getClassName() : ""));

                log.info("处理专业={}, 性别={}, 学生数={}", major,
                        gender == Constants.GENDER_MALE ? "男" : "女", genderStudents.size());

                // 过滤该性别可用的宿舍
                List<Dormitory> genderDormitories = availableDormitories.stream()
                        .filter(d -> {
                            Building building = buildingMapper.selectOneById(d.getBuildingId());
                            return building != null && building.getGenderType() == gender;
                        })
                        .collect(Collectors.toList());

                // 执行分组分配
                totalAssigned += assignStudentsToDormitories(genderStudents, genderDormitories);
            }
        }

        log.info("========== 分配完成，共分配 {} 名学生 ==========", totalAssigned);
        return totalAssigned;
    }

    /**
     * 将学生分配到宿舍
     * 使用贪心+回溯的CSP算法
     */
    private int assignStudentsToDormitories(List<Student> students, List<Dormitory> dormitories) {
        int assignedCount = 0;

        for (Dormitory dormitory : dormitories) {
            // 计算该宿舍还能住多少人
            int availableBeds = dormitory.getCapacity() - dormitory.getOccupied();
            if (availableBeds <= 0) {
                continue;
            }

            // 如果学生已经全部分配完，退出
            if (students.isEmpty()) {
                break;
            }

            // 获取当前宿舍已入住学生的问卷答案
            List<Long> currentRoommateIds = getCurrentRoommates(dormitory.getId());

            // 如果宿舍满了，跳过
            if (currentRoommateIds.size() >= ROOM_CAPACITY) {
                continue;
            }

            // 选择能住进这个宿舍的学生
            List<Student> selectedStudents = selectCompatibleStudents(
                    students, currentRoommateIds, ROOM_CAPACITY - currentRoommateIds.size());

            // 分配宿舍
            for (Student student : selectedStudents) {
                DormAssign assign = new DormAssign();
                assign.setStudentId(student.getId());
                assign.setDormitoryId(dormitory.getId());
                assign.setBedNo(String.valueOf(currentRoommateIds.size() + 1));
                assign.setCheckInDate(LocalDate.now());
                assign.setStatus(Constants.ASSIGN_STATUS_LIVING);
                assign.setAssignType(Constants.ASSIGN_TYPE_AUTO);
                dormAssignMapper.insert(assign);

                // 更新宿舍已住人数
                dormitory.setOccupied(dormitory.getOccupied() + 1);
                dormitoryMapper.update(dormitory);

                currentRoommateIds.add(student.getId());
                assignedCount++;
                log.info("学生 {} ({}) 分配到宿舍 {}-{}",
                        student.getName(), student.getStudentNo(),
                        dormitory.getRoomNo(), dormitory.getFloor());
            }

            // 从待分配列表中移除已分配的学生
            students.removeAll(selectedStudents);
        }

        return assignedCount;
    }

    /**
     * 选择兼容的学生（核心CSP算法）
     *
     * 硬约束：不能有"完全不能忍受"的冲突
     * 软约束：尽量同班级、尽量习惯相近
     */
    private List<Student> selectCompatibleStudents(List<Student> candidates,
                                                   List<Long> currentRoommateIds,
                                                   int maxCount) {
        List<Student> selected = new ArrayList<>();

        // 获取当前室友的问卷答案
        Map<Long, Map<Long, Long>> roommateAnswers = new HashMap<>();
        for (Long roommateId : currentRoommateIds) {
            roommateAnswers.put(roommateId, getStudentAnswers(roommateId));
        }

        // 遍历候选学生
        for (Student candidate : candidates) {
            if (selected.size() >= maxCount) {
                break;
            }

            Map<Long, Long> candidateAnswers = getStudentAnswers(candidate.getId());

            // 检查硬约束
            boolean hasHardConflict = false;
            for (Map<Long, Long> roommateAnswer : roommateAnswers.values()) {
                if (hasHardConflict(candidateAnswers, roommateAnswer)) {
                    hasHardConflict = true;
                    break;
                }
            }

            // 也检查已选学生之间的冲突
            for (Student alreadySelected : selected) {
                Map<Long, Long> selectedAnswers = getStudentAnswers(alreadySelected.getId());
                if (hasHardConflict(candidateAnswers, selectedAnswers)) {
                    hasHardConflict = true;
                    break;
                }
            }

            if (!hasHardConflict) {
                selected.add(candidate);
            }
        }

        return selected;
    }

    /**
     * 检查两个学生之间是否存在硬冲突
     *
     * 硬冲突规则：
     * - A完全不能忍受抽烟（Q6答案=1），B经常抽烟（Q2答案=3）
     * - A完全不能忍受晚睡（Q7答案=1），B凌晨后睡觉（Q1答案=4）
     * - A完全不能忍受打呼噜（Q8答案=1），B经常打呼噜（Q3答案=3）
     * - A完全不能忍受开麦（Q9答案=1），B经常开麦（Q5答案=4）
     * - A完全不能忍受卫生差（Q10答案=1），B卫生习惯随意（Q4答案=4）
     */
    private boolean hasHardConflict(Map<Long, Long> answersA, Map<Long, Long> answersB) {
        // Q6: 对抽烟的忍受程度（答案值1=完全不能忍受）
        // Q2: 是否抽烟（答案值3=经常抽烟）
        if (getAnswerValue(answersA, 6L) == 1 && getAnswerValue(answersB, 2L) == 3) {
            return true;
        }
        if (getAnswerValue(answersB, 6L) == 1 && getAnswerValue(answersA, 2L) == 3) {
            return true;
        }

        // Q7: 对晚睡的忍受程度（答案值1=完全不能忍受）
        // Q1: 作息时间（答案值4=凌晨后睡觉）
        if (getAnswerValue(answersA, 7L) == 1 && getAnswerValue(answersB, 1L) == 4) {
            return true;
        }
        if (getAnswerValue(answersB, 7L) == 1 && getAnswerValue(answersA, 1L) == 4) {
            return true;
        }

        // Q8: 对打呼噜的忍受程度（答案值1=完全不能忍受）
        // Q3: 是否打呼噜（答案值3=经常打呼噜）
        if (getAnswerValue(answersA, 8L) == 1 && getAnswerValue(answersB, 3L) == 3) {
            return true;
        }
        if (getAnswerValue(answersB, 8L) == 1 && getAnswerValue(answersA, 3L) == 3) {
            return true;
        }

        // Q9: 对开麦的忍受程度（答案值1=完全不能忍受）
        // Q5: 游戏开麦（答案值4=经常开麦）
        if (getAnswerValue(answersA, 9L) == 1 && getAnswerValue(answersB, 5L) == 4) {
            return true;
        }
        if (getAnswerValue(answersB, 9L) == 1 && getAnswerValue(answersA, 5L) == 4) {
            return true;
        }

        // Q10: 对卫生的忍受程度（答案值1=完全不能忍受）
        // Q4: 卫生习惯（答案值4=比较随意）
        if (getAnswerValue(answersA, 10L) == 1 && getAnswerValue(answersB, 4L) == 4) {
            return true;
        }
        if (getAnswerValue(answersB, 10L) == 1 && getAnswerValue(answersA, 4L) == 4) {
            return true;
        }

        return false;
    }

    /**
     * 获取学生的问卷答案
     * @return Map<题目ID, 选项值>
     */
    private Map<Long, Long> getStudentAnswers(Long studentId) {
        Map<Long, Long> answers = new HashMap<>();

        List<StudentQuestionnaire> records = studentQuestionnaireMapper.selectListByQuery(
                QueryWrapper.create()
                        .where(STUDENT_QUESTIONNAIRE.STUDENT_ID.eq(studentId))
        );

        for (StudentQuestionnaire record : records) {
            // 通过选项ID获取选项值
            // 这里直接存储题目ID和选项ID的映射
            answers.put(record.getQuestionId(), record.getOptionId());
        }

        return answers;
    }

    /**
     * 获取答案值（选项的option_value）
     * 由于answers里存的是optionId，需要转换
     */
    private int getAnswerValue(Map<Long, Long> answers, Long questionId) {
        Long optionId = answers.get(questionId);
        if (optionId == null) {
            return 0;
        }
        // 根据题目ID和选项ID计算值
        // 简化处理：optionId 和 questionId 的关系可以用来推导
        // Q1选项ID: 1-4, Q2: 5-7, Q3: 8-10, Q4: 11-14, Q5: 15-18
        // Q6: 19-22, Q7: 23-26, Q8: 27-30, Q9: 31-34, Q10: 35-38, Q11: 39-42
        if (questionId == 1L) return (int)(optionId - 0);
        if (questionId == 2L) return (int)(optionId - 4);
        if (questionId == 3L) return (int)(optionId - 7);
        if (questionId == 4L) return (int)(optionId - 10);
        if (questionId == 5L) return (int)(optionId - 14);
        if (questionId == 6L) return (int)(optionId - 18);
        if (questionId == 7L) return (int)(optionId - 22);
        if (questionId == 8L) return (int)(optionId - 26);
        if (questionId == 9L) return (int)(optionId - 30);
        if (questionId == 10L) return (int)(optionId - 34);
        if (questionId == 11L) return (int)(optionId - 38);
        return 0;
    }

    /**
     * 获取已填写问卷的学生
     */
    private List<Student> getStudentsWhoSubmittedQuestionnaire() {
        // 获取所有已填写问卷的学生ID
        List<StudentQuestionnaire> records = studentQuestionnaireMapper.selectAll();
        Set<Long> submittedStudentIds = records.stream()
                .map(StudentQuestionnaire::getStudentId)
                .collect(Collectors.toSet());

        if (submittedStudentIds.isEmpty()) {
            return new ArrayList<>();
        }

        // 获取未分配的学生
        List<Student> students = studentMapper.selectListByQuery(
                QueryWrapper.create()
                        .where(STUDENT.IS_DELETED.eq(Constants.NOT_DELETED))
                        .and(STUDENT.ID.in(submittedStudentIds))
        );

        // 过滤掉已分配的学生
        List<Student> unassigned = new ArrayList<>();
        for (Student student : students) {
            long count = dormAssignMapper.selectCountByQuery(
                    QueryWrapper.create()
                            .where(DORM_ASSIGN.STUDENT_ID.eq(student.getId()))
                            .and(DORM_ASSIGN.STATUS.eq(Constants.ASSIGN_STATUS_LIVING))
                            .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
            );
            if (count == 0) {
                unassigned.add(student);
            }
        }

        return unassigned;
    }

    /**
     * 获取可用宿舍
     */
    private List<Dormitory> getAvailableDormitories() {
        return dormitoryMapper.selectListByQuery(
                QueryWrapper.create()
                        .where(DORMITORY.IS_DELETED.eq(Constants.NOT_DELETED))
                        .and(DORMITORY.STATUS.ne(0))
                        .and(DORMITORY.OCCUPIED.lt(DORMITORY.CAPACITY))
                        .orderBy(DORMITORY.BUILDING_ID, true)
                        .orderBy(DORMITORY.ROOM_NO, true)
        );
    }

    /**
     * 获取当前宿舍的室友ID列表
     */
    private List<Long> getCurrentRoommates(Long dormitoryId) {
        List<DormAssign> assigns = dormAssignMapper.selectListByQuery(
                QueryWrapper.create()
                        .where(DORM_ASSIGN.DORMITORY_ID.eq(dormitoryId))
                        .and(DORM_ASSIGN.STATUS.eq(Constants.ASSIGN_STATUS_LIVING))
                        .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
        );

        return assigns.stream()
                .map(DormAssign::getStudentId)
                .collect(Collectors.toList());
    }

    /**
     * 获取分配结果列表
     */
    @Override
    public List<AssignmentResultVO> getAssignmentResults() {
        List<AssignmentResultVO> results = new ArrayList<>();

        List<DormAssign> assigns = dormAssignMapper.selectListByQuery(
                QueryWrapper.create()
                        .where(DORM_ASSIGN.STATUS.eq(Constants.ASSIGN_STATUS_LIVING))
                        .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
        );

        // 按宿舍分组
        Map<Long, List<DormAssign>> groupedByDorm = assigns.stream()
                .collect(Collectors.groupingBy(DormAssign::getDormitoryId));

        for (Map.Entry<Long, List<DormAssign>> entry : groupedByDorm.entrySet()) {
            Dormitory dormitory = dormitoryMapper.selectOneById(entry.getKey());
            if (dormitory == null) continue;

            Building building = buildingMapper.selectOneById(dormitory.getBuildingId());

            AssignmentResultVO vo = new AssignmentResultVO();
            vo.setDormitoryId(dormitory.getId());
            vo.setBuildingName(building != null ? building.getBuildingName() : "");
            vo.setRoomNo(dormitory.getRoomNo());

            List<AssignmentResultVO.RoommateInfo> roommates = new ArrayList<>();
            for (DormAssign assign : entry.getValue()) {
                Student student = studentMapper.selectOneById(assign.getStudentId());
                if (student != null) {
                    AssignmentResultVO.RoommateInfo info = new AssignmentResultVO.RoommateInfo();
                    info.setName(student.getName());
                    info.setMajor(student.getMajor());
                    info.setClassName(student.getClassName());
                    roommates.add(info);
                }
            }
            vo.setRoommates(roommates);
            results.add(vo);
        }

        return results;
    }

    /**
     * 获取当前学生的分配结果
     */
    @Override
    public AssignmentResultVO getMyAssignment(Long studentId) {
        DormAssign assign = dormAssignMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(DORM_ASSIGN.STUDENT_ID.eq(studentId))
                        .and(DORM_ASSIGN.STATUS.eq(Constants.ASSIGN_STATUS_LIVING))
                        .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
        );

        if (assign == null) {
            return null;
        }

        Dormitory dormitory = dormitoryMapper.selectOneById(assign.getDormitoryId());
        if (dormitory == null) {
            return null;
        }

        Building building = buildingMapper.selectOneById(dormitory.getBuildingId());

        AssignmentResultVO vo = new AssignmentResultVO();
        vo.setDormitoryId(dormitory.getId());
        vo.setBuildingName(building != null ? building.getBuildingName() : "");
        vo.setRoomNo(dormitory.getRoomNo());
        vo.setBedNo(assign.getBedNo());

        // 获取室友信息
        List<DormAssign> roommateAssigns = dormAssignMapper.selectListByQuery(
                QueryWrapper.create()
                        .where(DORM_ASSIGN.DORMITORY_ID.eq(dormitory.getId()))
                        .and(DORM_ASSIGN.STATUS.eq(Constants.ASSIGN_STATUS_LIVING))
                        .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
        );

        List<AssignmentResultVO.RoommateInfo> roommates = new ArrayList<>();
        for (DormAssign ra : roommateAssigns) {
            Student roommate = studentMapper.selectOneById(ra.getStudentId());
            if (roommate != null) {
                AssignmentResultVO.RoommateInfo info = new AssignmentResultVO.RoommateInfo();
                info.setName(roommate.getName());
                info.setMajor(roommate.getMajor());
                info.setClassName(roommate.getClassName());
                roommates.add(info);
            }
        }
        vo.setRoommates(roommates);

        return vo;
    }
}