package com.dormitory.management.service;

import com.dormitory.management.vo.DashboardVO;

/**
 * 仪表盘服务接口
 */
public interface DashboardService {
    
    /**
     * 获取仪表盘数据
     */
    DashboardVO getDashboardData();
}



