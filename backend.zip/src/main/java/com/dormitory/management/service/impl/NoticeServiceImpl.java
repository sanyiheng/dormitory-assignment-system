package com.dormitory.management.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.dormitory.management.common.Constants;
import com.dormitory.management.common.ResultCode;
import com.dormitory.management.dto.NoticeDTO;
import com.dormitory.management.dto.PageQueryDTO;
import com.dormitory.management.entity.Notice;
import com.dormitory.management.exception.BusinessException;
import com.dormitory.management.mapper.NoticeMapper;
import com.dormitory.management.service.NoticeService;
import com.dormitory.management.vo.NoticeVO;
import com.mybatisflex.core.paginate.Page;
import com.mybatisflex.core.query.QueryWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

import static com.dormitory.management.entity.table.NoticeTableDef.NOTICE;

/**
 * 通知公告服务实现类
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class NoticeServiceImpl implements NoticeService {
    
    private final NoticeMapper noticeMapper;
    private final StringRedisTemplate redisTemplate;
    
    @Override
    public Page<NoticeVO> pageQuery(PageQueryDTO pageQueryDTO) {
        QueryWrapper wrapper = QueryWrapper.create()
                .where(NOTICE.IS_DELETED.eq(Constants.NOT_DELETED));
        
        // 注意：管理员端应该看到所有状态的公告，学生端只看已发布的
        // 如果需要按状态过滤，可以在 PageQueryDTO 中添加 status 参数
        
        // 关键词搜索
        if (StrUtil.isNotBlank(pageQueryDTO.getKeyword())) {
            wrapper.and(NOTICE.TITLE.like(pageQueryDTO.getKeyword()));
        }
        
        // 排序：置顶优先，然后按发布时间倒序
        wrapper.orderBy(NOTICE.IS_TOP, false)
                .orderBy(NOTICE.CREATE_TIME, false);
        
        Page<Notice> page = noticeMapper.paginate(
                new Page<>(pageQueryDTO.getPageNum(), pageQueryDTO.getPageSize()),
                wrapper
        );
        
        // 转换为VO
        Page<NoticeVO> voPage = new Page<>();
        voPage.setPageNumber(page.getPageNumber());
        voPage.setPageSize(page.getPageSize());
        voPage.setTotalRow(page.getTotalRow());
        voPage.setRecords(page.getRecords().stream().map(this::convertToVO).toList());
        
        return voPage;
    }
    
    @Override
    public NoticeVO getById(Long id) {
        // 先从缓存获取
        String cacheKey = Constants.REDIS_KEY_NOTICE + id;
        String cacheData = redisTemplate.opsForValue().get(cacheKey);
        
        Notice notice;
        if (StrUtil.isNotBlank(cacheData)) {
            notice = BeanUtil.toBean(cacheData, Notice.class);
        } else {
            notice = noticeMapper.selectOneById(id);
            if (notice == null || notice.getIsDeleted() == Constants.IS_DELETED) {
                throw new BusinessException(ResultCode.NOTICE_NOT_EXIST);
            }
            
            // 缓存5分钟
            redisTemplate.opsForValue().set(cacheKey, BeanUtil.toBean(notice, String.class), 5, TimeUnit.MINUTES);
        }
        
        // 增加浏览次数
        notice.setViewCount(notice.getViewCount() + 1);
        noticeMapper.update(notice);
        
        return convertToVO(notice);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void publish(NoticeDTO noticeDTO, Long publisherId, String publisherName) {
        Notice notice = BeanUtil.copyProperties(noticeDTO, Notice.class);
        
        notice.setPublisherId(publisherId);
        notice.setPublisherName(publisherName);
        notice.setPublishTime(LocalDateTime.now());
        notice.setStatus(Constants.NOTICE_STATUS_PUBLISHED);
        notice.setViewCount(0);
        notice.setIsTop(noticeDTO.getIsTop() != null ? noticeDTO.getIsTop() : 0);
        
        // 设置默认值
        if (StrUtil.isBlank(notice.getNoticeType())) {
            notice.setNoticeType("SYSTEM");
        }
        if (notice.getPriority() == null) {
            notice.setPriority(1);
        }
        if (StrUtil.isBlank(notice.getTargetRole())) {
            notice.setTargetRole("ALL");
        }
        
        noticeMapper.insert(notice);

        log.info("发布公告成功：{} - {}", publisherName, notice.getTitle());
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(NoticeDTO noticeDTO) {
        Notice notice = noticeMapper.selectOneById(noticeDTO.getId());
        if (notice == null || notice.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException(ResultCode.NOTICE_NOT_EXIST);
        }
        
        BeanUtil.copyProperties(noticeDTO, notice, "id", "publisherId", "publisherName", "publishTime", "viewCount");
        noticeMapper.update(notice);
        
        // 清除缓存
        String cacheKey = Constants.REDIS_KEY_NOTICE + notice.getId();
        redisTemplate.delete(cacheKey);
        
        log.info("更新公告成功：{}", notice.getTitle());
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        Notice notice = noticeMapper.selectOneById(id);
        if (notice == null) {
            throw new BusinessException(ResultCode.NOTICE_NOT_EXIST);
        }
        
        // 逻辑删除
        notice.setIsDeleted(Constants.IS_DELETED);
        noticeMapper.update(notice);
        
        // 清除缓存
        String cacheKey = Constants.REDIS_KEY_NOTICE + id;
        redisTemplate.delete(cacheKey);
        
        log.info("删除公告成功：{}", notice.getTitle());
    }
    
    /**
     * 转换为VO
     */
    private NoticeVO convertToVO(Notice notice) {
        NoticeVO vo = BeanUtil.copyProperties(notice, NoticeVO.class);
        
        // 状态文本
        vo.setStatusText(getStatusText(notice.getStatus()));
        
        // 公告类型文本
        vo.setNoticeTypeText(getNoticeTypeText(notice.getNoticeType()));
        
        // 优先级文本
        vo.setPriorityText(getPriorityText(notice.getPriority()));
        
        return vo;
    }
    
    private String getStatusText(Integer status) {
        return switch (status) {
            case Constants.NOTICE_STATUS_DRAFT -> "草稿";
            case Constants.NOTICE_STATUS_PUBLISHED -> "已发布";
            case Constants.NOTICE_STATUS_EXPIRED -> "已过期";
            default -> "未知";
        };
    }
    
    private String getNoticeTypeText(String noticeType) {
        return switch (noticeType) {
            case "SYSTEM" -> "系统公告";
            case "ACTIVITY" -> "活动通知";
            case "MAINTENANCE" -> "维修通知";
            default -> noticeType;
        };
    }
    
    private String getPriorityText(Integer priority) {
        return switch (priority) {
            case 0 -> "低";
            case 1 -> "中";
            case 2 -> "高";
            default -> "未知";
        };
    }
}


