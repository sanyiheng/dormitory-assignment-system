package com.dormitory.management.service;

import com.dormitory.management.dto.PageQueryDTO;
import com.dormitory.management.dto.StudentDTO;
import com.dormitory.management.vo.StudentDormInfoVO;
import com.dormitory.management.vo.StudentHomeVO;
import com.dormitory.management.vo.StudentVO;
import com.mybatisflex.core.paginate.Page;

/**
 * 学生服务接口
 */
public interface StudentService {
    
    /**
     * 分页查询学生
     */
    Page<StudentVO> pageQuery(PageQueryDTO pageQueryDTO);
    
    /**
     * 根据ID查询学生
     */
    StudentVO getById(Long id);
    
    /**
     * 新增学生
     */
    void add(StudentDTO studentDTO);
    
    /**
     * 更新学生
     */
    void update(StudentDTO studentDTO);
    
    /**
     * 删除学生
     */
    void delete(Long id);
    
    /**
     * 批量删除学生
     */
    void batchDelete(Long[] ids);
    
    /**
     * 修改密码
     */
    void changePassword(Long id, String oldPassword, String newPassword);
    
    /**
     * 获取学生首页信息
     */
    StudentHomeVO getStudentHomeInfo(Long studentId);
    
    /**
     * 获取学生宿舍信息（包括室友）
     */
    StudentDormInfoVO getStudentDormInfo(Long studentId);
}


