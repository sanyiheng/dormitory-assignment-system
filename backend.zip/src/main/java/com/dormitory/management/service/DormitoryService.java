package com.dormitory.management.service;

import com.dormitory.management.dto.DormAssignDTO;
import com.dormitory.management.dto.DormitoryDTO;
import com.dormitory.management.dto.PageQueryDTO;
import com.dormitory.management.vo.DormitoryVO;
import com.mybatisflex.core.paginate.Page;

import java.util.List;

/**
 * 宿舍服务接口
 */
public interface DormitoryService {
    
    /**
     * 分页查询宿舍
     */
    Page<DormitoryVO> pageQuery(PageQueryDTO pageQueryDTO);
    
    /**
     * 根据ID查询宿舍
     */
    DormitoryVO getById(Long id);
    
    /**
     * 新增宿舍
     */
    void add(DormitoryDTO dormitoryDTO);
    
    /**
     * 更新宿舍
     */
    void update(DormitoryDTO dormitoryDTO);
    
    /**
     * 删除宿舍
     */
    void delete(Long id);
    
    /**
     * 批量删除宿舍
     */
    void batchDelete(Long[] ids);
    
    /**
     * 获取可用宿舍列表（有空余床位）
     */
    List<DormitoryVO> getAvailableDormitories();
    
    /**
     * 分配宿舍
     */
    void assignDormitory(DormAssignDTO dormAssignDTO);
    
    /**
     * 取消宿舍分配
     */
    void unassignDormitory(Long studentId);
}



