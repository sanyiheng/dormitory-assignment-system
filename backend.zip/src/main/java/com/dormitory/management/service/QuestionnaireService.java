package com.dormitory.management.service;

import com.dormitory.management.dto.SubmitQuestionnaireDTO;
import com.dormitory.management.vo.QuestionnaireVO;

import java.util.List;

/**
 * 问卷服务接口
 */
public interface QuestionnaireService {

    /**
     * 获取所有问卷题目（含选项）
     */
    List<QuestionnaireVO> getQuestionnaireList();

    /**
     * 提交问卷
     */
    void submitQuestionnaire(SubmitQuestionnaireDTO dto, Long studentId);

    /**
     * 检查学生是否已填写问卷
     */
    boolean hasSubmitted(Long studentId);
}