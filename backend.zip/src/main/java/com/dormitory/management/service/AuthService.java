package com.dormitory.management.service;

import com.dormitory.management.dto.LoginDTO;
import com.dormitory.management.dto.RegisterDTO;
import com.dormitory.management.vo.LoginVO;

/**
 * 认证服务接口
 */
public interface AuthService {
    
    /**
     * 用户登录
     */
    LoginVO login(LoginDTO loginDTO);
    
    /**
     * 用户登出
     */
    void logout();
    
    /**
     * 获取当前登录用户信息
     */
    LoginVO getCurrentUser();
    
    /**
     * 用户注册（学生和维修人员）
     */
    void register(RegisterDTO registerDTO);
    
    /**
     * 修改密码
     * @param userId 用户ID
     * @param userType 用户类型（ADMIN/STUDENT/STAFF）
     * @param oldPassword 原密码
     * @param newPassword 新密码
     */
    void changePassword(Long userId, String userType, String oldPassword, String newPassword);
}


