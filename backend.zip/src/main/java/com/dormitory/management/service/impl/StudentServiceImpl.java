package com.dormitory.management.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.digest.BCrypt;
import com.dormitory.management.common.Constants;
import com.dormitory.management.common.ResultCode;
import com.dormitory.management.dto.PageQueryDTO;
import com.dormitory.management.dto.StudentDTO;
import com.dormitory.management.entity.Building;
import com.dormitory.management.entity.DormAssign;
import com.dormitory.management.entity.Dormitory;
import com.dormitory.management.entity.Student;
import com.dormitory.management.exception.BusinessException;
import com.dormitory.management.mapper.*;
import com.dormitory.management.service.StudentService;
import com.dormitory.management.vo.RoommateVO;
import com.dormitory.management.vo.StudentDormInfoVO;
import com.dormitory.management.vo.StudentHomeVO;
import com.dormitory.management.vo.StudentVO;
import com.mybatisflex.core.paginate.Page;
import com.mybatisflex.core.query.QueryWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static com.dormitory.management.entity.table.DormAssignTableDef.DORM_ASSIGN;
import static com.dormitory.management.entity.table.StudentTableDef.STUDENT;

/**
 * 学生服务实现类
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {
    
    private final StudentMapper studentMapper;
    private final DormAssignMapper dormAssignMapper;
    private final DormitoryMapper dormitoryMapper;
    private final BuildingMapper buildingMapper;
    private final NoticeMapper noticeMapper;
    
    @Override
    public Page<StudentVO> pageQuery(PageQueryDTO pageQueryDTO) {
        QueryWrapper wrapper = QueryWrapper.create()
                .where(STUDENT.IS_DELETED.eq(Constants.NOT_DELETED));
        
        // 关键词搜索
        if (StrUtil.isNotBlank(pageQueryDTO.getKeyword())) {
            wrapper.and(STUDENT.NAME.like(pageQueryDTO.getKeyword())
                    .or(STUDENT.STUDENT_NO.like(pageQueryDTO.getKeyword()))
                    .or(STUDENT.CLASS_NAME.like(pageQueryDTO.getKeyword())));
        }
        
        // 排序
        if (StrUtil.isNotBlank(pageQueryDTO.getSortField())) {
            if ("asc".equalsIgnoreCase(pageQueryDTO.getSortOrder())) {
                wrapper.orderBy(pageQueryDTO.getSortField(), true);
            } else {
                wrapper.orderBy(pageQueryDTO.getSortField(), false);
            }
        } else {
            wrapper.orderBy(STUDENT.CREATE_TIME, false);
        }
        
        Page<Student> page = studentMapper.paginate(
                new Page<>(pageQueryDTO.getPageNum(), pageQueryDTO.getPageSize()),
                wrapper
        );
        
        // 转换为VO
        Page<StudentVO> voPage = new Page<>();
        voPage.setPageNumber(page.getPageNumber());
        voPage.setPageSize(page.getPageSize());
        voPage.setTotalRow(page.getTotalRow());
        voPage.setRecords(page.getRecords().stream().map(this::convertToVO).toList());
        
        return voPage;
    }
    
    @Override
    public StudentVO getById(Long id) {
        Student student = studentMapper.selectOneById(id);
        if (student == null || student.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException(ResultCode.STUDENT_NOT_EXIST);
        }
        return convertToVO(student);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void add(StudentDTO studentDTO) {
        // 检查身份证号是否存在
        if (StrUtil.isNotBlank(studentDTO.getIdCard())) {
            Student existStudent = studentMapper.selectOneByQuery(
                    QueryWrapper.create()
                            .where(STUDENT.ID_CARD.eq(studentDTO.getIdCard()))
                            .and(STUDENT.IS_DELETED.eq(Constants.NOT_DELETED))
            );
            if (existStudent != null) {
                throw new BusinessException("该身份证号已存在");
            }
        }
        
        Student student = BeanUtil.copyProperties(studentDTO, Student.class);
        
        // 密码加密
        if (StrUtil.isNotBlank(studentDTO.getPassword())) {
            student.setPassword(BCrypt.hashpw(studentDTO.getPassword()));
        } else {
            // 默认密码：123456
            student.setPassword(BCrypt.hashpw("123456"));
        }
        
        student.setStatus(Constants.USER_STATUS_ENABLED);
        studentMapper.insert(student);
        
        log.info("新增学生成功：{}", student.getStudentNo());
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(StudentDTO studentDTO) {
        Student student = studentMapper.selectOneById(studentDTO.getId());
        if (student == null || student.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException(ResultCode.STUDENT_NOT_EXIST);
        }

        // 检查身份证号是否被其他学生使用
        if (StrUtil.isNotBlank(studentDTO.getIdCard())) {
            Student existStudent = studentMapper.selectOneByQuery(
                    QueryWrapper.create()
                            .where(STUDENT.ID_CARD.eq(studentDTO.getIdCard()))
                            .and(STUDENT.ID.ne(studentDTO.getId()))
                            .and(STUDENT.IS_DELETED.eq(Constants.NOT_DELETED))
            );
            if (existStudent != null) {
                throw new BusinessException("该身份证号已存在");
            }
        }
        
        BeanUtil.copyProperties(studentDTO, student, "id", "password");
        studentMapper.update(student);
        
        log.info("更新学生成功：{}", student.getStudentNo());
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        Student student = studentMapper.selectOneById(id);
        if (student == null) {
            throw new BusinessException(ResultCode.STUDENT_NOT_EXIST);
        }
        
        // 逻辑删除
        student.setIsDeleted(Constants.IS_DELETED);
        studentMapper.update(student);
        
        log.info("删除学生成功：{}", student.getStudentNo());
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void batchDelete(Long[] ids) {
        for (Long id : ids) {
            delete(id);
        }
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void changePassword(Long id, String oldPassword, String newPassword) {
        Student student = studentMapper.selectOneById(id);
        if (student == null) {
            throw new BusinessException(ResultCode.STUDENT_NOT_EXIST);
        }
        
        // 验证旧密码
        if (!BCrypt.checkpw(oldPassword, student.getPassword())) {
            throw new BusinessException(ResultCode.OLD_PASSWORD_ERROR);
        }
        
        // 更新密码
        student.setPassword(BCrypt.hashpw(newPassword));
        studentMapper.update(student);
        
        log.info("学生修改密码成功：{}", student.getStudentNo());
    }
    
    @Override
    public StudentHomeVO getStudentHomeInfo(Long studentId) {
        Student student = studentMapper.selectOneById(studentId);
        if (student == null || student.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException(ResultCode.STUDENT_NOT_EXIST);
        }
        
        StudentHomeVO vo = new StudentHomeVO();
        vo.setStudentId(student.getId());
        vo.setStudentName(student.getName());
        
        // 查询宿舍分配信息
        DormAssign dormAssign = dormAssignMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(DORM_ASSIGN.STUDENT_ID.eq(studentId))
                        .and(DORM_ASSIGN.STATUS.eq(Constants.ASSIGN_STATUS_LIVING))
                        .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        
        if (dormAssign != null) {
            vo.setHasDormitory(true);
            // 获取宿舍详细信息
            Dormitory dormitory = dormitoryMapper.selectOneById(dormAssign.getDormitoryId());
            if (dormitory != null) {
                Building building = buildingMapper.selectOneById(dormitory.getBuildingId());
                if (building != null) {
                    vo.setDormitoryInfo(building.getBuildingName() + "-" + dormitory.getRoomNo());
                }
            }
        } else {
            vo.setHasDormitory(false);
            vo.setDormitoryInfo("未分配");
        }

        // 待处理报修数改为0（毕设系统不包含报修功能）
        vo.setPendingRepairCount(0);
        
        // 查询公告数
        vo.setUnreadNoticeCount(noticeMapper.selectAll().size());
        
        return vo;
    }
    
    @Override
    public StudentDormInfoVO getStudentDormInfo(Long studentId) {
        Student student = studentMapper.selectOneById(studentId);
        if (student == null || student.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException(ResultCode.STUDENT_NOT_EXIST);
        }
        
        // 查询宿舍分配信息
        DormAssign dormAssign = dormAssignMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(DORM_ASSIGN.STUDENT_ID.eq(studentId))
                        .and(DORM_ASSIGN.STATUS.eq(Constants.ASSIGN_STATUS_LIVING))
                        .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        
        if (dormAssign == null) {
            throw new BusinessException("您还未分配宿舍");
        }
        
        StudentDormInfoVO vo = new StudentDormInfoVO();
        vo.setAssignId(dormAssign.getId());
        vo.setDormitoryId(dormAssign.getDormitoryId());
        vo.setBedNo(dormAssign.getBedNo());
        vo.setCheckInDate(dormAssign.getCheckInDate());
        
        // 查询宿舍详细信息
        Dormitory dormitory = dormitoryMapper.selectOneById(dormAssign.getDormitoryId());
        if (dormitory != null) {
            vo.setRoomNo(dormitory.getRoomNo());
            vo.setFloor(dormitory.getFloor());
            vo.setCapacity(dormitory.getCapacity());
            vo.setOccupied(dormitory.getOccupied());
            vo.setRoomType(dormitory.getRoomType());
            vo.setFacilities(dormitory.getFacilities());
            vo.setBuildingId(dormitory.getBuildingId());
            
            // 查询楼栋信息
            Building building = buildingMapper.selectOneById(dormitory.getBuildingId());
            if (building != null) {
                vo.setBuildingName(building.getBuildingName());
                vo.setBuildingNo(building.getBuildingNo());
            }
        }
        
        // 查询室友信息
        List<DormAssign> roommates = dormAssignMapper.selectListByQuery(
                QueryWrapper.create()
                        .where(DORM_ASSIGN.DORMITORY_ID.eq(dormAssign.getDormitoryId()))
                        .and(DORM_ASSIGN.STATUS.eq(Constants.ASSIGN_STATUS_LIVING))
                        .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        
        List<RoommateVO> roommateVOS = new ArrayList<>();
        for (DormAssign ra : roommates) {
            Student roommate = studentMapper.selectOneById(ra.getStudentId());
            if (roommate != null) {
                RoommateVO roommateVO = new RoommateVO();
                roommateVO.setId(roommate.getId());
                roommateVO.setStudentNo(roommate.getStudentNo());
                roommateVO.setName(roommate.getName());
                roommateVO.setGender(roommate.getGender());
                roommateVO.setGenderText(roommate.getGender() == Constants.GENDER_MALE ? "男" : "女");
                roommateVO.setClassName(roommate.getClassName());
                roommateVO.setMajor(roommate.getMajor());
                roommateVO.setPhone(roommate.getPhone());
                roommateVO.setBedNo(ra.getBedNo());
                roommateVOS.add(roommateVO);
            }
        }
        vo.setRoommates(roommateVOS);
        
        return vo;
    }
    
    /**
     * 转换为VO
     */
    private StudentVO convertToVO(Student student) {
        StudentVO vo = BeanUtil.copyProperties(student, StudentVO.class);
        vo.setGenderText(student.getGender() == Constants.GENDER_MALE ? "男" : "女");
        vo.setStatusText(student.getStatus() == Constants.USER_STATUS_ENABLED ? "启用" : "禁用");
        
        // 查询宿舍信息
        DormAssign dormAssign = dormAssignMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(DORM_ASSIGN.STUDENT_ID.eq(student.getId()))
                        .and(DORM_ASSIGN.STATUS.eq(Constants.ASSIGN_STATUS_LIVING))
                        .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        if (dormAssign != null) {
            // 获取宿舍详细信息
            Dormitory dormitory = dormitoryMapper.selectOneById(dormAssign.getDormitoryId());
            if (dormitory != null) {
                Building building = buildingMapper.selectOneById(dormitory.getBuildingId());
                if (building != null) {
                    vo.setDormitoryInfo(building.getBuildingName() + "-" + dormitory.getRoomNo());
                } else {
                    vo.setDormitoryInfo("已分配宿舍");
                }
            } else {
                vo.setDormitoryInfo("已分配宿舍");
            }
        } else {
            vo.setDormitoryInfo("未分配");
        }
        
        return vo;
    }
}


