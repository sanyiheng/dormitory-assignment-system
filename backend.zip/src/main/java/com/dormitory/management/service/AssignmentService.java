package com.dormitory.management.service;

import com.dormitory.management.vo.AssignmentResultVO;

import java.util.List;

/**
 * 宿舍分配服务接口
 */
public interface AssignmentService {

    /**
     * 执行自动分配
     */
    int executeAssignment();

    /**
     * 获取分配结果列表
     */
    List<AssignmentResultVO> getAssignmentResults();

    /**
     * 获取当前学生的分配结果
     */
    AssignmentResultVO getMyAssignment(Long studentId);
}