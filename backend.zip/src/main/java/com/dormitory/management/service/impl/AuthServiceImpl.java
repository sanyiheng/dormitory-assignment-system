package com.dormitory.management.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.crypto.digest.BCrypt;
import com.dormitory.management.common.Constants;
import com.dormitory.management.common.ResultCode;
import com.dormitory.management.dto.LoginDTO;
import com.dormitory.management.entity.AdminUser;
import com.dormitory.management.entity.Student;
import com.dormitory.management.entity.SystemConfig;
import com.dormitory.management.exception.BusinessException;
import com.dormitory.management.mapper.AdminUserMapper;
import com.dormitory.management.mapper.StudentMapper;
import com.dormitory.management.mapper.SystemConfigMapper;
import com.dormitory.management.service.AuthService;
import com.dormitory.management.vo.LoginVO;
import com.mybatisflex.core.query.QueryWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

import static com.dormitory.management.entity.table.AdminUserTableDef.ADMIN_USER;
import static com.dormitory.management.entity.table.StudentTableDef.STUDENT;
import static com.dormitory.management.entity.table.SystemConfigTableDef.SYSTEM_CONFIG;

/**
 * 认证服务实现类
 * 改造：学生改为身份证号登录，移除维修人员相关代码
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final AdminUserMapper adminUserMapper;
    private final StudentMapper studentMapper;
    private final SystemConfigMapper systemConfigMapper;
    private final StringRedisTemplate redisTemplate;

    @Override
    public LoginVO login(LoginDTO loginDTO) {
        // 检查系统总开关（管理员不受限制）
        if (!Constants.USER_TYPE_ADMIN.equals(loginDTO.getUserType())) {
            SystemConfig systemConfig = systemConfigMapper.selectOneByQuery(
                    QueryWrapper.create()
                            .where(SYSTEM_CONFIG.CONFIG_KEY.eq("SYSTEM_SWITCH"))
            );
            if (systemConfig != null && "OFF".equals(systemConfig.getConfigValue())) {
                throw new BusinessException("系统暂未开放，请等待管理员开启");
            }
        }

        String username = loginDTO.getUsername();
        String password = loginDTO.getPassword();
        String userType = loginDTO.getUserType();

        LoginVO loginVO = new LoginVO();
        loginVO.setUserType(userType);

        if (Constants.USER_TYPE_ADMIN.equals(userType)) {
            // 管理员登录
            AdminUser admin = adminUserMapper.selectOneByQuery(
                    QueryWrapper.create()
                            .where(ADMIN_USER.USERNAME.eq(username))
                            .and(ADMIN_USER.IS_DELETED.eq(Constants.NOT_DELETED))
            );

            if (admin == null) {
                throw new BusinessException(ResultCode.USER_NOT_EXIST);
            }

            if (admin.getStatus() == Constants.USER_STATUS_DISABLED) {
                throw new BusinessException(ResultCode.USER_DISABLED);
            }

            // 验证密码
            if (!BCrypt.checkpw(password, admin.getPassword())) {
                throw new BusinessException(ResultCode.PASSWORD_ERROR);
            }

            // 登录成功
            StpUtil.login(admin.getId());
            StpUtil.getSession().set("userType", userType);

            loginVO.setUserId(admin.getId());
            loginVO.setUsername(admin.getUsername());
            loginVO.setRealName(admin.getRealName());
            loginVO.setRole("ADMIN");
            loginVO.setAvatar(admin.getAvatar());

        } else if (Constants.USER_TYPE_STUDENT.equals(userType)) {
            // 学生登录：使用身份证号登录
            Student student = studentMapper.selectOneByQuery(
                    QueryWrapper.create()
                            .where(STUDENT.ID_CARD.eq(username))
                            .and(STUDENT.IS_DELETED.eq(Constants.NOT_DELETED))
            );

            if (student == null) {
                throw new BusinessException(ResultCode.USER_NOT_EXIST);
            }

            if (student.getStatus() == Constants.USER_STATUS_DISABLED) {
                throw new BusinessException(ResultCode.USER_DISABLED);
            }

            // 验证密码（身份证后六位）
            String idCard = student.getIdCard();
            if (idCard == null || idCard.length() < 6) {
                throw new BusinessException("身份证号信息不完整，请联系管理员");
            }
            String expectedPassword = idCard.substring(idCard.length() - 6);

            if (!password.equals(expectedPassword)) {
                throw new BusinessException(ResultCode.PASSWORD_ERROR);
            }

            // 登录成功
            StpUtil.login(student.getId());
            StpUtil.getSession().set("userType", userType);

            loginVO.setUserId(student.getId());
            loginVO.setUsername(student.getIdCard());
            loginVO.setRealName(student.getName());
            loginVO.setRole("STUDENT");
            loginVO.setAvatar(student.getAvatar());

        } else {
            throw new BusinessException("用户类型不正确");
        }

        // 生成Token
        String token = StpUtil.getTokenValue();
        loginVO.setToken(token);
        loginVO.setExpireTime(StpUtil.getTokenTimeout());

        // 缓存用户信息到Redis
        String redisKey = Constants.REDIS_KEY_LOGIN_USER + userType + ":" + loginVO.getUserId();
        redisTemplate.opsForValue().set(redisKey, token, 30, TimeUnit.MINUTES);

        // 单独缓存 userType
        String userTypeKey = "user:type:" + loginVO.getUserId();
        redisTemplate.opsForValue().set(userTypeKey, userType, 30, TimeUnit.MINUTES);

        // 记录在线用户
        redisTemplate.opsForSet().add(Constants.REDIS_KEY_ONLINE_USERS,
                userType + ":" + loginVO.getUserId());

        log.info("用户登录成功：{} - {}", userType, username);
        return loginVO;
    }

    @Override
    public void logout() {
        Long userId = StpUtil.getLoginIdAsLong();
        String userType = (String) StpUtil.getSession().get("userType");

        StpUtil.logout();

        String redisKey = Constants.REDIS_KEY_LOGIN_USER + userType + ":" + userId;
        redisTemplate.delete(redisKey);

        redisTemplate.opsForSet().remove(Constants.REDIS_KEY_ONLINE_USERS,
                userType + ":" + userId);

        log.info("用户登出成功：{} - {}", userType, userId);
    }

    @Override
    public LoginVO getCurrentUser() {
        if (!StpUtil.isLogin()) {
            throw new BusinessException(ResultCode.UNAUTHORIZED);
        }

        Long userId = StpUtil.getLoginIdAsLong();
        String userType = (String) StpUtil.getSession().get("userType");

        LoginVO loginVO = new LoginVO();
        loginVO.setUserId(userId);
        loginVO.setUserType(userType);
        loginVO.setToken(StpUtil.getTokenValue());

        return loginVO;
    }

    @Override
    public void register(com.dormitory.management.dto.RegisterDTO registerDTO) {
        throw new BusinessException("本系统不支持自助注册，请联系管理员导入学生信息");
    }

    @Override
    public void changePassword(Long userId, String userType, String oldPassword, String newPassword) {
        if (newPassword == null || newPassword.length() < 6) {
            throw new BusinessException("新密码长度至少为6位");
        }

        if (Constants.USER_TYPE_ADMIN.equals(userType)) {
            AdminUser adminUser = adminUserMapper.selectOneById(userId);
            if (adminUser == null || adminUser.getIsDeleted() == Constants.IS_DELETED) {
                throw new BusinessException(ResultCode.USER_NOT_EXIST);
            }

            if (!BCrypt.checkpw(oldPassword, adminUser.getPassword())) {
                throw new BusinessException("原密码错误");
            }

            adminUser.setPassword(BCrypt.hashpw(newPassword));
            adminUserMapper.update(adminUser);

            log.info("管理员修改密码成功：{}", adminUser.getUsername());

        } else if (Constants.USER_TYPE_STUDENT.equals(userType)) {
            Student student = studentMapper.selectOneById(userId);
            if (student == null || student.getIsDeleted() == Constants.IS_DELETED) {
                throw new BusinessException(ResultCode.USER_NOT_EXIST);
            }

            if (!BCrypt.checkpw(oldPassword, student.getPassword())) {
                throw new BusinessException("原密码错误");
            }

            student.setPassword(BCrypt.hashpw(newPassword));
            studentMapper.update(student);

            log.info("学生修改密码成功：{}", student.getStudentNo());

        } else {
            throw new BusinessException("无法识别的用户类型");
        }

        StpUtil.logout(userId);
    }
}