package com.dormitory.management.service.impl;

import com.dormitory.management.common.Constants;
import com.dormitory.management.dto.SubmitQuestionnaireDTO;
import com.dormitory.management.entity.Questionnaire;
import com.dormitory.management.entity.QuestionnaireOption;
import com.dormitory.management.entity.StudentQuestionnaire;
import com.dormitory.management.entity.SystemConfig;
import com.dormitory.management.exception.BusinessException;
import com.dormitory.management.mapper.QuestionnaireMapper;
import com.dormitory.management.mapper.QuestionnaireOptionMapper;
import com.dormitory.management.mapper.StudentQuestionnaireMapper;
import com.dormitory.management.mapper.SystemConfigMapper;
import com.dormitory.management.service.QuestionnaireService;
import com.dormitory.management.vo.QuestionnaireVO;
import com.mybatisflex.core.query.QueryWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static com.dormitory.management.entity.table.QuestionnaireOptionTableDef.QUESTIONNAIRE_OPTION;
import static com.dormitory.management.entity.table.QuestionnaireTableDef.QUESTIONNAIRE;
import static com.dormitory.management.entity.table.StudentQuestionnaireTableDef.STUDENT_QUESTIONNAIRE;
import static com.dormitory.management.entity.table.SystemConfigTableDef.SYSTEM_CONFIG;

/**
 * 问卷服务实现类
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class QuestionnaireServiceImpl implements QuestionnaireService {

    private final QuestionnaireMapper questionnaireMapper;
    private final QuestionnaireOptionMapper questionnaireOptionMapper;
    private final StudentQuestionnaireMapper studentQuestionnaireMapper;
    private final SystemConfigMapper systemConfigMapper;

    @Override
    public List<QuestionnaireVO> getQuestionnaireList() {
        // 检查问卷填写开关
        SystemConfig config = systemConfigMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(SYSTEM_CONFIG.CONFIG_KEY.eq("QUESTIONNAIRE_SWITCH"))
        );
        if (config != null && "OFF".equals(config.getConfigValue())) {
            throw new BusinessException("问卷填写已截止");
        }

        // 查询所有未删除的题目，按排序字段排序
        List<Questionnaire> questions = questionnaireMapper.selectListByQuery(
                QueryWrapper.create()
                        .where(QUESTIONNAIRE.IS_DELETED.eq(Constants.NOT_DELETED))
                        .orderBy(QUESTIONNAIRE.SORT_ORDER, true)
        );

        List<QuestionnaireVO> voList = new ArrayList<>();
        for (Questionnaire question : questions) {
            QuestionnaireVO vo = new QuestionnaireVO();
            vo.setId(question.getId());
            vo.setQuestionNo(question.getQuestionNo());
            vo.setQuestionText(question.getQuestionText());
            vo.setDimension(question.getDimension());
            vo.setSortOrder(question.getSortOrder());

            // 查询该题目的选项
            List<QuestionnaireOption> options = questionnaireOptionMapper.selectListByQuery(
                    QueryWrapper.create()
                            .where(QUESTIONNAIRE_OPTION.QUESTION_ID.eq(question.getId()))
                            .and(QUESTIONNAIRE_OPTION.IS_DELETED.eq(Constants.NOT_DELETED))
                            .orderBy(QUESTIONNAIRE_OPTION.SORT_ORDER, true)
            );

            List<QuestionnaireVO.QuestionnaireOptionVO> optionVOs = new ArrayList<>();
            for (QuestionnaireOption option : options) {
                QuestionnaireVO.QuestionnaireOptionVO optionVO = new QuestionnaireVO.QuestionnaireOptionVO();
                optionVO.setId(option.getId());
                optionVO.setOptionNo(option.getOptionNo());
                optionVO.setOptionText(option.getOptionText());
                optionVO.setOptionValue(option.getOptionValue());
                optionVOs.add(optionVO);
            }

            vo.setOptions(optionVOs);
            voList.add(vo);
        }

        return voList;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void submitQuestionnaire(SubmitQuestionnaireDTO dto, Long studentId) {
        // 检查问卷填写开关
        SystemConfig config = systemConfigMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(SYSTEM_CONFIG.CONFIG_KEY.eq("QUESTIONNAIRE_SWITCH"))
        );
        if (config != null && "OFF".equals(config.getConfigValue())) {
            throw new BusinessException("问卷填写已截止");
        }

        if (dto.getAnswers() == null || dto.getAnswers().isEmpty()) {
            throw new BusinessException("问卷答案不能为空");
        }

        // 检查是否已填写过
        long count = studentQuestionnaireMapper.selectCountByQuery(
                QueryWrapper.create()
                        .where(STUDENT_QUESTIONNAIRE.STUDENT_ID.eq(studentId))
        );
        if (count > 0) {
            throw new BusinessException("您已填写过问卷，不能重复提交");
        }

        // 保存答卷
        for (SubmitQuestionnaireDTO.AnswerItem answer : dto.getAnswers()) {
            StudentQuestionnaire sq = new StudentQuestionnaire();
            sq.setStudentId(studentId);
            sq.setQuestionId(answer.getQuestionId());
            sq.setOptionId(answer.getOptionId());
            studentQuestionnaireMapper.insert(sq);
        }

        log.info("学生 {} 提交问卷成功，共 {} 题", studentId, dto.getAnswers().size());
    }

    @Override
    public boolean hasSubmitted(Long studentId) {
        long count = studentQuestionnaireMapper.selectCountByQuery(
                QueryWrapper.create()
                        .where(STUDENT_QUESTIONNAIRE.STUDENT_ID.eq(studentId))
        );
        return count > 0;
    }
}