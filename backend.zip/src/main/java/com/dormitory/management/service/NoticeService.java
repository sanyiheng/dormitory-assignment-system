package com.dormitory.management.service;

import com.dormitory.management.dto.NoticeDTO;
import com.dormitory.management.dto.PageQueryDTO;
import com.dormitory.management.vo.NoticeVO;
import com.mybatisflex.core.paginate.Page;

/**
 * 通知公告服务接口
 */
public interface NoticeService {
    
    /**
     * 分页查询公告
     */
    Page<NoticeVO> pageQuery(PageQueryDTO pageQueryDTO);
    
    /**
     * 根据ID查询公告
     */
    NoticeVO getById(Long id);
    
    /**
     * 发布公告
     */
    void publish(NoticeDTO noticeDTO, Long publisherId, String publisherName);
    
    /**
     * 更新公告
     */
    void update(NoticeDTO noticeDTO);
    
    /**
     * 删除公告
     */
    void delete(Long id);
}




