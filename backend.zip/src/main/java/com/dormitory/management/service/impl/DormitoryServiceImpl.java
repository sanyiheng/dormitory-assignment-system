package com.dormitory.management.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.dormitory.management.common.Constants;
import com.dormitory.management.common.ResultCode;
import com.dormitory.management.dto.DormAssignDTO;
import com.dormitory.management.dto.DormitoryDTO;
import com.dormitory.management.dto.PageQueryDTO;
import com.dormitory.management.entity.Building;
import com.dormitory.management.entity.DormAssign;
import com.dormitory.management.entity.Dormitory;
import com.dormitory.management.exception.BusinessException;
import com.dormitory.management.mapper.BuildingMapper;
import com.dormitory.management.mapper.DormAssignMapper;
import com.dormitory.management.mapper.DormitoryMapper;
import com.dormitory.management.service.DormitoryService;
import com.dormitory.management.vo.DormitoryVO;
import com.mybatisflex.core.paginate.Page;
import com.mybatisflex.core.query.QueryWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

import static com.dormitory.management.entity.table.BuildingTableDef.BUILDING;
import static com.dormitory.management.entity.table.DormAssignTableDef.DORM_ASSIGN;
import static com.dormitory.management.entity.table.DormitoryTableDef.DORMITORY;

/**
 * 宿舍服务实现类
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DormitoryServiceImpl implements DormitoryService {
    
    private final DormitoryMapper dormitoryMapper;
    private final BuildingMapper buildingMapper;
    private final DormAssignMapper dormAssignMapper;
    
    @Override
    public Page<DormitoryVO> pageQuery(PageQueryDTO pageQueryDTO) {
        QueryWrapper wrapper = QueryWrapper.create()
                .select(DORMITORY.ALL_COLUMNS, BUILDING.BUILDING_NAME, BUILDING.BUILDING_NO)
                .from(DORMITORY)
                .leftJoin(BUILDING).on(DORMITORY.BUILDING_ID.eq(BUILDING.ID))
                .where(DORMITORY.IS_DELETED.eq(Constants.NOT_DELETED));
        
        // 关键词搜索（搜索楼栋名称或房间号）
        if (StrUtil.isNotBlank(pageQueryDTO.getKeyword())) {
            wrapper.and(BUILDING.BUILDING_NAME.like(pageQueryDTO.getKeyword())
                    .or(DORMITORY.ROOM_NO.like(pageQueryDTO.getKeyword())));
        }
        
        // 排序
        if (StrUtil.isNotBlank(pageQueryDTO.getSortField())) {
            if ("asc".equalsIgnoreCase(pageQueryDTO.getSortOrder())) {
                wrapper.orderBy(pageQueryDTO.getSortField(), true);
            } else {
                wrapper.orderBy(pageQueryDTO.getSortField(), false);
            }
        } else {
            wrapper.orderBy(BUILDING.BUILDING_NAME, true)
                    .orderBy(DORMITORY.FLOOR, true)
                    .orderBy(DORMITORY.ROOM_NO, true);
        }
        
        Page<Dormitory> page = dormitoryMapper.paginate(
                new Page<>(pageQueryDTO.getPageNum(), pageQueryDTO.getPageSize()),
                wrapper
        );
        
        // 转换为VO
        Page<DormitoryVO> voPage = new Page<>();
        voPage.setPageNumber(page.getPageNumber());
        voPage.setPageSize(page.getPageSize());
        voPage.setTotalRow(page.getTotalRow());
        voPage.setRecords(page.getRecords().stream().map(this::convertToVO).toList());
        
        return voPage;
    }
    
    @Override
    public DormitoryVO getById(Long id) {
        Dormitory dormitory = dormitoryMapper.selectOneById(id);
        if (dormitory == null || dormitory.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException(ResultCode.NOT_FOUND);
        }
        return convertToVO(dormitory);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void add(DormitoryDTO dormitoryDTO) {
        // 验证已住人数不能超过可住人数
        if (dormitoryDTO.getOccupied() > dormitoryDTO.getCapacity()) {
            throw new BusinessException("已住人数不能超过可住人数");
        }
        
        // 检查楼栋是否存在
        Building building = buildingMapper.selectOneById(dormitoryDTO.getBuildingId());
        if (building == null || building.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException("楼栋不存在");
        }
        
        // 检查同一楼栋的房间号是否已存在
        Dormitory existDorm = dormitoryMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(DORMITORY.BUILDING_ID.eq(dormitoryDTO.getBuildingId()))
                        .and(DORMITORY.ROOM_NO.eq(dormitoryDTO.getRoomNo()))
                        .and(DORMITORY.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        if (existDorm != null) {
            throw new BusinessException("该楼栋的房间号已存在");
        }
        
        Dormitory dormitory = BeanUtil.copyProperties(dormitoryDTO, Dormitory.class);
        
        // 设置状态
        dormitory.setStatus(calculateStatus(dormitory.getOccupied(), dormitory.getCapacity()));
        dormitory.setIsDeleted(Constants.NOT_DELETED);
        
        dormitoryMapper.insert(dormitory);
        log.info("新增宿舍成功：{}", dormitory);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(DormitoryDTO dormitoryDTO) {
        if (dormitoryDTO.getId() == null) {
            throw new BusinessException("宿舍ID不能为空");
        }
        
        // 验证已住人数不能超过可住人数
        if (dormitoryDTO.getOccupied() > dormitoryDTO.getCapacity()) {
            throw new BusinessException("已住人数不能超过可住人数");
        }
        
        Dormitory dormitory = dormitoryMapper.selectOneById(dormitoryDTO.getId());
        if (dormitory == null || dormitory.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException(ResultCode.NOT_FOUND);
        }
        
        // 检查楼栋是否存在
        Building building = buildingMapper.selectOneById(dormitoryDTO.getBuildingId());
        if (building == null || building.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException("楼栋不存在");
        }
        
        // 检查房间号是否与其他宿舍重复
        Dormitory existDorm = dormitoryMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(DORMITORY.BUILDING_ID.eq(dormitoryDTO.getBuildingId()))
                        .and(DORMITORY.ROOM_NO.eq(dormitoryDTO.getRoomNo()))
                        .and(DORMITORY.ID.ne(dormitoryDTO.getId()))
                        .and(DORMITORY.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        if (existDorm != null) {
            throw new BusinessException("该楼栋的房间号已存在");
        }
        
        BeanUtil.copyProperties(dormitoryDTO, dormitory, "id", "createTime", "isDeleted");
        
        // 更新状态
        dormitory.setStatus(calculateStatus(dormitory.getOccupied(), dormitory.getCapacity()));
        
        dormitoryMapper.update(dormitory);
        log.info("更新宿舍成功：{}", dormitory);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        Dormitory dormitory = dormitoryMapper.selectOneById(id);
        if (dormitory == null || dormitory.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException(ResultCode.NOT_FOUND);
        }
        
        // 检查是否还有学生在住
        if (dormitory.getOccupied() > 0) {
            throw new BusinessException("该宿舍还有学生入住，无法删除");
        }
        
        // 逻辑删除
        dormitory.setIsDeleted(Constants.IS_DELETED);
        dormitoryMapper.update(dormitory);
        log.info("删除宿舍成功，ID：{}", id);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void batchDelete(Long[] ids) {
        for (Long id : ids) {
            delete(id);
        }
    }
    
    @Override
    public List<DormitoryVO> getAvailableDormitories() {
        // 查询有空余床位的宿舍
        QueryWrapper wrapper = QueryWrapper.create()
                .select(DORMITORY.ALL_COLUMNS, BUILDING.BUILDING_NAME, BUILDING.BUILDING_NO)
                .from(DORMITORY)
                .leftJoin(BUILDING).on(DORMITORY.BUILDING_ID.eq(BUILDING.ID))
                .where(DORMITORY.IS_DELETED.eq(Constants.NOT_DELETED))
                .and(DORMITORY.STATUS.ne(0)) // 不是维修中
                .and(DORMITORY.OCCUPIED.lt(DORMITORY.CAPACITY)) // 还有空余床位
                .orderBy(BUILDING.BUILDING_NAME, true)
                .orderBy(DORMITORY.FLOOR, true)
                .orderBy(DORMITORY.ROOM_NO, true);
        
        List<Dormitory> dormitories = dormitoryMapper.selectListByQuery(wrapper);
        return dormitories.stream().map(this::convertToVO).toList();
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void assignDormitory(DormAssignDTO dormAssignDTO) {
        // 检查新宿舍是否存在
        Dormitory newDormitory = dormitoryMapper.selectOneById(dormAssignDTO.getDormitoryId());
        if (newDormitory == null || newDormitory.getIsDeleted() == Constants.IS_DELETED) {
            throw new BusinessException("宿舍不存在");
        }
        
        if (newDormitory.getStatus() == 0) {
            throw new BusinessException("该宿舍正在维修中，无法分配");
        }
        
        // 检查学生是否已经分配过宿舍
        DormAssign existAssign = dormAssignMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(DORM_ASSIGN.STUDENT_ID.eq(dormAssignDTO.getStudentId()))
                        .and(DORM_ASSIGN.STATUS.eq(1)) // 在住状态
                        .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        
        if (existAssign != null) {
            // 学生已有宿舍，执行更新操作
            Long oldDormitoryId = existAssign.getDormitoryId();
            
            // 如果是同一个宿舍，只更新床位号等信息
            if (oldDormitoryId.equals(dormAssignDTO.getDormitoryId())) {
                existAssign.setBedNo(dormAssignDTO.getBedNo());
                existAssign.setRemark(dormAssignDTO.getRemark());
                dormAssignMapper.update(existAssign);
                log.info("更新宿舍信息成功：学生ID={}, 宿舍ID={}", dormAssignDTO.getStudentId(), dormAssignDTO.getDormitoryId());
                return;
            }
            
            // 如果是不同宿舍，需要更新occupied
            // 检查新宿舍是否有空余床位
            if (newDormitory.getOccupied() >= newDormitory.getCapacity()) {
                throw new BusinessException("该宿舍床位已满，无法分配");
            }
            
            // 更新旧宿舍的占用数 -1
            Dormitory oldDormitory = dormitoryMapper.selectOneById(oldDormitoryId);
            if (oldDormitory != null) {
                oldDormitory.setOccupied(Math.max(0, oldDormitory.getOccupied() - 1));
                oldDormitory.setStatus(calculateStatus(oldDormitory.getOccupied(), oldDormitory.getCapacity()));
                dormitoryMapper.update(oldDormitory);
            }
            
            // 更新分配记录
            existAssign.setDormitoryId(dormAssignDTO.getDormitoryId());
            existAssign.setBedNo(dormAssignDTO.getBedNo());
            existAssign.setCheckInDate(dormAssignDTO.getCheckInDate() != null ? 
                    dormAssignDTO.getCheckInDate() : existAssign.getCheckInDate());
            existAssign.setRemark(dormAssignDTO.getRemark());
            dormAssignMapper.update(existAssign);
            
            // 更新新宿舍的占用数 +1
            newDormitory.setOccupied(newDormitory.getOccupied() + 1);
            newDormitory.setStatus(calculateStatus(newDormitory.getOccupied(), newDormitory.getCapacity()));
            dormitoryMapper.update(newDormitory);
            
            log.info("更换宿舍成功：学生ID={}, 旧宿舍ID={}, 新宿舍ID={}", 
                    dormAssignDTO.getStudentId(), oldDormitoryId, dormAssignDTO.getDormitoryId());
        } else {
            // 学生没有宿舍，执行新增操作
            // 检查新宿舍是否有空余床位
            if (newDormitory.getOccupied() >= newDormitory.getCapacity()) {
                throw new BusinessException("该宿舍床位已满，无法分配");
            }
            
            // 创建分配记录
            DormAssign dormAssign = new DormAssign();
            dormAssign.setStudentId(dormAssignDTO.getStudentId());
            dormAssign.setDormitoryId(dormAssignDTO.getDormitoryId());
            dormAssign.setBedNo(dormAssignDTO.getBedNo());
            dormAssign.setCheckInDate(dormAssignDTO.getCheckInDate() != null ? 
                    dormAssignDTO.getCheckInDate() : LocalDate.now());
            dormAssign.setStatus(1); // 在住
            dormAssign.setAssignType(dormAssignDTO.getAssignType() != null ? 
                    dormAssignDTO.getAssignType() : 1); // 默认手动分配
            dormAssign.setRemark(dormAssignDTO.getRemark());
            dormAssign.setIsDeleted(Constants.NOT_DELETED);
            
            dormAssignMapper.insert(dormAssign);
            
            // 更新新宿舍的占用数 +1
            newDormitory.setOccupied(newDormitory.getOccupied() + 1);
            newDormitory.setStatus(calculateStatus(newDormitory.getOccupied(), newDormitory.getCapacity()));
            dormitoryMapper.update(newDormitory);
            
            log.info("分配宿舍成功：学生ID={}, 宿舍ID={}", dormAssignDTO.getStudentId(), dormAssignDTO.getDormitoryId());
        }
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void unassignDormitory(Long studentId) {
        // 查询学生当前的宿舍分配记录
        DormAssign dormAssign = dormAssignMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(DORM_ASSIGN.STUDENT_ID.eq(studentId))
                        .and(DORM_ASSIGN.STATUS.eq(1)) // 在住状态
                        .and(DORM_ASSIGN.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        
        if (dormAssign == null) {
            return; // 没有分配记录，直接返回
        }
        
        // 更新分配记录为已退宿
        dormAssign.setStatus(0); // 已退宿
        dormAssign.setCheckOutDate(LocalDate.now());
        dormAssignMapper.update(dormAssign);
        
        // 更新宿舍已住人数和状态
        Dormitory dormitory = dormitoryMapper.selectOneById(dormAssign.getDormitoryId());
        if (dormitory != null) {
            dormitory.setOccupied(Math.max(0, dormitory.getOccupied() - 1));
            dormitory.setStatus(calculateStatus(dormitory.getOccupied(), dormitory.getCapacity()));
            dormitoryMapper.update(dormitory);
        }
        
        log.info("取消宿舍分配成功：学生ID={}", studentId);
    }
    
    /**
     * 转换为VO
     */
    private DormitoryVO convertToVO(Dormitory dormitory) {
        DormitoryVO vo = BeanUtil.copyProperties(dormitory, DormitoryVO.class);
        
        // 查询楼栋信息
        Building building = buildingMapper.selectOneById(dormitory.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getBuildingName());
            vo.setBuildingNo(building.getBuildingNo());
        }
        
        // 计算剩余床位
        vo.setAvailable(dormitory.getCapacity() - dormitory.getOccupied());
        
        // 设置状态文本
        vo.setStatusText(getStatusText(dormitory.getStatus()));
        
        return vo;
    }
    
    /**
     * 计算宿舍状态
     */
    private Integer calculateStatus(Integer occupied, Integer capacity) {
        if (occupied >= capacity) {
            return 2; // 已满
        } else {
            return 1; // 正常
        }
    }
    
    /**
     * 获取状态文本
     */
    private String getStatusText(Integer status) {
        return switch (status) {
            case 0 -> "维修中";
            case 1 -> "正常";
            case 2 -> "已满";
            default -> "未知";
        };
    }
}

