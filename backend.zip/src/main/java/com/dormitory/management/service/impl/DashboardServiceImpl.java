package com.dormitory.management.service.impl;

import com.dormitory.management.common.Constants;
import com.dormitory.management.mapper.DormitoryMapper;
import com.dormitory.management.mapper.NoticeMapper;
import com.dormitory.management.mapper.StudentMapper;
import com.dormitory.management.service.DashboardService;
import com.dormitory.management.vo.DashboardVO;
import com.mybatisflex.core.query.QueryWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import static com.dormitory.management.entity.table.DormitoryTableDef.DORMITORY;
import static com.dormitory.management.entity.table.NoticeTableDef.NOTICE;
import static com.dormitory.management.entity.table.StudentTableDef.STUDENT;

/**
 * 仪表盘服务实现类
 * 改造：移除报修相关统计，改为宿舍分配相关统计
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final StudentMapper studentMapper;
    private final DormitoryMapper dormitoryMapper;
    private final NoticeMapper noticeMapper;

    @Override
    public DashboardVO getDashboardData() {
        DashboardVO dashboardVO = new DashboardVO();

        // 获取统计数据
        dashboardVO.setStatistics(getStatistics());

        return dashboardVO;
    }

    /**
     * 获取统计数据
     */
    private DashboardVO.StatisticsData getStatistics() {
        DashboardVO.StatisticsData statistics = new DashboardVO.StatisticsData();

        // 学生总数
        long studentCount = studentMapper.selectCountByQuery(
                QueryWrapper.create()
                        .where(STUDENT.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        statistics.setStudentCount((int) studentCount);

        // 宿舍总数
        long dormitoryCount = dormitoryMapper.selectCountByQuery(
                QueryWrapper.create()
                        .where(DORMITORY.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        statistics.setDormitoryCount((int) dormitoryCount);

        // 公告数量
        long noticeCount = noticeMapper.selectCountByQuery(
                QueryWrapper.create()
                        .where(NOTICE.IS_DELETED.eq(Constants.NOT_DELETED))
        );
        statistics.setNoticeCount((int) noticeCount);

        return statistics;
    }
}