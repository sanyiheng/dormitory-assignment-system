package com.dormitory.management.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.io.Serializable;

/**
 * 报修处理DTO
 */
@Data
@Schema(description = "报修处理请求对象")
public class RepairHandleDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @NotNull(message = "报修ID不能为空")
    @Schema(description = "报修ID")
    private Long id;
    
    @NotNull(message = "处理状态不能为空")
    @Schema(description = "处理状态：1-接受，2-处理中，3-完成，4-拒绝")
    private Integer status;
    
    @Schema(description = "处理备注")
    private String handlerRemark;
    
    @Schema(description = "拒绝原因（拒绝时必填）")
    private String rejectReason;
}


