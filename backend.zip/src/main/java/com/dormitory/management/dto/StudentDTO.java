package com.dormitory.management.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * 学生DTO
 */
@Data
@Schema(description = "学生信息请求对象")
public class StudentDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @Schema(description = "学生ID（更新时使用）")
    private Long id;

    @Schema(description = "学号（新生可为空）")
    private String studentNo;

    @Schema(description = "密码（新增时必填）")
    private String password;

    @NotBlank(message = "姓名不能为空")
    @Schema(description = "姓名")
    private String name;

    @NotNull(message = "性别不能为空")
    @Schema(description = "性别：0-女，1-男")
    private Integer gender;

    @Schema(description = "联系电话")
    private String phone;

    @Email(message = "邮箱格式不正确")
    @Schema(description = "邮箱")
    private String email;

    @NotBlank(message = "身份证号不能为空")
    @Schema(description = "身份证号（学生登录账号）")
    private String idCard;

    @Schema(description = "头像URL")
    private String avatar;

    @Schema(description = "班级")
    private String className;

    @Schema(description = "专业")
    private String major;

    @Schema(description = "年级")
    private String grade;

    @Schema(description = "入学日期")
    private LocalDate enrollmentDate;

    @Schema(description = "状态：0-禁用，1-启用")
    private Integer status;
}