package com.dormitory.management.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;
import java.util.List;

/**
 * 提交问卷DTO
 */
@Data
@Schema(description = "提交问卷请求参数")
public class SubmitQuestionnaireDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @Schema(description = "答卷列表")
    private List<AnswerItem> answers;

    /**
     * 单个题目答案
     */
    @Data
    @Schema(description = "单个题目答案")
    public static class AnswerItem implements Serializable {

        @Schema(description = "题目ID")
        private Long questionId;

        @Schema(description = "选中的选项ID")
        private Long optionId;
    }
}