package com.dormitory.management.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 公告DTO
 */
@Data
@Schema(description = "公告请求对象")
public class NoticeDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Schema(description = "公告ID（更新时使用）")
    private Long id;
    
    @NotBlank(message = "公告标题不能为空")
    @Schema(description = "公告标题")
    private String title;
    
    @NotBlank(message = "公告内容不能为空")
    @Schema(description = "公告内容")
    private String content;
    
    @Schema(description = "公告类型：SYSTEM-系统公告，ACTIVITY-活动通知，MAINTENANCE-维修通知")
    private String noticeType;
    
    @Schema(description = "优先级：0-低，1-中，2-高")
    private Integer priority;
    
    @Schema(description = "目标角色：ALL-所有人，STUDENT-学生，ADMIN-管理员")
    private String targetRole;
    
    @Schema(description = "是否置顶：0-否，1-是")
    private Integer isTop;
    
    @Schema(description = "过期时间")
    private LocalDateTime expireTime;
    
    @Schema(description = "状态：0-草稿，1-已发布")
    private Integer status;
}


