package com.dormitory.management.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 报修审核DTO
 */
@Data
@Schema(description = "报修审核DTO")
public class RepairAuditDTO {

    @NotNull(message = "报修ID不能为空")
    @Schema(description = "报修ID")
    private Long id;

    @NotNull(message = "审核结果不能为空")
    @Schema(description = "审核结果：1-通过（接受），4-拒绝")
    private Integer status;

    @Schema(description = "指定的维修人员ID（通过时必填）")
    private Long handlerId;

    @Schema(description = "拒绝原因（拒绝时必填）")
    private String rejectReason;
}



