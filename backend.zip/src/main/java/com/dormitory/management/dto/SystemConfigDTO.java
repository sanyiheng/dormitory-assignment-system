package com.dormitory.management.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;

/**
 * 系统配置DTO
 */
@Data
@Schema(description = "系统配置请求参数")
public class SystemConfigDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @Schema(description = "配置键")
    private String configKey;

    @Schema(description = "配置值")
    private String configValue;
}