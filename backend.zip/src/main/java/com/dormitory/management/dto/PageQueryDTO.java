package com.dormitory.management.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;

/**
 * 分页查询DTO
 */
@Data
@Schema(description = "分页查询请求对象")
public class PageQueryDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Schema(description = "当前页码", example = "1")
    private Integer pageNum = 1;
    
    @Schema(description = "每页大小", example = "10")
    private Integer pageSize = 10;
    
    @Schema(description = "关键词搜索")
    private String keyword;
    
    @Schema(description = "排序字段")
    private String sortField;
    
    @Schema(description = "排序方式：asc-升序，desc-降序")
    private String sortOrder;
}


