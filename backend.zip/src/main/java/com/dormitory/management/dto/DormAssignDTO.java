package com.dormitory.management.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * 宿舍分配DTO
 */
@Data
@Schema(description = "宿舍分配请求对象")
public class DormAssignDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @NotNull(message = "学生ID不能为空")
    @Schema(description = "学生ID")
    private Long studentId;
    
    @NotNull(message = "宿舍ID不能为空")
    @Schema(description = "宿舍ID")
    private Long dormitoryId;
    
    @Schema(description = "床位号")
    private String bedNo;
    
    @NotNull(message = "入住日期不能为空")
    @Schema(description = "入住日期")
    private LocalDate checkInDate;
    
    @Schema(description = "分配类型：0-自动分配，1-手动分配，2-调整分配")
    private Integer assignType;
    
    @Schema(description = "备注")
    private String remark;
}


