package com.dormitory.management.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.io.Serializable;

/**
 * 宿舍DTO
 */
@Data
@Schema(description = "宿舍请求对象")
public class DormitoryDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Schema(description = "宿舍ID（更新时必填）")
    private Long id;
    
    @NotNull(message = "楼栋ID不能为空")
    @Schema(description = "楼栋ID")
    private Long buildingId;
    
    @NotBlank(message = "房间号不能为空")
    @Schema(description = "房间号")
    private String roomNo;
    
    @NotNull(message = "楼层不能为空")
    @Schema(description = "楼层")
    private Integer floor;
    
    @NotNull(message = "可住人数不能为空")
    @Min(value = 1, message = "可住人数至少为1")
    @Schema(description = "可住人数")
    private Integer capacity;
    
    @NotNull(message = "已住人数不能为空")
    @Min(value = 0, message = "已住人数不能为负数")
    @Schema(description = "已住人数")
    private Integer occupied;
    
    @Schema(description = "房间类型：STANDARD-标准间，DELUXE-豪华间")
    private String roomType;
    
    @Schema(description = "设施说明")
    private String facilities;
}



