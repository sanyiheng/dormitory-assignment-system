package com.dormitory.management.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.dormitory.management.common.Result;
import com.dormitory.management.dto.ChangePasswordDTO;
import com.dormitory.management.dto.LoginDTO;
import com.dormitory.management.dto.RegisterDTO;
import com.dormitory.management.service.AuthService;
import com.dormitory.management.vo.LoginVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

/**
 * 认证控制器
 */
@Tag(name = "认证管理")
@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {
    
    private final AuthService authService;
    private final StringRedisTemplate redisTemplate;
    
    @Operation(summary = "用户登录")
    @PostMapping("/login")
    public Result<LoginVO> login(@Valid @RequestBody LoginDTO loginDTO) {
        LoginVO loginVO = authService.login(loginDTO);
        return Result.success(loginVO);
    }
    
    @Operation(summary = "用户注册（学生/维修人员）")
    @PostMapping("/register")
    public Result<String> register(@Valid @RequestBody RegisterDTO registerDTO) {
        authService.register(registerDTO);
        return Result.success("注册成功");
    }
    
    @Operation(summary = "用户登出")
    @PostMapping("/logout")
    public Result<Void> logout() {
        authService.logout();
        return Result.success();
    }
    
    @Operation(summary = "获取当前用户信息")
    @GetMapping("/current")
    public Result<LoginVO> getCurrentUser() {
        LoginVO loginVO = authService.getCurrentUser();
        return Result.success(loginVO);
    }
    
    @Operation(summary = "修改密码")
    @PostMapping("/changePassword")
    public Result<Void> changePassword(@Valid @RequestBody ChangePasswordDTO changePasswordDTO) {
        Long userId = StpUtil.getLoginIdAsLong();
        String userTypeKey = "user:type:" + userId;
        String userType = redisTemplate.opsForValue().get(userTypeKey);
        
        authService.changePassword(userId, userType, changePasswordDTO.getOldPassword(), changePasswordDTO.getNewPassword());
        return Result.success();
    }
}


