package com.dormitory.management.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.dormitory.management.common.Result;
import com.dormitory.management.dto.NoticeDTO;
import com.dormitory.management.dto.PageQueryDTO;
import com.dormitory.management.service.NoticeService;
import com.dormitory.management.vo.NoticeVO;
import com.mybatisflex.core.paginate.Page;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 通知公告控制器
 */
@Tag(name = "公告管理")
@RestController
@RequestMapping("/notice")
@RequiredArgsConstructor
public class NoticeController {
    
    private final NoticeService noticeService;
    
    @Operation(summary = "分页查询公告")
    @GetMapping("/page")
    public Result<Page<NoticeVO>> pageQuery(PageQueryDTO pageQueryDTO) {
        Page<NoticeVO> page = noticeService.pageQuery(pageQueryDTO);
        return Result.success(page);
    }
    
    @Operation(summary = "根据ID查询公告")
    @GetMapping("/{id}")
    public Result<NoticeVO> getById(@PathVariable Long id) {
        NoticeVO noticeVO = noticeService.getById(id);
        return Result.success(noticeVO);
    }
    
    @Operation(summary = "发布公告")
    @PostMapping("/publish")
    public Result<Void> publish(@Valid @RequestBody NoticeDTO noticeDTO) {
        Long publisherId = StpUtil.getLoginIdAsLong();
        // 从 session 或前端传递获取发布人姓名
        String publisherName = (String) StpUtil.getSession().get("realName");
        if (publisherName == null) {
            publisherName = "系统管理员"; // 默认值
        }
        noticeService.publish(noticeDTO, publisherId, publisherName);
        return Result.success();
    }
    
    @Operation(summary = "更新公告")
    @PutMapping
    public Result<Void> update(@Valid @RequestBody NoticeDTO noticeDTO) {
        noticeService.update(noticeDTO);
        return Result.success();
    }
    
    @Operation(summary = "删除公告")
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        noticeService.delete(id);
        return Result.success();
    }
}


