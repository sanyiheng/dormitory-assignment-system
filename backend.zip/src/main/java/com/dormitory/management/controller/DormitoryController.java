package com.dormitory.management.controller;

import com.dormitory.management.common.Result;
import com.dormitory.management.dto.DormAssignDTO;
import com.dormitory.management.dto.DormitoryDTO;
import com.dormitory.management.dto.PageQueryDTO;
import com.dormitory.management.service.DormitoryService;
import com.dormitory.management.vo.DormitoryVO;
import com.mybatisflex.core.paginate.Page;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 宿舍管理控制器
 */
@Tag(name = "宿舍管理")
@RestController
@RequestMapping("/dormitory")
@RequiredArgsConstructor
public class DormitoryController {
    
    private final DormitoryService dormitoryService;
    
    @Operation(summary = "分页查询宿舍")
    @GetMapping("/page")
    public Result<Page<DormitoryVO>> pageQuery(PageQueryDTO pageQueryDTO) {
        Page<DormitoryVO> page = dormitoryService.pageQuery(pageQueryDTO);
        return Result.success(page);
    }
    
    @Operation(summary = "根据ID查询宿舍")
    @GetMapping("/{id}")
    public Result<DormitoryVO> getById(@PathVariable Long id) {
        DormitoryVO dormitoryVO = dormitoryService.getById(id);
        return Result.success(dormitoryVO);
    }
    
    @Operation(summary = "新增宿舍")
    @PostMapping
    public Result<Void> add(@Valid @RequestBody DormitoryDTO dormitoryDTO) {
        dormitoryService.add(dormitoryDTO);
        return Result.success();
    }
    
    @Operation(summary = "更新宿舍")
    @PutMapping
    public Result<Void> update(@Valid @RequestBody DormitoryDTO dormitoryDTO) {
        dormitoryService.update(dormitoryDTO);
        return Result.success();
    }
    
    @Operation(summary = "删除宿舍")
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        dormitoryService.delete(id);
        return Result.success();
    }
    
    @Operation(summary = "批量删除宿舍")
    @DeleteMapping("/batch")
    public Result<Void> batchDelete(@RequestBody Long[] ids) {
        dormitoryService.batchDelete(ids);
        return Result.success();
    }
    
    @Operation(summary = "获取可用宿舍列表")
    @GetMapping("/available")
    public Result<List<DormitoryVO>> getAvailableDormitories() {
        List<DormitoryVO> list = dormitoryService.getAvailableDormitories();
        return Result.success(list);
    }
    
    @Operation(summary = "分配宿舍")
    @PostMapping("/assign")
    public Result<Void> assignDormitory(@Valid @RequestBody DormAssignDTO dormAssignDTO) {
        dormitoryService.assignDormitory(dormAssignDTO);
        return Result.success();
    }
    
    @Operation(summary = "取消宿舍分配")
    @DeleteMapping("/unassign/{studentId}")
    public Result<Void> unassignDormitory(@PathVariable Long studentId) {
        dormitoryService.unassignDormitory(studentId);
        return Result.success();
    }
}



