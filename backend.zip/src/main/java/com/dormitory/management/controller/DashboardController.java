package com.dormitory.management.controller;

import com.dormitory.management.common.Result;
import com.dormitory.management.service.DashboardService;
import com.dormitory.management.vo.DashboardVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 仪表盘控制器
 */
@Tag(name = "仪表盘管理")
@RestController
@RequestMapping("/dashboard")
@RequiredArgsConstructor
public class DashboardController {
    
    private final DashboardService dashboardService;
    
    @Operation(summary = "获取仪表盘数据")
    @GetMapping("/data")
    public Result<DashboardVO> getDashboardData() {
        DashboardVO dashboardVO = dashboardService.getDashboardData();
        return Result.success(dashboardVO);
    }
}



