package com.dormitory.management.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.dormitory.management.common.Result;
import com.dormitory.management.service.AssignmentService;
import com.dormitory.management.vo.AssignmentResultVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 宿舍分配控制器
 */
@Slf4j
@RestController
@RequestMapping("/assignment")
@RequiredArgsConstructor
@Tag(name = "宿舍分配", description = "智能分配算法相关接口")
public class AssignmentController {

    private final AssignmentService assignmentService;

    /**
     * 执行自动分配
     */
    @PostMapping("/execute")
    @Operation(summary = "执行分配", description = "执行宿舍智能分配算法")
    public Result<Integer> executeAssignment() {
        int count = assignmentService.executeAssignment();
        return Result.success(count);
    }

    /**
     * 获取分配结果列表（管理员用）
     */
    @GetMapping("/results")
    @Operation(summary = "获取分配结果", description = "获取所有分配结果")
    public Result<List<AssignmentResultVO>> getResults() {
        List<AssignmentResultVO> results = assignmentService.getAssignmentResults();
        return Result.success(results);
    }

    /**
     * 获取当前学生的分配结果
     */
    @GetMapping("/my")
    @Operation(summary = "我的分配结果", description = "获取当前登录学生的宿舍分配结果")
    public Result<AssignmentResultVO> getMyAssignment() {
        Long studentId = StpUtil.getLoginIdAsLong();
        AssignmentResultVO result = assignmentService.getMyAssignment(studentId);
        return Result.success(result);
    }
}