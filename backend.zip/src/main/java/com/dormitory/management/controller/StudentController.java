package com.dormitory.management.controller;

import com.dormitory.management.common.Result;
import com.dormitory.management.dto.PageQueryDTO;
import com.dormitory.management.dto.StudentDTO;
import com.dormitory.management.service.StudentService;
import com.dormitory.management.vo.StudentDormInfoVO;
import com.dormitory.management.vo.StudentHomeVO;
import com.dormitory.management.vo.StudentVO;
import com.mybatisflex.core.paginate.Page;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 学生管理控制器
 */
@Tag(name = "学生管理")
@RestController
@RequestMapping("/student")
@RequiredArgsConstructor
public class StudentController {
    
    private final StudentService studentService;
    
    @Operation(summary = "分页查询学生")
    @GetMapping("/page")
    public Result<Page<StudentVO>> pageQuery(PageQueryDTO pageQueryDTO) {
        Page<StudentVO> page = studentService.pageQuery(pageQueryDTO);
        return Result.success(page);
    }
    
    @Operation(summary = "根据ID查询学生")
    @GetMapping("/{id}")
    public Result<StudentVO> getById(@PathVariable Long id) {
        StudentVO studentVO = studentService.getById(id);
        return Result.success(studentVO);
    }
    
    @Operation(summary = "新增学生")
    @PostMapping
    public Result<Void> add(@Valid @RequestBody StudentDTO studentDTO) {
        studentService.add(studentDTO);
        return Result.success();
    }
    
    @Operation(summary = "更新学生")
    @PutMapping
    public Result<Void> update(@Valid @RequestBody StudentDTO studentDTO) {
        studentService.update(studentDTO);
        return Result.success();
    }
    
    @Operation(summary = "删除学生")
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        studentService.delete(id);
        return Result.success();
    }
    
    @Operation(summary = "批量删除学生")
    @DeleteMapping("/batch")
    public Result<Void> batchDelete(@RequestBody Long[] ids) {
        studentService.batchDelete(ids);
        return Result.success();
    }
    
    @Operation(summary = "修改密码")
    @PutMapping("/password")
    public Result<Void> changePassword(@RequestParam Long id, 
                                       @RequestParam String oldPassword,
                                       @RequestParam String newPassword) {
        studentService.changePassword(id, oldPassword, newPassword);
        return Result.success();
    }
    
    @Operation(summary = "获取学生首页信息")
    @GetMapping("/home/{studentId}")
    public Result<StudentHomeVO> getStudentHomeInfo(@PathVariable Long studentId) {
        StudentHomeVO homeInfo = studentService.getStudentHomeInfo(studentId);
        return Result.success(homeInfo);
    }
    
    @Operation(summary = "获取学生宿舍信息（包括室友）")
    @GetMapping("/dorm/{studentId}")
    public Result<StudentDormInfoVO> getStudentDormInfo(@PathVariable Long studentId) {
        StudentDormInfoVO dormInfo = studentService.getStudentDormInfo(studentId);
        return Result.success(dormInfo);
    }
}


