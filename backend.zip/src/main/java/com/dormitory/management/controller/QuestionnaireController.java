package com.dormitory.management.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.dormitory.management.common.Result;
import com.dormitory.management.dto.SubmitQuestionnaireDTO;
import com.dormitory.management.service.QuestionnaireService;
import com.dormitory.management.vo.QuestionnaireVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 问卷控制器
 */
@Slf4j
@RestController
@RequestMapping("/questionnaire")
@RequiredArgsConstructor
@Tag(name = "问卷管理", description = "问卷获取和提交相关接口")
public class QuestionnaireController {

    private final QuestionnaireService questionnaireService;

    /**
     * 获取问卷列表（含选项）
     */
    @GetMapping("/list")
    @Operation(summary = "获取问卷列表", description = "获取所有问卷题目和选项")
    public Result<List<QuestionnaireVO>> getQuestionnaireList() {
        List<QuestionnaireVO> list = questionnaireService.getQuestionnaireList();
        return Result.success(list);
    }

    /**
     * 提交问卷
     */
    @PostMapping("/submit")
    @Operation(summary = "提交问卷", description = "学生提交问卷答案")
    public Result<Void> submitQuestionnaire(@RequestBody SubmitQuestionnaireDTO dto) {
        Long studentId = StpUtil.getLoginIdAsLong();
        questionnaireService.submitQuestionnaire(dto, studentId);
        return Result.success(null);
    }

    /**
     * 检查是否已填写问卷
     */
    @GetMapping("/check")
    @Operation(summary = "检查是否已填写", description = "检查当前登录学生是否已填写问卷")
    public Result<Boolean> checkSubmitted() {
        Long studentId = StpUtil.getLoginIdAsLong();
        boolean submitted = questionnaireService.hasSubmitted(studentId);
        return Result.success(submitted);
    }
}