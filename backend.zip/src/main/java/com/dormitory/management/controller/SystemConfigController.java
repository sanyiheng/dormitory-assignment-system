package com.dormitory.management.controller;

import com.dormitory.management.common.Result;
import com.dormitory.management.dto.SystemConfigDTO;
import com.dormitory.management.mapper.SystemConfigMapper;
import com.dormitory.management.entity.SystemConfig;
import com.mybatisflex.core.query.QueryWrapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.dormitory.management.entity.table.SystemConfigTableDef.SYSTEM_CONFIG;

/**
 * 系统配置控制器
 */
@RestController
@RequestMapping("/system-config")
@RequiredArgsConstructor
@Tag(name = "系统配置", description = "系统开关管理接口")
public class SystemConfigController {

    private final SystemConfigMapper systemConfigMapper;

    /**
     * 获取所有系统配置
     */
    @GetMapping("/list")
    @Operation(summary = "获取所有配置", description = "获取系统所有开关配置")
    public Result<List<SystemConfig>> getAllConfigs() {
        List<SystemConfig> configs = systemConfigMapper.selectAll();
        return Result.success(configs);
    }

    /**
     * 更新配置
     */
    @PutMapping("/update")
    @Operation(summary = "更新配置", description = "更新系统开关配置")
    public Result<Void> updateConfig(@RequestBody SystemConfigDTO dto) {
        SystemConfig config = systemConfigMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(SYSTEM_CONFIG.CONFIG_KEY.eq(dto.getConfigKey()))
        );

        if (config != null) {
            config.setConfigValue(dto.getConfigValue());
            systemConfigMapper.update(config);
        }

        return Result.success(null);
    }

    /**
     * 获取系统总开关状态
     */
    @GetMapping("/switch")
    @Operation(summary = "获取系统开关", description = "获取系统总开关状态")
    public Result<String> getSystemSwitch() {
        SystemConfig config = systemConfigMapper.selectOneByQuery(
                QueryWrapper.create()
                        .where(SYSTEM_CONFIG.CONFIG_KEY.eq("SYSTEM_SWITCH"))
        );
        return Result.success(config != null ? config.getConfigValue() : "OFF");
    }
}