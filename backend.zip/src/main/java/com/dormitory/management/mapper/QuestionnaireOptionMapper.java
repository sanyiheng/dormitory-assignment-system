package com.dormitory.management.mapper;

import com.dormitory.management.entity.QuestionnaireOption;
import com.mybatisflex.core.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 问卷选项Mapper
 */
@Mapper
public interface QuestionnaireOptionMapper extends BaseMapper<QuestionnaireOption> {
}