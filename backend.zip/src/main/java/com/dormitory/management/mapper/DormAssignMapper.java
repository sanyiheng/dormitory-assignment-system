package com.dormitory.management.mapper;

import com.dormitory.management.entity.DormAssign;
import com.mybatisflex.core.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 宿舍分配Mapper
 */
@Mapper
public interface DormAssignMapper extends BaseMapper<DormAssign> {
}




