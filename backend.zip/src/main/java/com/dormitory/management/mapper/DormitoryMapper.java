package com.dormitory.management.mapper;

import com.dormitory.management.entity.Dormitory;
import com.mybatisflex.core.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 宿舍Mapper
 */
@Mapper
public interface DormitoryMapper extends BaseMapper<Dormitory> {
}




