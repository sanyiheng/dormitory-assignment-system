package com.dormitory.management.mapper;

import com.dormitory.management.entity.Questionnaire;
import com.mybatisflex.core.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 问卷题目Mapper
 */
@Mapper
public interface QuestionnaireMapper extends BaseMapper<Questionnaire> {
}