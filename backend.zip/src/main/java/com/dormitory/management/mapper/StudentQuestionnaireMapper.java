package com.dormitory.management.mapper;

import com.dormitory.management.entity.StudentQuestionnaire;
import com.mybatisflex.core.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 学生问卷记录Mapper
 */
@Mapper
public interface StudentQuestionnaireMapper extends BaseMapper<StudentQuestionnaire> {
}