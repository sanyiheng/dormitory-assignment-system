package com.dormitory.management.mapper;

import com.dormitory.management.entity.MessageNotification;
import com.mybatisflex.core.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 消息通知Mapper
 */
@Mapper
public interface MessageNotificationMapper extends BaseMapper<MessageNotification> {
}




