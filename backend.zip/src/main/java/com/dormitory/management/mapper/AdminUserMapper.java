package com.dormitory.management.mapper;

import com.dormitory.management.entity.AdminUser;
import com.mybatisflex.core.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 管理员Mapper
 */
@Mapper
public interface AdminUserMapper extends BaseMapper<AdminUser> {
}




