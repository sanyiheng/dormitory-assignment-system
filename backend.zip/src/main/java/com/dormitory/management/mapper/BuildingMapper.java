package com.dormitory.management.mapper;

import com.dormitory.management.entity.Building;
import com.mybatisflex.core.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 宿舍楼Mapper
 */
@Mapper
public interface BuildingMapper extends BaseMapper<Building> {
}




