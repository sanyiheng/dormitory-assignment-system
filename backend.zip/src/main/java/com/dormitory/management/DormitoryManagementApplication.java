package com.dormitory.management;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * 学生宿舍管理系统主启动类
 *
 * @author Dormitory Management Team
 * @since 2024
 */
@EnableAsync
@SpringBootApplication
@MapperScan("com.dormitory.management.mapper")
public class DormitoryManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(DormitoryManagementApplication.class, args);
        System.out.println("""
            
            =====================================================
                学生宿舍管理系统启动成功！
                接口文档地址：http://localhost:8080/api/doc.html
            =====================================================
            """);
    }
}


