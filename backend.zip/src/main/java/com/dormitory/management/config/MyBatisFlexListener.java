package com.dormitory.management.config;

import com.mybatisflex.annotation.InsertListener;
import com.mybatisflex.annotation.UpdateListener;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.time.LocalDateTime;

/**
 * MyBatis-Flex 监听器
 * 自动填充 create_time 和 update_time
 */
@Slf4j
public class MyBatisFlexListener implements InsertListener, UpdateListener {

    /**
     * 插入前自动填充 createTime 和 updateTime
     */
    @Override
    public void onInsert(Object entity) {
        fillTimeFields(entity, true);
    }

    /**
     * 更新前自动填充 updateTime
     */
    @Override
    public void onUpdate(Object entity) {
        fillTimeFields(entity, false);
    }

    /**
     * 填充时间字段
     * @param entity 实体对象
     * @param isInsert 是否为插入操作
     */
    private void fillTimeFields(Object entity, boolean isInsert) {
        try {
            Class<?> clazz = entity.getClass();
            LocalDateTime now = LocalDateTime.now();

            // 插入时填充 createTime
            if (isInsert) {
                try {
                    Field createTimeField = clazz.getDeclaredField("createTime");
                    createTimeField.setAccessible(true);
                    if (createTimeField.get(entity) == null) {
                        createTimeField.set(entity, now);
                    }
                } catch (NoSuchFieldException e) {
                    // 该实体没有 createTime 字段，忽略
                }
            }

            // 插入和更新时都填充 updateTime
            try {
                Field updateTimeField = clazz.getDeclaredField("updateTime");
                updateTimeField.setAccessible(true);
                updateTimeField.set(entity, now);
            } catch (NoSuchFieldException e) {
                // 该实体没有 updateTime 字段，忽略
            }

        } catch (Exception e) {
            log.warn("自动填充时间字段失败: {}", e.getMessage());
        }
    }
}



