package com.dormitory.management.config;

import com.mybatisflex.core.audit.AuditManager;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;


/**
 * MyBatis-Flex 配置类
 */
@Slf4j
@Configuration
public class MyBatisFlexConfiguration {

    /**
     * 配置全局审计
     */
    @PostConstruct
    public void init() {
        // 开启审计功能
        AuditManager.setAuditEnable(true);
        
        // SQL 执行日志（开发环境可开启）
        AuditManager.setMessageCollector(auditMessage -> {
            log.debug("SQL执行: {}, 耗时: {}ms", 
                auditMessage.getFullSql(), 
                auditMessage.getElapsedTime());
        });
        
        log.info("MyBatis-Flex 全局配置已加载：自动填充时间字段");
    }
}

