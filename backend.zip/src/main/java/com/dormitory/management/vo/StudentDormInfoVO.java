package com.dormitory.management.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

/**
 * 学生宿舍信息VO
 */
@Data
@Schema(description = "学生宿舍信息响应对象")
public class StudentDormInfoVO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Schema(description = "宿舍分配ID")
    private Long assignId;
    
    @Schema(description = "宿舍ID")
    private Long dormitoryId;
    
    @Schema(description = "楼栋ID")
    private Long buildingId;
    
    @Schema(description = "楼栋名称")
    private String buildingName;
    
    @Schema(description = "楼栋编号")
    private String buildingNo;
    
    @Schema(description = "房间号")
    private String roomNo;
    
    @Schema(description = "楼层")
    private Integer floor;
    
    @Schema(description = "床位号")
    private String bedNo;
    
    @Schema(description = "入住日期")
    private LocalDate checkInDate;
    
    @Schema(description = "可住人数")
    private Integer capacity;
    
    @Schema(description = "已住人数")
    private Integer occupied;
    
    @Schema(description = "房间类型")
    private String roomType;
    
    @Schema(description = "设施说明")
    private String facilities;
    
    @Schema(description = "室友列表")
    private List<RoommateVO> roommates;
}



