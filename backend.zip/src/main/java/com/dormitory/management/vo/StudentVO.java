package com.dormitory.management.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 学生VO
 */
@Data
@Schema(description = "学生信息响应对象")
public class StudentVO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Schema(description = "学生ID")
    private Long id;
    
    @Schema(description = "学号")
    private String studentNo;
    
    @Schema(description = "姓名")
    private String name;
    
    @Schema(description = "性别：0-女，1-男")
    private Integer gender;
    
    @Schema(description = "性别文本")
    private String genderText;
    
    @Schema(description = "联系电话")
    private String phone;
    
    @Schema(description = "邮箱")
    private String email;
    
    @Schema(description = "身份证号")
    private String idCard;
    
    @Schema(description = "头像URL")
    private String avatar;
    
    @Schema(description = "班级")
    private String className;
    
    @Schema(description = "专业")
    private String major;
    
    @Schema(description = "年级")
    private String grade;
    
    @Schema(description = "入学日期")
    private LocalDate enrollmentDate;
    
    @Schema(description = "状态：0-禁用，1-启用")
    private Integer status;
    
    @Schema(description = "状态文本")
    private String statusText;
    
    @Schema(description = "宿舍信息")
    private String dormitoryInfo;
    
    @Schema(description = "创建时间")
    private LocalDateTime createTime;
}


