package com.dormitory.management.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;
import java.util.List;

/**
 * 问卷题目VO（包含选项列表）
 */
@Data
@Schema(description = "问卷题目响应对象")
public class QuestionnaireVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @Schema(description = "题目ID")
    private Long id;

    @Schema(description = "题号")
    private String questionNo;

    @Schema(description = "题目内容")
    private String questionText;

    @Schema(description = "维度")
    private String dimension;

    @Schema(description = "排序")
    private Integer sortOrder;

    @Schema(description = "选项列表")
    private List<QuestionnaireOptionVO> options;

    /**
     * 选项VO
     */
    @Data
    @Schema(description = "问卷选项")
    public static class QuestionnaireOptionVO implements Serializable {

        @Schema(description = "选项ID")
        private Long id;

        @Schema(description = "选项编号")
        private String optionNo;

        @Schema(description = "选项内容")
        private String optionText;

        @Schema(description = "选项分值")
        private Integer optionValue;
    }
}