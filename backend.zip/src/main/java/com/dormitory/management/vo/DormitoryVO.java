package com.dormitory.management.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;

/**
 * 宿舍VO
 */
@Data
@Schema(description = "宿舍信息响应对象")
public class DormitoryVO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Schema(description = "宿舍ID")
    private Long id;
    
    @Schema(description = "楼栋ID")
    private Long buildingId;
    
    @Schema(description = "楼栋名称")
    private String buildingName;
    
    @Schema(description = "楼栋编号")
    private String buildingNo;
    
    @Schema(description = "房间号")
    private String roomNo;
    
    @Schema(description = "楼层")
    private Integer floor;
    
    @Schema(description = "可住人数")
    private Integer capacity;
    
    @Schema(description = "已住人数")
    private Integer occupied;
    
    @Schema(description = "剩余床位")
    private Integer available;
    
    @Schema(description = "状态：0-维修中，1-正常，2-已满")
    private Integer status;
    
    @Schema(description = "状态文本")
    private String statusText;
    
    @Schema(description = "房间类型")
    private String roomType;
    
    @Schema(description = "设施说明")
    private String facilities;
}


