package com.dormitory.management.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;

/**
 * 室友信息VO
 */
@Data
@Schema(description = "室友信息响应对象")
public class RoommateVO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Schema(description = "学生ID")
    private Long id;
    
    @Schema(description = "学号")
    private String studentNo;
    
    @Schema(description = "姓名")
    private String name;
    
    @Schema(description = "性别：0-女，1-男")
    private Integer gender;
    
    @Schema(description = "性别文本")
    private String genderText;
    
    @Schema(description = "班级")
    private String className;
    
    @Schema(description = "专业")
    private String major;
    
    @Schema(description = "手机号")
    private String phone;
    
    @Schema(description = "床位号")
    private String bedNo;
}



