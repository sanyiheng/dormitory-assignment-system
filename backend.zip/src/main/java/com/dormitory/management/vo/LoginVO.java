package com.dormitory.management.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;

/**
 * 登录返回VO
 */
@Data
@Schema(description = "登录响应对象")
public class LoginVO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Schema(description = "用户ID")
    private Long userId;
    
    @Schema(description = "用户名")
    private String username;
    
    @Schema(description = "真实姓名")
    private String realName;
    
    @Schema(description = "用户类型：ADMIN-管理员，STUDENT-学生")
    private String userType;
    
    @Schema(description = "角色")
    private String role;
    
    @Schema(description = "头像")
    private String avatar;
    
    @Schema(description = "Token令牌")
    private String token;
    
    @Schema(description = "Token过期时间（秒）")
    private Long expireTime;
}


