package com.dormitory.management.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;
import java.util.List;

/**
 * 分配结果VO
 */
@Data
@Schema(description = "宿舍分配结果")
public class AssignmentResultVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @Schema(description = "宿舍ID")
    private Long dormitoryId;

    @Schema(description = "楼栋名称")
    private String buildingName;

    @Schema(description = "房间号")
    private String roomNo;

    @Schema(description = "床位号")
    private String bedNo;

    @Schema(description = "专业")
    private String major;

    @Schema(description = "班级")
    private String className;

    @Schema(description = "室友信息列表")
    private List<RoommateInfo> roommates;

    /**
     * 室友信息
     */
    @Data
    @Schema(description = "室友信息")
    public static class RoommateInfo implements Serializable {

        @Schema(description = "姓名")
        private String name;

        @Schema(description = "专业")
        private String major;

        @Schema(description = "班级")
        private String className;
    }
}