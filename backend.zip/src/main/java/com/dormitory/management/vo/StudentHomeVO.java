package com.dormitory.management.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;

/**
 * 学生首页信息VO
 */
@Data
@Schema(description = "学生首页信息响应对象")
public class StudentHomeVO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Schema(description = "学生ID")
    private Long studentId;
    
    @Schema(description = "学生姓名")
    private String studentName;
    
    @Schema(description = "宿舍信息")
    private String dormitoryInfo;
    
    @Schema(description = "待处理报修数")
    private Integer pendingRepairCount;
    
    @Schema(description = "未读公告数")
    private Integer unreadNoticeCount;
    
    @Schema(description = "是否已分配宿舍")
    private Boolean hasDormitory;
}



