package com.dormitory.management.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 公告VO
 */
@Data
@Schema(description = "公告响应对象")
public class NoticeVO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Schema(description = "公告ID")
    private Long id;
    
    @Schema(description = "公告标题")
    private String title;
    
    @Schema(description = "公告内容")
    private String content;
    
    @Schema(description = "公告类型")
    private String noticeType;
    
    @Schema(description = "公告类型文本")
    private String noticeTypeText;
    
    @Schema(description = "优先级")
    private Integer priority;
    
    @Schema(description = "优先级文本")
    private String priorityText;
    
    @Schema(description = "目标角色")
    private String targetRole;
    
    @Schema(description = "是否置顶")
    private Integer isTop;
    
    @Schema(description = "发布人ID")
    private Long publisherId;
    
    @Schema(description = "发布人姓名")
    private String publisherName;
    
    @Schema(description = "发布时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private LocalDateTime publishTime;
    
    @Schema(description = "过期时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private LocalDateTime expireTime;
    
    @Schema(description = "状态")
    private Integer status;
    
    @Schema(description = "状态文本")
    private String statusText;
    
    @Schema(description = "浏览次数")
    private Integer viewCount;
    
    @Schema(description = "是否已读")
    private Boolean isRead;
}


