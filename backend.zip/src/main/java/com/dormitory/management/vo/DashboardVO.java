package com.dormitory.management.vo;

import lombok.Data;
import java.io.Serializable;
import java.util.List;

/**
 * 仪表盘数据VO
 */
@Data
public class DashboardVO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 统计数据
     */
    private StatisticsData statistics;
    
    /**
     * 报修趋势数据（最近7个月）
     */
    private TrendData repairTrend;
    
    /**
     * 宿舍入住率数据
     */
    private OccupancyData occupancy;
    
    /**
     * 每月统计对比数据（最近12个月）
     */
    private MonthlyStatsData monthlyStats;
    
    /**
     * 最近报修记录（最近5条）
     */
    private List<RecentRepairVO> recentRepairs;
    
    /**
     * 统计数据
     */
    @Data
    public static class StatisticsData implements Serializable {
        private Integer studentCount;         // 学生总数
        private Integer dormitoryCount;       // 宿舍总数
        private Integer pendingRepairCount;   // 待处理报修数
        private Integer noticeCount;          // 本月新增公告数
    }
    
    /**
     * 趋势数据
     */
    @Data
    public static class TrendData implements Serializable {
        private List<String> months;   // 月份列表
        private List<Integer> values;  // 对应的数值
    }
    
    /**
     * 入住率数据
     */
    @Data
    public static class OccupancyData implements Serializable {
        private Integer occupied;      // 已入住
        private Integer vacant;        // 空置
        private Integer maintenance;   // 维修中
    }
    
    /**
     * 每月统计数据
     */
    @Data
    public static class MonthlyStatsData implements Serializable {
        private List<String> months;              // 月份列表
        private List<Integer> repairCounts;       // 报修数量
        private List<Integer> noticeCounts;       // 公告数量
        private List<Integer> newStudentCounts;   // 新增学生数量
    }
    
    /**
     * 最近报修VO
     */
    @Data
    public static class RecentRepairVO implements Serializable {
        private Long id;
        private String title;
        private String studentName;
        private Integer status;
        private String statusText;
    }
}



