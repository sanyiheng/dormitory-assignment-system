package com.dormitory.management.common;

import lombok.Getter;

/**
 * 响应状态码枚举
 */
@Getter
public enum ResultCode {
    
    // 成功
    SUCCESS(200, "操作成功"),
    
    // 客户端错误
    FAIL(400, "操作失败"),
    UNAUTHORIZED(401, "未登录或登录已过期"),
    FORBIDDEN(403, "权限不足"),
    NOT_FOUND(404, "资源不存在"),
    METHOD_NOT_ALLOWED(405, "请求方法不支持"),
    PARAMS_ERROR(422, "参数校验失败"),
    
    // 服务器错误
    SERVER_ERROR(500, "服务器内部错误"),
    
    // 业务错误 (1000-1999)
    LOGIN_ERROR(1001, "用户名或密码错误"),
    USER_NOT_EXIST(1002, "用户不存在"),
    USER_DISABLED(1003, "用户已被禁用"),
    USER_EXIST(1004, "用户已存在"),
    PASSWORD_ERROR(1005, "密码错误"),
    OLD_PASSWORD_ERROR(1006, "原密码错误"),
    
    STUDENT_NOT_EXIST(1101, "学生不存在"),
    STUDENT_NO_EXIST(1102, "学号已存在"),
    
    DORMITORY_NOT_EXIST(1201, "宿舍不存在"),
    DORMITORY_FULL(1202, "宿舍已满"),
    DORMITORY_GENDER_ERROR(1203, "宿舍性别不匹配"),
    
    ASSIGN_EXIST(1301, "学生已分配宿舍"),
    ASSIGN_NOT_EXIST(1302, "未找到分配记录"),
    
    REPAIR_NOT_EXIST(1401, "报修记录不存在"),
    REPAIR_STATUS_ERROR(1402, "报修状态错误"),
    
    NOTICE_NOT_EXIST(1501, "公告不存在"),
    
    // Redis 错误 (2100-2199)
    REDIS_ERROR(2101, "缓存操作失败");
    
    private final Integer code;
    private final String message;
    
    ResultCode(Integer code, String message) {
        this.code = code;
        this.message = message;
    }
}


