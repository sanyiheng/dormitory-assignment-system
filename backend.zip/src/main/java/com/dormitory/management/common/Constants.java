package com.dormitory.management.common;

/**
 * 常量类
 */
public class Constants {

    /**
     * 用户类型
     */
    public static final String USER_TYPE_ADMIN = "ADMIN";
    public static final String USER_TYPE_STUDENT = "STUDENT";
    public static final String USER_TYPE_STAFF = "STAFF";

    /**
     * 用户状态
     */
    public static final int USER_STATUS_DISABLED = 0;
    public static final int USER_STATUS_ENABLED = 1;

    /**
     * 性别
     */
    public static final int GENDER_FEMALE = 0;
    public static final int GENDER_MALE = 1;

    /**
     * 宿舍状态
     */
    public static final int DORM_STATUS_MAINTENANCE = 0;
    public static final int DORM_STATUS_NORMAL = 1;
    public static final int DORM_STATUS_FULL = 2;

    /**
     * 分配状态
     */
    public static final int ASSIGN_STATUS_CHECKED_OUT = 0;
    public static final int ASSIGN_STATUS_LIVING = 1;

    /**
     * 分配类型
     */
    public static final int ASSIGN_TYPE_AUTO = 0;
    public static final int ASSIGN_TYPE_MANUAL = 1;
    public static final int ASSIGN_TYPE_ADJUST = 2;

    /**
     * 报修状态
     */
    public static final int REPAIR_STATUS_PENDING = 0;
    public static final int REPAIR_STATUS_ACCEPTED = 1;
    public static final int REPAIR_STATUS_PROCESSING = 2;
    public static final int REPAIR_STATUS_COMPLETED = 3;
    public static final int REPAIR_STATUS_REJECTED = 4;

    /**
     * 报修优先级
     */
    public static final int REPAIR_PRIORITY_LOW = 0;
    public static final int REPAIR_PRIORITY_MEDIUM = 1;
    public static final int REPAIR_PRIORITY_HIGH = 2;
    public static final int REPAIR_PRIORITY_URGENT = 3;

    /**
     * 公告状态
     */
    public static final int NOTICE_STATUS_DRAFT = 0;
    public static final int NOTICE_STATUS_PUBLISHED = 1;
    public static final int NOTICE_STATUS_EXPIRED = 2;

    /**
     * 操作日志状态
     */
    public static final int LOG_STATUS_FAIL = 0;
    public static final int LOG_STATUS_SUCCESS = 1;

    /**
     * 逻辑删除
     */
    public static final int NOT_DELETED = 0;
    public static final int IS_DELETED = 1;

    /**
     * Redis Key 前缀
     */
    public static final String REDIS_KEY_LOGIN_USER = "login:user:";
    public static final String REDIS_KEY_ONLINE_USERS = "online:users";
    public static final String REDIS_KEY_NOTICE = "notice:";
    public static final String REDIS_KEY_CAPTCHA = "captcha:";
}


