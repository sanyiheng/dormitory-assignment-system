package com.dormitory.management.entity;

import com.mybatisflex.annotation.Id;
import com.mybatisflex.annotation.KeyType;
import com.mybatisflex.annotation.Table;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 问卷题目实体类
 */
@Data
@Table("questionnaire")
public class Questionnaire implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @Id(keyType = KeyType.Auto)
    private Long id;

    /**
     * 题号
     */
    private String questionNo;

    /**
     * 题目内容
     */
    private String questionText;

    /**
     * 维度：SCHEDULE-作息，SMOKING-抽烟，SNORING-打呼噜，HYGIENE-卫生，GAMING-游戏，TOLERANCE-忍耐度，INTEREST-兴趣
     */
    private String dimension;

    /**
     * 排序
     */
    private Integer sortOrder;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 逻辑删除：0-未删除，1-已删除
     */
    private Integer isDeleted;
}