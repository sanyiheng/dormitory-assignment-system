package com.dormitory.management.entity;

import com.dormitory.management.config.MyBatisFlexListener;
import com.mybatisflex.annotation.Id;
import com.mybatisflex.annotation.KeyType;
import com.mybatisflex.annotation.Table;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 学生实体类
 */
@Data
@Table(value = "student", onInsert = MyBatisFlexListener.class, onUpdate = MyBatisFlexListener.class)
public class Student implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键ID
     */
    @Id(keyType = KeyType.Auto)
    private Long id;
    
    /**
     * 学号
     */
    private String studentNo;
    
    /**
     * 密码(BCrypt加密)
     */
    private String password;
    
    /**
     * 姓名
     */
    private String name;
    
    /**
     * 性别：0-女，1-男
     */
    private Integer gender;
    
    /**
     * 联系电话
     */
    private String phone;
    
    /**
     * 邮箱
     */
    private String email;
    
    /**
     * 身份证号
     */
    private String idCard;
    
    /**
     * 头像URL
     */
    private String avatar;
    
    /**
     * 班级
     */
    private String className;
    
    /**
     * 专业
     */
    private String major;
    
    /**
     * 年级
     */
    private String grade;
    
    /**
     * 入学日期
     */
    private LocalDate enrollmentDate;
    
    /**
     * 状态：0-禁用，1-启用
     */
    private Integer status;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
    
    /**
     * 逻辑删除：0-未删除，1-已删除
     */
    private Integer isDeleted;
}


