package com.dormitory.management.entity;

import com.dormitory.management.config.MyBatisFlexListener;
import com.mybatisflex.annotation.Id;
import com.mybatisflex.annotation.KeyType;
import com.mybatisflex.annotation.Table;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 宿舍实体类
 */
@Data
@Table(value = "dormitory", onInsert = MyBatisFlexListener.class, onUpdate = MyBatisFlexListener.class)
public class Dormitory implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键ID
     */
    @Id(keyType = KeyType.Auto)
    private Long id;
    
    /**
     * 楼栋ID
     */
    private Long buildingId;
    
    /**
     * 房间号
     */
    private String roomNo;
    
    /**
     * 楼层
     */
    private Integer floor;
    
    /**
     * 可住人数
     */
    private Integer capacity;
    
    /**
     * 已住人数
     */
    private Integer occupied;
    
    /**
     * 状态：0-维修中，1-正常，2-已满
     */
    private Integer status;
    
    /**
     * 房间类型：STANDARD-标准间，DELUXE-豪华间
     */
    private String roomType;
    
    /**
     * 设施说明
     */
    private String facilities;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
    
    /**
     * 逻辑删除：0-未删除，1-已删除
     */
    private Integer isDeleted;
}


