package com.dormitory.management.entity;

import com.mybatisflex.annotation.Id;
import com.mybatisflex.annotation.KeyType;
import com.mybatisflex.annotation.Table;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 问卷选项实体类
 */
@Data
@Table("questionnaire_option")
public class QuestionnaireOption implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @Id(keyType = KeyType.Auto)
    private Long id;

    /**
     * 题目ID
     */
    private Long questionId;

    /**
     * 选项编号：A,B,C,D
     */
    private String optionNo;

    /**
     * 选项内容
     */
    private String optionText;

    /**
     * 选项分值（用于算法计算）
     */
    private Integer optionValue;

    /**
     * 排序
     */
    private Integer sortOrder;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 逻辑删除：0-未删除，1-已删除
     */
    private Integer isDeleted;
}