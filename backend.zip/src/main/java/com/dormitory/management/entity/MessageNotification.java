package com.dormitory.management.entity;

import com.dormitory.management.config.MyBatisFlexListener;
import com.mybatisflex.annotation.Id;
import com.mybatisflex.annotation.KeyType;
import com.mybatisflex.annotation.Table;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 消息通知实体类
 */
@Data
@Table(value = "message_notification", onInsert = MyBatisFlexListener.class)
public class MessageNotification implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键ID
     */
    @Id(keyType = KeyType.Auto)
    private Long id;
    
    /**
     * 接收人ID
     */
    private Long receiverId;
    
    /**
     * 接收人类型：STUDENT-学生，ADMIN-管理员
     */
    private String receiverType;
    
    /**
     * 消息标题
     */
    private String title;
    
    /**
     * 消息内容
     */
    private String content;
    
    /**
     * 消息类型：REPAIR_SUBMIT-报修提交，REPAIR_HANDLED-报修处理，NOTICE-公告通知，SYSTEM-系统消息
     */
    private String messageType;
    
    /**
     * 关联业务ID
     */
    private Long relatedId;
    
    /**
     * 是否已读：0-未读，1-已读
     */
    private Integer isRead;
    
    /**
     * 阅读时间
     */
    private LocalDateTime readTime;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
}


