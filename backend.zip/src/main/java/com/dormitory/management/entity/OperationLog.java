package com.dormitory.management.entity;

import com.dormitory.management.config.MyBatisFlexListener;
import com.mybatisflex.annotation.Id;
import com.mybatisflex.annotation.KeyType;
import com.mybatisflex.annotation.Table;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 操作日志实体类
 */
@Data
@Table(value = "operation_log", onInsert = MyBatisFlexListener.class)
public class OperationLog implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键ID
     */
    @Id(keyType = KeyType.Auto)
    private Long id;
    
    /**
     * 操作用户ID
     */
    private Long userId;
    
    /**
     * 操作用户名
     */
    private String userName;
    
    /**
     * 用户类型：STUDENT-学生，ADMIN-管理员
     */
    private String userType;
    
    /**
     * 操作名称
     */
    private String operation;
    
    /**
     * 操作模块
     */
    private String module;
    
    /**
     * 请求方法
     */
    private String method;
    
    /**
     * 请求URL
     */
    private String requestUrl;
    
    /**
     * 请求方式：GET/POST/PUT/DELETE
     */
    private String requestMethod;
    
    /**
     * 请求参数
     */
    private String requestParams;
    
    /**
     * 响应结果
     */
    private String responseResult;
    
    /**
     * IP地址
     */
    private String ipAddress;
    
    /**
     * 操作地点
     */
    private String location;
    
    /**
     * 浏览器
     */
    private String browser;
    
    /**
     * 操作系统
     */
    private String os;
    
    /**
     * 状态：0-失败，1-成功
     */
    private Integer status;
    
    /**
     * 错误信息
     */
    private String errorMsg;
    
    /**
     * 执行时长(毫秒)
     */
    private Integer executeTime;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
}


