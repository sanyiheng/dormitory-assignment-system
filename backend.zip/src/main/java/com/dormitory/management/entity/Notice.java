package com.dormitory.management.entity;

import com.dormitory.management.config.MyBatisFlexListener;
import com.mybatisflex.annotation.Id;
import com.mybatisflex.annotation.KeyType;
import com.mybatisflex.annotation.Table;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 通知公告实体类
 */
@Data
@Table(value = "notice", onInsert = MyBatisFlexListener.class, onUpdate = MyBatisFlexListener.class)
public class Notice implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键ID
     */
    @Id(keyType = KeyType.Auto)
    private Long id;
    
    /**
     * 公告标题
     */
    private String title;
    
    /**
     * 公告内容
     */
    private String content;
    
    /**
     * 公告类型：SYSTEM-系统公告，ACTIVITY-活动通知，MAINTENANCE-维修通知
     */
    private String noticeType;
    
    /**
     * 优先级：0-低，1-中，2-高
     */
    private Integer priority;
    
    /**
     * 目标角色：ALL-所有人，STUDENT-学生，ADMIN-管理员
     */
    private String targetRole;
    
    /**
     * 是否置顶：0-否，1-是
     */
    private Integer isTop;
    
    /**
     * 发布人ID
     */
    private Long publisherId;
    
    /**
     * 发布人姓名
     */
    private String publisherName;
    
    /**
     * 发布时间
     */
    private LocalDateTime publishTime;
    
    /**
     * 过期时间
     */
    private LocalDateTime expireTime;
    
    /**
     * 状态：0-草稿，1-已发布，2-已过期
     */
    private Integer status;
    
    /**
     * 浏览次数
     */
    private Integer viewCount;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
    
    /**
     * 逻辑删除：0-未删除，1-已删除
     */
    private Integer isDeleted;
}


