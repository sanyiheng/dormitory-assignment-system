package com.dormitory.management.entity;

import com.dormitory.management.config.MyBatisFlexListener;
import com.mybatisflex.annotation.Id;
import com.mybatisflex.annotation.KeyType;
import com.mybatisflex.annotation.Table;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 宿舍分配实体类
 */
@Data
@Table(value = "dorm_assign", onInsert = MyBatisFlexListener.class, onUpdate = MyBatisFlexListener.class)
public class DormAssign implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键ID
     */
    @Id(keyType = KeyType.Auto)
    private Long id;
    
    /**
     * 学生ID
     */
    private Long studentId;
    
    /**
     * 宿舍ID
     */
    private Long dormitoryId;
    
    /**
     * 床位号
     */
    private String bedNo;
    
    /**
     * 入住日期
     */
    private LocalDate checkInDate;
    
    /**
     * 退宿日期
     */
    private LocalDate checkOutDate;
    
    /**
     * 状态：0-已退宿，1-在住
     */
    private Integer status;
    
    /**
     * 分配类型：0-自动分配，1-手动分配，2-调整分配
     */
    private Integer assignType;
    
    /**
     * 备注
     */
    private String remark;
    
    /**
     * 操作员ID
     */
    private Long operatorId;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
    
    /**
     * 逻辑删除：0-未删除，1-已删除
     */
    private Integer isDeleted;
}


