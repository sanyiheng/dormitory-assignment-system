package com.dormitory.management.entity;

import com.mybatisflex.annotation.Id;
import com.mybatisflex.annotation.KeyType;
import com.mybatisflex.annotation.Table;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 宿舍楼实体类
 */
@Data
@Table("building")
public class Building implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键ID
     */
    @Id(keyType = KeyType.Auto)
    private Long id;
    
    /**
     * 楼栋名称
     */
    private String buildingName;
    
    /**
     * 楼栋编号
     */
    private String buildingNo;
    
    /**
     * 性别类型：0-女生楼，1-男生楼
     */
    private Integer genderType;
    
    /**
     * 楼层数
     */
    private Integer floorCount;
    
    /**
     * 描述
     */
    private String description;
    
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
    
    /**
     * 逻辑删除：0-未删除，1-已删除
     */
    private Integer isDeleted;
}


