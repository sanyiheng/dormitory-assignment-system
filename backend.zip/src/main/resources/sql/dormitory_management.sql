/*
 Navicat Premium Data Transfer

 Source Server         : localhost8.0
 Source Server Type    : MySQL
 Source Server Version : 80013
 Source Host           : localhost:3306
 Source Schema         : dormitory_management

 Target Server Type    : MySQL
 Target Server Version : 80013
 File Encoding         : 65001

 Date: 10/11/2025 21:11:43
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin_user
-- ----------------------------
DROP TABLE IF EXISTS `admin_user`;
CREATE TABLE `admin_user`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码(BCrypt加密)',
  `real_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '真实姓名',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系电话',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '头像URL',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
  `role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'ADMIN' COMMENT '角色：ADMIN-管理员，SUPER_ADMIN-超级管理员',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `is_deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE,
  INDEX `idx_username`(`username`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_is_deleted`(`is_deleted`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '管理员表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin_user
-- ----------------------------
INSERT INTO `admin_user` VALUES (1, 'admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '系统管理员', '13800138000', 'admin@dormitory.com', NULL, 1, 'ADMIN', '2025-11-07 20:41:48', '2025-11-08 23:00:43', 0);

-- ----------------------------
-- Table structure for building
-- ----------------------------
DROP TABLE IF EXISTS `building`;
CREATE TABLE `building`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `building_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '楼栋名称',
  `building_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '楼栋编号',
  `gender_type` tinyint(4) NOT NULL COMMENT '性别类型：0-女生楼，1-男生楼',
  `floor_count` int(11) NULL DEFAULT 0 COMMENT '楼层数',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '描述',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `is_deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `building_name`(`building_name`) USING BTREE,
  UNIQUE INDEX `building_no`(`building_no`) USING BTREE,
  INDEX `idx_building_no`(`building_no`) USING BTREE,
  INDEX `idx_gender_type`(`gender_type`) USING BTREE,
  INDEX `idx_is_deleted`(`is_deleted`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '宿舍楼表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of building
-- ----------------------------
INSERT INTO `building` VALUES (1, '1号楼', 'A1', 1, 6, '男生宿舍楼，标准4人间', '2025-11-07 20:41:48', '2025-11-07 20:41:48', 0);
INSERT INTO `building` VALUES (2, '2号楼', 'A2', 1, 6, '男生宿舍楼，标准4人间', '2025-11-07 20:41:48', '2025-11-07 20:41:48', 0);
INSERT INTO `building` VALUES (3, '3号楼', 'B1', 0, 6, '女生宿舍楼，标准4人间', '2025-11-07 20:41:48', '2025-11-07 20:41:48', 0);
INSERT INTO `building` VALUES (4, '4号楼', 'B2', 0, 6, '女生宿舍楼，标准4人间', '2025-11-07 20:41:48', '2025-11-07 20:41:48', 0);

-- ----------------------------
-- Table structure for dorm_assign
-- ----------------------------
DROP TABLE IF EXISTS `dorm_assign`;
CREATE TABLE `dorm_assign`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `student_id` bigint(20) NOT NULL COMMENT '学生ID',
  `dormitory_id` bigint(20) NOT NULL COMMENT '宿舍ID',
  `bed_no` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '床位号',
  `check_in_date` date NOT NULL COMMENT '入住日期',
  `check_out_date` date NULL DEFAULT NULL COMMENT '退宿日期',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态：0-已退宿，1-在住',
  `assign_type` tinyint(4) NULL DEFAULT 0 COMMENT '分配类型：0-自动分配，1-手动分配，2-调整分配',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `operator_id` bigint(20) NULL DEFAULT NULL COMMENT '操作员ID',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `is_deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_student_id`(`student_id`) USING BTREE,
  INDEX `idx_dormitory_id`(`dormitory_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_check_in_date`(`check_in_date`) USING BTREE,
  INDEX `idx_is_deleted`(`is_deleted`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '宿舍分配表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dorm_assign
-- ----------------------------
INSERT INTO `dorm_assign` VALUES (8, 1, 2, '2号床', '2025-11-08', NULL, 1, 1, '', NULL, NULL, '2025-11-08 18:42:25', 0);
INSERT INTO `dorm_assign` VALUES (9, 2, 2, '1号床', '2025-11-09', NULL, 1, 1, '', NULL, '2025-11-09 10:12:29', '2025-11-09 10:12:29', 0);
INSERT INTO `dorm_assign` VALUES (10, 3, 2, '3号床', '2025-11-12', NULL, 1, 1, '', NULL, '2025-11-09 10:12:45', '2025-11-09 10:12:45', 0);

-- ----------------------------
-- Table structure for dormitory
-- ----------------------------
DROP TABLE IF EXISTS `dormitory`;
CREATE TABLE `dormitory`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `building_id` bigint(20) NOT NULL COMMENT '楼栋ID',
  `room_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '房间号',
  `floor` int(11) NOT NULL COMMENT '楼层',
  `capacity` int(11) NULL DEFAULT 4 COMMENT '可住人数',
  `occupied` int(11) NULL DEFAULT 0 COMMENT '已住人数',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态：0-维修中，1-正常，2-已满',
  `room_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'STANDARD' COMMENT '房间类型：STANDARD-标准间，DELUXE-豪华间',
  `facilities` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '设施说明',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `is_deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_building_room`(`building_id`, `room_no`) USING BTREE,
  INDEX `idx_building_id`(`building_id`) USING BTREE,
  INDEX `idx_room_no`(`room_no`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_is_deleted`(`is_deleted`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '宿舍表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dormitory
-- ----------------------------
INSERT INTO `dormitory` VALUES (1, 1, '101', 1, 4, 0, 1, 'STANDARD', NULL, '2025-11-07 20:41:48', '2025-11-08 17:42:01', 0);
INSERT INTO `dormitory` VALUES (2, 1, '102', 1, 4, 3, 1, 'STANDARD', NULL, '2025-11-07 20:41:48', '2025-11-09 10:12:45', 0);
INSERT INTO `dormitory` VALUES (3, 1, '201', 2, 4, 0, 1, 'STANDARD', NULL, '2025-11-07 20:41:48', '2025-11-08 18:33:04', 0);
INSERT INTO `dormitory` VALUES (4, 2, '402', 4, 4, 0, 1, 'STANDARD', NULL, '2025-11-07 20:41:48', '2025-11-07 20:41:48', 0);
INSERT INTO `dormitory` VALUES (5, 2, '101', 1, 4, 0, 1, 'STANDARD', NULL, '2025-11-07 20:41:48', '2025-11-07 20:41:48', 0);
INSERT INTO `dormitory` VALUES (6, 2, '102', 1, 4, 0, 1, 'STANDARD', NULL, '2025-11-07 20:41:48', '2025-11-07 20:41:48', 0);
INSERT INTO `dormitory` VALUES (7, 3, '101', 1, 4, 0, 1, 'STANDARD', NULL, '2025-11-07 20:41:48', '2025-11-08 18:33:02', 0);
INSERT INTO `dormitory` VALUES (8, 3, '102', 1, 4, 0, 1, 'STANDARD', NULL, '2025-11-07 20:41:48', '2025-11-07 20:41:48', 0);

-- ----------------------------
-- Table structure for maintenance_staff
-- ----------------------------
DROP TABLE IF EXISTS `maintenance_staff`;
CREATE TABLE `maintenance_staff`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码(BCrypt加密)',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '姓名',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '联系电话',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '头像URL',
  `specialty` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '专长领域：水电/家具/网络/综合',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态：0-离职，1-在职',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `is_deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE,
  INDEX `idx_username`(`username`) USING BTREE,
  INDEX `idx_phone`(`phone`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_is_deleted`(`is_deleted`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '维修人员表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of maintenance_staff
-- ----------------------------
INSERT INTO `maintenance_staff` VALUES (1, 'staff001', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '张师傅', '13800138001', 'zhangshifu@dormitory.com', NULL, '水电维修', 1, '2025-11-08 17:20:41', '2025-11-08 17:30:03', 0);
INSERT INTO `maintenance_staff` VALUES (2, 'staff002', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '李师傅', '13800138002', 'lishifu@dormitory.com', NULL, '家具维修', 1, '2025-11-08 17:20:41', '2025-11-08 17:30:08', 0);
INSERT INTO `maintenance_staff` VALUES (3, 'staff003', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '王师傅', '13800138003', 'wangshifu@dormitory.com', NULL, '网络维修', 1, '2025-11-08 17:20:41', '2025-11-08 17:30:11', 0);

-- ----------------------------
-- Table structure for message_notification
-- ----------------------------
DROP TABLE IF EXISTS `message_notification`;
CREATE TABLE `message_notification`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `receiver_id` bigint(20) NOT NULL COMMENT '接收人ID',
  `receiver_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '接收人类型：STUDENT-学生，ADMIN-管理员',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息内容',
  `message_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息类型：REPAIR_SUBMIT-报修提交，REPAIR_HANDLED-报修处理，NOTICE-公告通知，SYSTEM-系统消息',
  `related_id` bigint(20) NULL DEFAULT NULL COMMENT '关联业务ID',
  `is_read` tinyint(4) NULL DEFAULT 0 COMMENT '是否已读：0-未读，1-已读',
  `read_time` datetime(0) NULL DEFAULT NULL COMMENT '阅读时间',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_receiver`(`receiver_id`, `receiver_type`) USING BTREE,
  INDEX `idx_is_read`(`is_read`) USING BTREE,
  INDEX `idx_message_type`(`message_type`) USING BTREE,
  INDEX `idx_create_time`(`create_time`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '消息通知表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of message_notification
-- ----------------------------
INSERT INTO `message_notification` VALUES (1, 1, 'ADMIN', '新的报修申请', '学生 张三 提交了报修申请：漏水', 'REPAIR_SUBMIT', 7, 0, NULL, '2025-11-10 20:58:23');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '公告标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '公告内容',
  `notice_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'SYSTEM' COMMENT '公告类型：SYSTEM-系统公告，ACTIVITY-活动通知，MAINTENANCE-维修通知',
  `priority` tinyint(4) NULL DEFAULT 1 COMMENT '优先级：0-低，1-中，2-高',
  `target_role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'ALL' COMMENT '目标角色：ALL-所有人，STUDENT-学生，ADMIN-管理员',
  `is_top` tinyint(4) NULL DEFAULT 0 COMMENT '是否置顶：0-否，1-是',
  `publisher_id` bigint(20) NOT NULL COMMENT '发布人ID',
  `publisher_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '发布人姓名',
  `publish_time` datetime(0) NULL DEFAULT NULL COMMENT '发布时间',
  `expire_time` datetime(0) NULL DEFAULT NULL COMMENT '过期时间',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态：0-草稿，1-已发布，2-已过期',
  `view_count` int(11) NULL DEFAULT 0 COMMENT '浏览次数',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `is_deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_publisher_id`(`publisher_id`) USING BTREE,
  INDEX `idx_notice_type`(`notice_type`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_publish_time`(`publish_time`) USING BTREE,
  INDEX `idx_is_top`(`is_top`) USING BTREE,
  INDEX `idx_is_deleted`(`is_deleted`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '通知公告表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (1, '宿舍卫生检查通知', '各位同学，本周五（1月19日）下午2点将进行宿舍卫生检查。请大家做好以下准备：\r\n1. 保持宿舍整洁，物品摆放有序\r\n2. 清理垃圾，保持地面干净\r\n3. 整理床铺，被褥叠放整齐\r\n4. 检查门窗是否完好\r\n感谢大家的配合！', 'MAINTENANCE', 1, 'STUDENT', 1, 1, '系统管理员', '2024-01-15 10:00:00', NULL, 1, 156, '2024-01-15 10:00:00', '2025-11-08 22:05:36', 0);
INSERT INTO `notice` VALUES (2, '寒假宿舍管理规定', '各位同学：\r\n寒假将至，现就寒假期间宿舍管理相关事宜通知如下：\r\n一、离校注意事项\r\n1. 离校前请关好门窗，切断所有电源\r\n2. 贵重物品请随身携带，学校不承担保管责任\r\n3. 清理宿舍垃圾，保持卫生\r\n二、留校住宿管理\r\n1. 留校学生需提前申请并登记\r\n2. 遵守作息时间，保持安静\r\n3. 注意用电安全，禁止使用大功率电器\r\n三、返校时间\r\n请于2月20日前返校报到。\r\n祝大家寒假愉快！', 'SYSTEM', 1, 'STUDENT', 0, 1, '系统管理员', '2024-01-10 09:00:00', NULL, 1, 234, '2024-01-10 09:00:00', '2025-11-08 19:16:35', 0);
INSERT INTO `notice` VALUES (3, '3号楼网络维修通知', '尊敬的各位师生：\r\n因网络设备升级，3号楼（女生宿舍楼）将于本周六（1月20日）上午9:00-12:00进行网络维护。\r\n维护期间该楼栋网络将暂时中断，给您带来不便敬请谅解。\r\n如有紧急情况，请联系网络中心：0571-88888888', 'MAINTENANCE', 2, 'ALL', 0, 1, '系统管理员', '2024-01-12 14:00:00', NULL, 1, 89, '2024-01-12 14:00:00', '2025-11-08 19:16:35', 0);
INSERT INTO `notice` VALUES (4, '春季运动会报名通知', '各位同学：\r\n学校将于3月15日举办春季运动会，现开始接受报名！\r\n比赛项目：\r\n1. 田径项目：100米、200米、400米、800米、1500米、跳远、跳高\r\n2. 球类项目：篮球、足球、羽毛球、乒乓球\r\n3. 趣味项目：拔河、接力赛\r\n报名时间：即日起至2月28日\r\n报名方式：请到各班级体育委员处报名\r\n奖励：前三名将获得荣誉证书和奖品！\r\n期待大家踊跃参与！', 'ACTIVITY', 1, 'STUDENT', 0, 1, '系统管理员', '2024-01-08 16:00:00', NULL, 1, 312, '2024-01-08 16:00:00', '2025-11-08 22:00:09', 1);
INSERT INTO `notice` VALUES (5, '消防安全演练通知', '【重要通知】\r\n各位同学：\r\n为提高大家的消防安全意识和应急逃生能力，学校将组织消防安全演练。\r\n时间：1月25日（周四）下午3:00\r\n地点：各宿舍楼\r\n内容：\r\n1. 火灾报警演练\r\n2. 应急疏散演练\r\n3. 灭火器使用培训\r\n注意事项：\r\n1. 听到警报后，请按指定路线有序撤离\r\n2. 不要携带贵重物品\r\n3. 用湿毛巾捂住口鼻，弯腰前进\r\n4. 到达集合地点后清点人数\r\n请大家务必重视，积极配合！', 'SYSTEM', 2, 'ALL', 1, 1, '系统管理员', '2024-01-13 11:00:00', NULL, 1, 278, '2024-01-13 11:00:00', '2025-11-08 19:16:35', 0);
INSERT INTO `notice` VALUES (6, '图书馆开放时间调整通知', '各位读者：\r\n因馆内设施维护，图书馆开放时间临时调整如下：\r\n调整时间：1月22日-1月26日\r\n开放时间：\r\n周一至周五 9:00-17:00（午休时间12:00-13:00不闭馆）\r\n周六、周日 9:00-16:00\r\n1月27日起恢复正常开放时间。\r\n给您带来不便，敬请谅解！\r\n图书馆咨询电话：0571-88888899', 'SYSTEM', 1, 'ALL', 0, 1, '系统管理员', '2024-01-11 10:30:00', NULL, 1, 145, '2024-01-11 10:30:00', '2025-11-08 19:16:35', 0);

-- ----------------------------
-- Table structure for notice_read
-- ----------------------------
DROP TABLE IF EXISTS `notice_read`;
CREATE TABLE `notice_read`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `notice_id` bigint(20) NOT NULL COMMENT '公告ID',
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `user_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户类型：STUDENT-学生，ADMIN-管理员',
  `read_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '阅读时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_notice_user`(`notice_id`, `user_id`, `user_type`) USING BTREE,
  INDEX `idx_notice_id`(`notice_id`) USING BTREE,
  INDEX `idx_user_id`(`user_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '公告阅读记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of notice_read
-- ----------------------------

-- ----------------------------
-- Table structure for operation_log
-- ----------------------------
DROP TABLE IF EXISTS `operation_log`;
CREATE TABLE `operation_log`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` bigint(20) NOT NULL COMMENT '操作用户ID',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '操作用户名',
  `user_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户类型：STUDENT-学生，ADMIN-管理员',
  `operation` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '操作名称',
  `module` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '操作模块',
  `method` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '请求方法',
  `request_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '请求URL',
  `request_method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '请求方式：GET/POST/PUT/DELETE',
  `request_params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '请求参数',
  `response_result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '响应结果',
  `ip_address` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'IP地址',
  `location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '操作地点',
  `browser` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '浏览器',
  `os` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '操作系统',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态：0-失败，1-成功',
  `error_msg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '错误信息',
  `execute_time` int(11) NULL DEFAULT NULL COMMENT '执行时长(毫秒)',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_user_id`(`user_id`) USING BTREE,
  INDEX `idx_module`(`module`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_create_time`(`create_time`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '操作日志表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of operation_log
-- ----------------------------

-- ----------------------------
-- Table structure for repair_request
-- ----------------------------
DROP TABLE IF EXISTS `repair_request`;
CREATE TABLE `repair_request`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `student_id` bigint(20) NOT NULL COMMENT '学生ID',
  `dormitory_id` bigint(20) NOT NULL COMMENT '宿舍ID',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '报修标题',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '问题描述',
  `repair_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '报修类型：WATER-水电，FURNITURE-家具，NETWORK-网络，OTHER-其他',
  `images` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '图片URL列表，多个用逗号分隔',
  `status` tinyint(4) NULL DEFAULT 0 COMMENT '状态：0-待审核，1-已接受，2-处理中，3-已完成，4-已拒绝',
  `priority` tinyint(4) NULL DEFAULT 1 COMMENT '优先级：0-低，1-中，2-高，3-紧急',
  `handler_id` bigint(20) NULL DEFAULT NULL COMMENT '处理人ID',
  `handler_remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '处理备注',
  `handle_time` datetime(0) NULL DEFAULT NULL COMMENT '处理时间',
  `complete_time` datetime(0) NULL DEFAULT NULL COMMENT '完成时间',
  `reject_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '拒绝原因',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `is_deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_student_id`(`student_id`) USING BTREE,
  INDEX `idx_dormitory_id`(`dormitory_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_handler_id`(`handler_id`) USING BTREE,
  INDEX `idx_create_time`(`create_time`) USING BTREE,
  INDEX `idx_is_deleted`(`is_deleted`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '报修申请表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of repair_request
-- ----------------------------
INSERT INTO `repair_request` VALUES (1, 1, 1, '水龙头漏水', '宿舍卫生间水龙头一直在滴水，请尽快维修', 'WATER', NULL, 0, 2, 1, NULL, NULL, NULL, NULL, '2025-10-15 10:00:00', '2025-11-08 22:50:58', 0);
INSERT INTO `repair_request` VALUES (2, 2, 1, '门锁损坏', '宿舍门锁打不开，需要更换', 'FURNITURE', NULL, 2, 3, 1, NULL, NULL, NULL, NULL, '2025-07-14 14:30:00', '2025-11-08 22:50:47', 0);
INSERT INTO `repair_request` VALUES (3, 1, 1, '灯泡不亮', '客厅灯泡不亮了，需要更换', 'OTHER', NULL, 3, 1, 1, NULL, NULL, NULL, NULL, '2025-08-10 09:00:00', '2025-11-08 22:50:35', 0);
INSERT INTO `repair_request` VALUES (4, 1, 2, '宿舍漏水了', '请早点过来', 'WATER', NULL, 2, 1, 1, NULL, '2025-11-08 23:41:07', NULL, NULL, '2025-11-08 22:50:14', '2025-11-08 23:44:14', 0);
INSERT INTO `repair_request` VALUES (5, 1, 2, '维修', '请快点', 'WATER', NULL, 0, 1, 2, NULL, NULL, NULL, NULL, '2025-11-01 22:50:18', '2025-11-08 22:50:24', 0);
INSERT INTO `repair_request` VALUES (6, 1, 2, '11月9号厕所马桶漏水', '一直 滴水麻烦赶紧来修', 'WATER', NULL, 3, 1, 1, '已修好', '2025-11-09 10:13:20', '2025-11-09 10:19:02', NULL, '2025-11-09 10:11:26', '2025-11-09 10:19:02', 0);
INSERT INTO `repair_request` VALUES (7, 1, 2, '漏水', '11月10日水龙头漏水', 'FURNITURE', NULL, 0, 1, 2, NULL, NULL, NULL, NULL, '2025-11-10 20:58:22', '2025-11-10 20:58:22', 0);

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `student_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '学号',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码(BCrypt加密)',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '姓名',
  `gender` tinyint(4) NOT NULL COMMENT '性别：0-女，1-男',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系电话',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `id_card` varchar(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '身份证号',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '头像URL',
  `class_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '班级',
  `major` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '专业',
  `grade` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '年级',
  `enrollment_date` date NULL DEFAULT NULL COMMENT '入学日期',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `is_deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `student_no`(`student_no`) USING BTREE,
  INDEX `idx_student_no`(`student_no`) USING BTREE,
  INDEX `idx_name`(`name`) USING BTREE,
  INDEX `idx_class`(`class_name`) USING BTREE,
  INDEX `idx_major`(`major`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_is_deleted`(`is_deleted`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '学生表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (1, '2025001', '$2a$10$XvEI1OHcGKNqEgb/vo2DKuIvvyzb/ie0esNmvB.7BfmVBT62Lqwbi', '张三', 1, '13900139001', 'zhangsan@student.com', NULL, NULL, '软件1班', '软件工程', '2024', '2024-09-01', 1, '2025-11-07 20:41:48', '2025-11-10 21:11:03', 0);
INSERT INTO `student` VALUES (2, '2025002', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '李四', 1, '13900139002', 'lisi@student.com', NULL, NULL, '软件1班', '软件工程', '2024', '2024-09-01', 1, '2025-11-07 20:41:48', '2025-11-10 21:11:06', 0);
INSERT INTO `student` VALUES (3, '2025003', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '王芳', 0, '13900139003', 'wangfang@student.com', NULL, NULL, '计算机1班', '计算机科学', '2024', '2024-09-01', 1, '2025-11-07 20:41:48', '2025-11-10 21:11:09', 0);

SET FOREIGN_KEY_CHECKS = 1;
