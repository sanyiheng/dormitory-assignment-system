import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/stores/user'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/common/Login.vue'),
    meta: { title: '登录', requireAuth: false }
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('@/views/common/Register.vue'),
    meta: { title: '注册', requireAuth: false }
  },
  {
    path: '/admin',
    name: 'AdminLayout',
    component: () => import('@/views/admin/Layout.vue'),
    meta: { title: '管理员端', requireAuth: true, roles: ['ADMIN', 'STAFF'] },
    children: [
      {
        path: 'dashboard',
        name: 'AdminDashboard',
        component: () => import('@/views/admin/Dashboard.vue'),
        meta: { title: '仪表盘', roles: ['ADMIN'] }
      },
      {
        path: 'student',
        name: 'StudentManage',
        component: () => import('@/views/admin/StudentManage.vue'),
        meta: { title: '学生管理', roles: ['ADMIN'] }
      },
      {
        path: 'dormitory',
        name: 'DormitoryManage',
        component: () => import('@/views/admin/DormitoryManage.vue'),
        meta: { title: '宿舍管理', roles: ['ADMIN'] }
      },
      {
        path: 'assignment',
        name: 'AssignmentManage',
        component: () => import('@/views/admin/AssignmentManage.vue'),
        meta: { title: '分配管理', roles: ['ADMIN'] }
      },
      {
        path: 'notice',
        name: 'NoticeManage',
        component: () => import('@/views/admin/NoticeManage.vue'),
        meta: { title: '公告管理', roles: ['ADMIN'] }
      }
    ]
  },
  {
    path: '/student',
    name: 'StudentLayout',
    component: () => import('@/views/student/Layout.vue'),
    meta: { title: '学生端', requireAuth: true, role: 'STUDENT' },
    children: [
      {
        path: 'home',
        name: 'StudentHome',
        component: () => import('@/views/student/Home.vue'),
        meta: { title: '首页' }
      },
      {
        path: 'dormitory',
        name: 'StudentDormitory',
        component: () => import('@/views/student/Dormitory.vue'),
        meta: { title: '我的宿舍' }
      },
      {
        path: 'questionnaire',
        name: 'StudentQuestionnaire',
        component: () => import('@/views/student/Questionnaire.vue'),
        meta: { title: '填写问卷' }
      },
      {
        path: 'assignment',
        name: 'StudentAssignment',
        component: () => import('@/views/student/Assignment.vue'),
        meta: { title: '我的分配' }
      },
      {
        path: 'notice',
        name: 'StudentNotice',
        component: () => import('@/views/student/Notice.vue'),
        meta: { title: '公告通知' }
      },
      {
        path: 'profile',
        name: 'StudentProfile',
        component: () => import('@/views/student/Profile.vue'),
        meta: { title: '个人信息' }
      }
    ]
  },
  {
    path: '/',
    redirect: '/login'
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// 路由守卫
router.beforeEach((to, from, next) => {
  const userStore = useUserStore()
  
  // 设置页面标题
  document.title = to.meta.title ? `${to.meta.title} - 学生宿舍智能分配系统` : '学生宿舍智能分配系统'
  
  // 如果不需要认证，直接通过
  if (!to.meta.requireAuth) {
    next()
    return
  }
  
  // 检查是否登录
  if (!userStore.isLogin()) {
    window.$message?.warning('请先登录')
    next('/login')
    return
  }
  
  // 检查角色权限（支持多角色）
  if (to.meta.roles) {
    const userRole = userStore.userInfo?.role
    if (!to.meta.roles.includes(userRole)) {
      window.$message?.error('您没有权限访问该页面')
      // 根据用户角色跳转到对应首页
      if (userRole === 'ADMIN') {
        next('/admin/dashboard')
      } else if (userRole === 'STAFF') {
        next('/admin/repair')
      } else {
        next('/student/home')
      }
      return
    }
  }
  
  // 兼容旧的单角色检查
  if (to.meta.role) {
    const userRole = userStore.userInfo?.role
    if (to.meta.role !== userRole) {
      window.$message?.error('您没有权限访问该页面')
      if (userRole === 'ADMIN') {
        next('/admin/dashboard')
      } else if (userRole === 'STAFF') {
        next('/admin/repair')
      } else {
        next('/student/home')
      }
      return
    }
  }
  
  next()
})

export default router


