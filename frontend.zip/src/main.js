import { createApp } from 'vue'
import { createPinia } from 'pinia'
import naive from 'naive-ui'
import { createDiscreteApi } from 'naive-ui'
import App from './App.vue'
import router from './router'
import './assets/style.css'

// 创建离散式 API（用于在非组件上下文中使用）
const { message, dialog, notification, loadingBar } = createDiscreteApi(
  ['message', 'dialog', 'notification', 'loadingBar']
)

// 挂载到 window 对象，供 axios 拦截器等使用
window.$message = message
window.$dialog = dialog
window.$notification = notification
window.$loadingBar = loadingBar

const app = createApp(App)
const pinia = createPinia()

app.use(pinia)
app.use(router)
app.use(naive)

app.mount('#app')


