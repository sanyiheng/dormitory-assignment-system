import request from '@/utils/request'

/**
 * 获取问卷列表
 */
export const getQuestionnaireList = () => {
  return request({
    url: '/questionnaire/list',
    method: 'get'
  })
}

/**
 * 提交问卷
 */
export const submitQuestionnaire = (data) => {
  return request({
    url: '/questionnaire/submit',
    method: 'post',
    data
  })
}

/**
 * 检查是否已填写问卷
 */
export const checkSubmitted = () => {
  return request({
    url: '/questionnaire/check',
    method: 'get'
  })
}