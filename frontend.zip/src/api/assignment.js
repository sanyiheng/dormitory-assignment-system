import request from '@/utils/request'

/**
 * 获取我的分配结果
 */
export const getMyAssignment = () => {
  return request({
    url: '/assignment/my',
    method: 'get'
  })
}

/**
 * 获取所有分配结果（管理员用）
 */
export const getAssignmentResults = () => {
  return request({
    url: '/assignment/results',
    method: 'get'
  })
}

/**
 * 执行分配算法
 */
export const executeAssignment = () => {
  return request({
    url: '/assignment/execute',
    method: 'post'
  })
}