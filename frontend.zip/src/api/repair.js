import request from '@/utils/request'

/**
 * 分页查询报修申请
 */
export const getRepairPage = (params) => {
  return request({
    url: '/repair/page',
    method: 'get',
    params
  })
}

/**
 * 根据ID查询报修申请
 */
export const getRepairById = (id) => {
  return request({
    url: `/repair/${id}`,
    method: 'get'
  })
}

/**
 * 提交报修申请
 */
export const submitRepair = (data) => {
  return request({
    url: '/repair/submit',
    method: 'post',
    data
  })
}

/**
 * 审核报修申请（管理员）
 */
export const auditRepair = (data) => {
  return request({
    url: '/repair/audit',
    method: 'post',
    data
  })
}

/**
 * 接受报修（维修人员）
 */
export const acceptRepair = (id) => {
  return request({
    url: `/repair/accept/${id}`,
    method: 'put'
  })
}

/**
 * 开始处理（维修人员）
 */
export const startRepair = (id) => {
  return request({
    url: `/repair/start/${id}`,
    method: 'put'
  })
}

/**
 * 完成报修（维修人员）
 */
export const completeRepair = (data) => {
  return request({
    url: '/repair/complete',
    method: 'put',
    data
  })
}

/**
 * 删除报修申请
 */
export const deleteRepair = (id) => {
  return request({
    url: `/repair/${id}`,
    method: 'delete'
  })
}

/**
 * 获取所有在职维修人员列表
 */
export const getMaintenanceStaffList = () => {
  return request({
    url: '/maintenance-staff/list',
    method: 'get'
  })
}

