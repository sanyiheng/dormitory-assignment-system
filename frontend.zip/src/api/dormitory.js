import request from '@/utils/request'

/**
 * 分页查询宿舍
 */
export const getDormitoryPage = (params) => {
  return request({
    url: '/dormitory/page',
    method: 'get',
    params
  })
}

/**
 * 根据ID查询宿舍
 */
export const getDormitoryById = (id) => {
  return request({
    url: `/dormitory/${id}`,
    method: 'get'
  })
}

/**
 * 新增宿舍
 */
export const addDormitory = (data) => {
  return request({
    url: '/dormitory',
    method: 'post',
    data
  })
}

/**
 * 更新宿舍
 */
export const updateDormitory = (data) => {
  return request({
    url: '/dormitory',
    method: 'put',
    data
  })
}

/**
 * 删除宿舍
 */
export const deleteDormitory = (id) => {
  return request({
    url: `/dormitory/${id}`,
    method: 'delete'
  })
}

/**
 * 批量删除宿舍
 */
export const batchDeleteDormitory = (ids) => {
  return request({
    url: '/dormitory/batch',
    method: 'delete',
    data: ids
  })
}

/**
 * 获取可用宿舍列表（有空余床位）
 */
export const getAvailableDormitories = () => {
  return request({
    url: '/dormitory/available',
    method: 'get'
  })
}

/**
 * 分配宿舍
 */
export const assignDormitory = (data) => {
  return request({
    url: '/dormitory/assign',
    method: 'post',
    data
  })
}

/**
 * 取消宿舍分配
 */
export const unassignDormitory = (studentId) => {
  return request({
    url: `/dormitory/unassign/${studentId}`,
    method: 'delete'
  })
}



