import request from '@/utils/request'

/**
 * 获取仪表盘数据
 */
export const getDashboardData = () => {
  return request({
    url: '/dashboard/data',
    method: 'get'
  })
}



