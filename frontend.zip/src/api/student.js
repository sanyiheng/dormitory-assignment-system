import request from '@/utils/request'

/**
 * 分页查询学生
 */
export const getStudentPage = (params) => {
  return request({
    url: '/student/page',
    method: 'get',
    params
  })
}

/**
 * 根据ID查询学生
 */
export const getStudentById = (id) => {
  return request({
    url: `/student/${id}`,
    method: 'get'
  })
}

/**
 * 新增学生
 */
export const addStudent = (data) => {
  return request({
    url: '/student',
    method: 'post',
    data
  })
}

/**
 * 更新学生
 */
export const updateStudent = (data) => {
  return request({
    url: '/student',
    method: 'put',
    data
  })
}

/**
 * 删除学生
 */
export const deleteStudent = (id) => {
  return request({
    url: `/student/${id}`,
    method: 'delete'
  })
}

/**
 * 批量删除学生
 */
export const batchDeleteStudent = (ids) => {
  return request({
    url: '/student/batch',
    method: 'delete',
    data: ids
  })
}

/**
 * 获取学生首页信息
 */
export const getStudentHomeInfo = (studentId) => {
  return request({
    url: `/student/home/${studentId}`,
    method: 'get'
  })
}

/**
 * 获取学生宿舍信息（包括室友）
 */
export const getStudentDormInfo = (studentId) => {
  return request({
    url: `/student/dorm/${studentId}`,
    method: 'get'
  })
}
