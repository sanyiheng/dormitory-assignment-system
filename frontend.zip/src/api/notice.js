import request from '@/utils/request'

/**
 * 分页查询公告
 */
export const getNoticePage = (params) => {
  return request({
    url: '/notice/page',
    method: 'get',
    params
  })
}

/**
 * 根据ID查询公告详情
 */
export const getNoticeById = (id) => {
  return request({
    url: `/notice/${id}`,
    method: 'get'
  })
}

/**
 * 发布公告
 */
export const publishNotice = (data) => {
  return request({
    url: '/notice/publish',
    method: 'post',
    data
  })
}

/**
 * 更新公告
 */
export const updateNotice = (data) => {
  return request({
    url: '/notice',
    method: 'put',
    data
  })
}

/**
 * 删除公告
 */
export const deleteNotice = (id) => {
  return request({
    url: `/notice/${id}`,
    method: 'delete'
  })
}
