<template>
  <div class="modern-page">
    <!-- 背景装饰 -->
    <div class="background-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 页面标题 -->
    <div class="page-header">
      <h2 class="page-title">
        <span class="title-icon">👨‍🎓</span>
        学生管理
      </h2>
      <p class="page-subtitle">管理学生信息、分配宿舍、查看学生状态</p>
    </div>

    <!-- 操作栏 -->
    <div class="action-bar">
      <div class="action-left">
        <button class="modern-btn btn-primary" @click="handleAdd">
          <svg class="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
          </svg>
          新增学生
        </button>
        <button class="modern-btn btn-secondary" @click="handleRefresh">
          <svg class="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          刷新
        </button>
      </div>
      
      <div class="search-box">
        <input
          v-model="queryParams.keyword"
          class="modern-input"
          placeholder="🔍 搜索身份证号、姓名或班级..."
          @keyup.enter="handleSearch"
        />
        <button class="search-btn" @click="handleSearch">搜索</button>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <div class="stat-card stat-primary">
        <div class="stat-icon">👥</div>
        <div class="stat-content">
          <div class="stat-value">{{ tableData.length }}</div>
          <div class="stat-label">总学生数</div>
        </div>
      </div>
      <div class="stat-card stat-success">
        <div class="stat-icon">🏠</div>
        <div class="stat-content">
          <div class="stat-value">{{ tableData.filter(s => s.dormitoryInfo && s.dormitoryInfo !== '未分配').length }}</div>
          <div class="stat-label">已分配宿舍</div>
        </div>
      </div>
      <div class="stat-card stat-warning">
        <div class="stat-icon">⏳</div>
        <div class="stat-content">
          <div class="stat-value">{{ tableData.filter(s => !s.dormitoryInfo || s.dormitoryInfo === '未分配').length }}</div>
          <div class="stat-label">未分配宿舍</div>
        </div>
      </div>
    </div>

    <!-- 现代化表格卡片 -->
    <div class="table-card">
      <n-data-table
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :pagination="pagination"
        :bordered="false"
        striped
      />
    </div>
    
    <!-- 新增/编辑对话框 -->
    <n-modal
      v-model:show="showModal"
      preset="dialog"
      :title="modalTitle"
      :positive-text="'确定'"
      :negative-text="'取消'"
      @positive-click="handleSubmit"
    >
      <n-form
        ref="formRef"
        :model="formData"
        :rules="rules"
        label-placement="left"
        label-width="auto"
        require-mark-placement="right-hanging"
      >
        <n-form-item label="身份证号（必填）" path="idCard">
          <n-input 
            v-model:value="formData.idCard" 
            placeholder="18位身份证号，X大写"
            :maxlength="18"
            @input="handleIdCardInput"
          />
        </n-form-item>
        
        <n-form-item label="姓名" path="name">
          <n-input v-model:value="formData.name" placeholder="请输入姓名" />
        </n-form-item>
        
        <n-form-item label="性别" path="gender">
          <n-radio-group v-model:value="formData.gender">
            <n-radio :value="1">男</n-radio>
            <n-radio :value="0">女</n-radio>
          </n-radio-group>
        </n-form-item>
        
        <n-form-item label="学号（选填）" path="studentNo">
          <n-input v-model:value="formData.studentNo" placeholder="新生可暂不填写" />
        </n-form-item>
        
        <n-form-item label="手机号" path="phone">
          <n-input v-model:value="formData.phone" placeholder="请输入手机号" />
        </n-form-item>
        
        <n-form-item label="邮箱" path="email">
          <n-input v-model:value="formData.email" placeholder="请输入邮箱" />
        </n-form-item>
        
        <n-form-item label="班级" path="className">
          <n-input v-model:value="formData.className" placeholder="请输入班级" />
        </n-form-item>
        
        <n-form-item label="专业" path="major">
          <n-input v-model:value="formData.major" placeholder="请输入专业" />
        </n-form-item>
        
        <n-form-item label="年级" path="grade">
          <n-input v-model:value="formData.grade" placeholder="请输入年级" />
        </n-form-item>
        
        <n-form-item v-if="!formData.id" label="密码（选填）" path="password">
          <n-input
            v-model:value="formData.password"
            type="password"
            placeholder="学生实际用身份证后六位登录"
          />
        </n-form-item>
      </n-form>
    </n-modal>

    <!-- 分配宿舍对话框 -->
    <n-modal
      v-model:show="showDormModal"
      preset="dialog"
      :title="currentStudent?.dormitoryInfo && currentStudent.dormitoryInfo !== '未分配' ? '已分配宿舍' : '分配宿舍'"
      :positive-text="'确定分配'"
      :negative-text="'取消'"
      @positive-click="handleAssignDorm"
    >
      <n-tabs v-if="currentStudent?.dormitoryInfo && currentStudent.dormitoryInfo !== '未分配'" type="line" animated>
        <n-tab-pane name="current" tab="当前宿舍">
          <div style="padding: 12px 0;">
            <n-form label-placement="left" label-width="100px">
              <n-form-item label="学生信息">
                <div style="color: #666;">
                  {{ currentStudent?.name }} ({{ currentStudent?.studentNo || '暂无学号' }})
                </div>
              </n-form-item>
              <n-form-item label="当前宿舍">
                <n-tag type="success" size="large">{{ currentStudent.dormitoryInfo }}</n-tag>
              </n-form-item>
            </n-form>
          </div>
        </n-tab-pane>
        <n-tab-pane name="assign" tab="已分配宿舍">
          <n-form
            ref="dormFormRef"
            :model="dormFormData"
            label-placement="left"
            label-width="100px"
          >
            <n-form-item label="选择宿舍" path="dormitoryId">
              <n-select
                v-model:value="dormFormData.dormitoryId"
                :options="availableDormitories"
                placeholder="请选择宿舍"
                filterable
                clearable
                @update:value="handleDormSelect"
              />
            </n-form-item>

            <n-form-item label="床位号" path="bedNo">
              <n-input v-model:value="dormFormData.bedNo" placeholder="如：1号床" />
            </n-form-item>

            <n-form-item label="入住日期" path="checkInDate">
              <n-date-picker 
                v-model:formatted-value="dormFormData.checkInDate"
                type="date"
                value-format="yyyy-MM-dd"
                style="width: 100%"
              />
            </n-form-item>

            <n-alert 
              v-if="selectedDormInfo" 
              type="info" 
              :title="'宿舍详情'"
              style="margin-top: 12px;"
            >
              <div>楼栋：{{ selectedDormInfo.buildingName }}</div>
              <div>房间号：{{ selectedDormInfo.roomNo }}</div>
              <div>可住人数：{{ selectedDormInfo.capacity }}</div>
              <div>已住人数：{{ selectedDormInfo.occupied }}</div>
              <div style="color: #8b7ec8; font-weight: 600;">
                剩余床位：{{ selectedDormInfo.capacity - selectedDormInfo.occupied }}
              </div>
            </n-alert>
          </n-form>
        </n-tab-pane>
      </n-tabs>

      <n-form
        v-else
        ref="dormFormRef"
        :model="dormFormData"
        label-placement="left"
        label-width="100px"
      >
        <n-form-item label="学生信息">
          <div style="color: #666;">
            {{ currentStudent?.name }} ({{ currentStudent?.studentNo || '暂无学号' }})
          </div>
        </n-form-item>

        <n-form-item label="选择宿舍" path="dormitoryId">
          <n-select
            v-model:value="dormFormData.dormitoryId"
            :options="availableDormitories"
            placeholder="请选择宿舍"
            filterable
            clearable
            @update:value="handleDormSelect"
          />
        </n-form-item>

        <n-form-item label="床位号" path="bedNo">
          <n-input v-model:value="dormFormData.bedNo" placeholder="如：1号床" />
        </n-form-item>

        <n-form-item label="入住日期" path="checkInDate">
          <n-date-picker 
            v-model:formatted-value="dormFormData.checkInDate"
            type="date"
            value-format="yyyy-MM-dd"
            style="width: 100%"
          />
        </n-form-item>

        <n-alert 
          v-if="selectedDormInfo" 
          type="info" 
          :title="'宿舍详情'"
          style="margin-top: 12px;"
        >
          <div>楼栋：{{ selectedDormInfo.buildingName }}</div>
          <div>房间号：{{ selectedDormInfo.roomNo }}</div>
          <div>可住人数：{{ selectedDormInfo.capacity }}</div>
          <div>已住人数：{{ selectedDormInfo.occupied }}</div>
          <div style="color: #8b7ec8; font-weight: 600;">
            剩余床位：{{ selectedDormInfo.capacity - selectedDormInfo.occupied }}
          </div>
        </n-alert>
      </n-form>
    </n-modal>
  </div>
</template>

<script setup>
import { ref, reactive, h, computed } from 'vue'
import { useMessage, useDialog, NButton, NTag, NSpace, NTabs, NTabPane } from 'naive-ui'
import { AddOutline, RefreshOutline, SearchOutline, CreateOutline, TrashOutline } from '@vicons/ionicons5'
import { getStudentPage, addStudent, updateStudent, deleteStudent } from '@/api/student'
import { getAvailableDormitories, assignDormitory } from '@/api/dormitory'

const message = useMessage()
const dialog = useDialog()

const loading = ref(false)
const showModal = ref(false)
const modalTitle = ref('新增学生')
const formRef = ref(null)

const queryParams = reactive({
  pageNum: 1,
  pageSize: 10,
  keyword: ''
})

const tableData = ref([])
const pagination = reactive({
  page: 1,
  pageSize: 10,
  pageCount: 1,
  itemCount: 0,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  onChange: (page) => {
    queryParams.pageNum = page
    fetchData()
  },
  onUpdatePageSize: (pageSize) => {
    queryParams.pageSize = pageSize
    queryParams.pageNum = 1
    fetchData()
  }
})

const formData = reactive({
  id: null,
  studentNo: '',
  name: '',
  gender: 1,
  idCard: '',
  phone: '',
  email: '',
  className: '',
  major: '',
  grade: '',
  password: ''
})

const rules = {
  name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
  gender: [{ required: true, type: 'number', message: '请选择性别', trigger: 'change' }],
  idCard: [
    { required: true, message: '请输入身份证号', trigger: 'blur' },
    { 
      validator: (rule, value) => {
        if (value && value.length !== 18) {
          return new Error('身份证号必须为18位')
        }
        return true
      },
      trigger: 'blur'
    }
  ]
}

const columns = [
  { title: '学号', key: 'studentNo', width: 120 },
  { title: '姓名', key: 'name', width: 100 },
  { title: '身份证号', key: 'idCard', width: 180 },
  {
    title: '性别',
    key: 'genderText',
    width: 80,
    render: (row) => {
      return h(NTag, { type: row.gender === 1 ? 'info' : 'error', size: 'small' }, 
        { default: () => row.genderText })
    }
  },
  { title: '班级', key: 'className', width: 120 },
  { title: '专业', key: 'major', width: 120 },
  { title: '手机号', key: 'phone', width: 120 },
  { 
    title: '宿舍信息', 
    key: 'dormitoryInfo', 
    width: 150,
    render: (row) => {
      if (row.dormitoryInfo && row.dormitoryInfo !== '未分配') {
        return h(NTag, { type: 'success', size: 'small' }, 
          { default: () => row.dormitoryInfo })
      } else {
        return h(NTag, { type: 'default', size: 'small' }, 
          { default: () => '可分配' })
      }
    }
  },
  {
    title: '状态',
    key: 'statusText',
    width: 80,
    render: (row) => {
      return h(NTag, { type: row.status === 1 ? 'success' : 'default', size: 'small' }, 
        { default: () => row.statusText })
    }
  },
  {
    title: '操作',
    key: 'actions',
    width: 220,
    fixed: 'right',
    render: (row) => {
      return h(NSpace, null, {
        default: () => [
          h(NButton, 
            { text: true, type: 'info', onClick: () => handleAssignDormDialog(row) },
            { default: () => '分配宿舍' }
          ),
          h(NButton, 
            { text: true, type: 'primary', onClick: () => handleEdit(row) },
            { default: () => '编辑' }
          ),
          h(NButton,
            { text: true, type: 'error', onClick: () => handleDelete(row.id) },
            { default: () => '删除' }
          )
        ]
      })
    }
  }
]

const showDormModal = ref(false)
const dormFormRef = ref(null)
const currentStudent = ref(null)
const dormFormData = ref({
  studentId: null,
  dormitoryId: null,
  bedNo: '',
  checkInDate: new Date().toISOString().split('T')[0]
})
const selectedDormInfo = ref(null)
const dormitoryList = ref([])

const availableDormitories = computed(() => {
  return dormitoryList.value
    .filter(dorm => dorm.available > 0)
    .map(dorm => ({
      label: `${dorm.buildingName} ${dorm.roomNo} (剩余${dorm.available}个床位)`,
      value: dorm.id,
      disabled: dorm.available === 0
    }))
})

const fetchAvailableDormitories = async () => {
  try {
    const res = await getAvailableDormitories()
    dormitoryList.value = res.data || []
  } catch (error) {
    console.error('获取可用宿舍失败：', error)
    message.error('获取可用宿舍失败')
  }
}

const handleAssignDormDialog = async (row) => {
  currentStudent.value = row
  await fetchAvailableDormitories()
  
  let existingDormId = null
  if (row.dormitoryInfo && row.dormitoryInfo !== '未分配') {
    const existingDorm = dormitoryList.value.find(d => 
      `${d.buildingName}-${d.roomNo}` === row.dormitoryInfo
    )
    if (existingDorm) {
      existingDormId = existingDorm.id
      selectedDormInfo.value = existingDorm
    }
  }
  
  dormFormData.value = {
    studentId: row.id,
    dormitoryId: existingDormId,
    bedNo: '',
    checkInDate: new Date().toISOString().split('T')[0]
  }
  
  showDormModal.value = true
}

const handleDormSelect = (dormId) => {
  if (dormId) {
    selectedDormInfo.value = dormitoryList.value.find(d => d.id === dormId)
  } else {
    selectedDormInfo.value = null
  }
}

const handleAssignDorm = async () => {
  if (!dormFormData.value.dormitoryId) {
    message.warning('请选择宿舍')
    return false
  }

  const selectedDorm = dormitoryList.value.find(d => d.id === dormFormData.value.dormitoryId)
  
  if (selectedDorm.available <= 0) {
    message.error('该宿舍床位已满，无法分配！')
    return false
  }

  try {
    await assignDormitory({
      studentId: dormFormData.value.studentId,
      dormitoryId: dormFormData.value.dormitoryId,
      bedNo: dormFormData.value.bedNo,
      checkInDate: dormFormData.value.checkInDate,
      assignType: 1,
      remark: ''
    })
    
    message.success('分配宿舍成功')
    showDormModal.value = false
    fetchData()
    return true
  } catch (error) {
    console.error('分配失败：', error)
    return false
  }
}

const fetchData = async () => {
  loading.value = true
  try {
    const res = await getStudentPage(queryParams)
    tableData.value = res.data.records
    pagination.itemCount = res.data.totalRow
    pagination.pageCount = Math.ceil(res.data.totalRow / queryParams.pageSize)
  } catch (error) {
    console.error('获取学生列表失败：', error)
  } finally {
    loading.value = false
  }
}

// 身份证号输入处理：自动转大写，限制18位
const handleIdCardInput = () => {
  if (formData.idCard) {
    formData.idCard = formData.idCard.toUpperCase()
    if (formData.idCard.length > 18) {
      formData.idCard = formData.idCard.slice(0, 18)
    }
  }
}

const handleSearch = () => {
  queryParams.pageNum = 1
  fetchData()
}

const handleRefresh = () => {
  queryParams.keyword = ''
  queryParams.pageNum = 1
  fetchData()
}

const handleAdd = () => {
  modalTitle.value = '新增学生'
  resetForm()
  showModal.value = true
}

const handleEdit = (row) => {
  modalTitle.value = '编辑学生'
  Object.assign(formData, row)
  showModal.value = true
}

const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
    
    if (formData.id) {
      await updateStudent(formData)
      message.success('更新成功')
    } else {
      await addStudent(formData)
      message.success('新增成功')
    }
    
    showModal.value = false
    fetchData()
  } catch (error) {
    console.error('提交失败：', error)
    return false
  }
}

const handleDelete = (id) => {
  dialog.warning({
    title: '确认删除',
    content: '确定要删除该学生吗？',
    positiveText: '确定',
    negativeText: '取消',
    onPositiveClick: async () => {
      try {
        await deleteStudent(id)
        message.success('删除成功')
        fetchData()
      } catch (error) {
        console.error('删除失败：', error)
      }
    }
  })
}

const resetForm = () => {
  formData.id = null
  formData.studentNo = ''
  formData.name = ''
  formData.gender = 1
  formData.idCard = ''
  formData.phone = ''
  formData.email = ''
  formData.className = ''
  formData.major = ''
  formData.grade = ''
  formData.password = ''
}

fetchData()
</script>

<style scoped>
.modern-page {
  position: relative;
  min-height: 100vh;
  padding: 24px;
}

.background-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #f3f4d6 0%, #c6ccff 100%);
  top: -200px;
  left: -200px;
  animation-delay: 0s;
}

.orb-2 {
  width: 350px;
  height: 350px;
  background: linear-gradient(135deg, #ebecde 0%, #cfd4f7 100%);
  top: 40%;
  right: -180px;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #dde0ea 0%, #c6ccff 100%);
  bottom: -150px;
  left: 30%;
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(50px, -50px) scale(1.1); }
  66% { transform: translate(-50px, 50px) scale(0.9); }
}

.page-header {
  position: relative;
  z-index: 1;
  margin-bottom: 24px;
}

.page-title {
  font-size: 32px;
  font-weight: 700;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 12px;
}

.page-subtitle {
  font-size: 14px;
  color: #64748b;
  margin: 8px 0 0 48px;
}

.action-bar {
  position: relative;
  z-index: 1;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
  flex-wrap: wrap;
}

.action-left {
  display: flex;
  gap: 12px;
}

.modern-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(139, 126, 200, 0.15);
}

.btn-icon {
  width: 18px;
  height: 18px;
}

.btn-primary {
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  color: white;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(198, 204, 255, 0.4);
}

.btn-secondary {
  background: white;
  color: #8b7ec8;
  border: 2px solid #c6ccff;
}

.btn-secondary:hover {
  background: #c6ccff;
  color: white;
  transform: translateY(-2px);
}

.search-box {
  display: flex;
  gap: 12px;
  background: white;
  padding: 6px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(139, 126, 200, 0.1);
}

.modern-input {
  padding: 8px 16px;
  border: none;
  outline: none;
  font-size: 14px;
  width: 300px;
  background: transparent;
}

.search-btn {
  padding: 8px 24px;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.3s ease;
}

.search-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(198, 204, 255, 0.4);
}

.stats-grid {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-bottom: 24px;
}

.stat-card {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 24px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: 0 8px 24px rgba(139, 126, 200, 0.12);
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.6);
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(139, 126, 200, 0.2);
}

.stat-icon {
  font-size: 40px;
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 32px;
  font-weight: 700;
  line-height: 1;
  margin-bottom: 4px;
}

.stat-label {
  font-size: 13px;
  color: #64748b;
  font-weight: 500;
}

.stat-primary .stat-value {
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.stat-success .stat-value {
  background: linear-gradient(135deg, #cfd4f7 0%, #dde0ea 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.stat-warning .stat-value {
  background: linear-gradient(135deg, #c6ccff 0%, #ebecde 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.table-card {
  position: relative;
  z-index: 1;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 24px;
  box-shadow: 0 8px 32px rgba(139, 126, 200, 0.12);
  border: 1px solid rgba(255, 255, 255, 0.6);
}

.table-card :deep(.n-data-table) {
  background: transparent;
}

.table-card :deep(.n-data-table-th) {
  background: rgba(198, 204, 255, 0.15);
  color: #8b7ec8;
  font-weight: 600;
  border: none;
}

.table-card :deep(.n-data-table-tr:hover) {
  background: rgba(198, 204, 255, 0.08);
}

.table-card :deep(.n-data-table-td) {
  border: none;
}

@media (max-width: 768px) {
  .action-bar {
    flex-direction: column;
    align-items: stretch;
  }
  
  .action-left {
    flex-direction: column;
  }
  
  .search-box {
    width: 100%;
  }
  
  .modern-input {
    width: 100%;
  }
  
  .stats-grid {
    grid-template-columns: 1fr;
  }
}
</style>