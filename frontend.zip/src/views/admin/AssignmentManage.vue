<template>
  <div class="assignment-manage">
    <div class="page-header">
      <h2 class="page-title">🏠 宿舍分配管理</h2>
      <p class="page-subtitle">管理宿舍智能分配</p>
    </div>

    <!-- 系统开关 -->
    <div class="switch-section">
      <div class="switch-card" v-for="config in configs" :key="config.configKey">
        <div class="switch-info">
          <div class="switch-name">{{ getConfigName(config.configKey) }}</div>
          <div class="switch-desc">{{ config.description }}</div>
        </div>
        <n-switch
          :value="config.configValue === 'ON'"
          @update:value="(val) => updateSwitch(config.configKey, val)"
        />
      </div>
    </div>

    <!-- 操作按钮 -->
    <div class="action-section">
      <n-button
        type="primary"
        size="large"
        :loading="executing"
        @click="handleExecute"
        class="execute-btn"
      >
        🚀 执行智能分配
      </n-button>
      <n-button
        size="large"
        @click="fetchResults"
      >
        🔄 刷新结果
      </n-button>
    </div>

    <!-- 分配结果 -->
    <div class="results-section">
      <h3 class="section-title">📋 分配结果（共 {{ results.length }} 间宿舍）</h3>
      
      <div v-if="results.length === 0" class="empty-tip">
        暂无分配结果，请先执行分配算法
      </div>

      <div class="result-grid">
        <div v-for="result in results" :key="result.dormitoryId" class="result-card">
          <div class="result-header">
            <span class="dorm-name">{{ result.buildingName }} - {{ result.roomNo }}</span>
            <span class="member-count">{{ result.roommates.length }} 人</span>
          </div>
          <div class="roommate-list">
            <div v-for="(roommate, index) in result.roommates" :key="index" class="roommate-item">
              <div class="roommate-avatar">{{ roommate.name?.charAt(0) }}</div>
              <div class="roommate-info">
                <div class="roommate-name">{{ roommate.name }}</div>
                <div class="roommate-detail">{{ roommate.major }} · {{ roommate.className }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { executeAssignment, getAssignmentResults } from '@/api/assignment'
import request from '@/utils/request'

const message = useMessage()
const results = ref([])
const configs = ref([])
const executing = ref(false)

const getConfigName = (key) => {
  const names = {
    'SYSTEM_SWITCH': '系统总开关',
    'QUESTIONNAIRE_SWITCH': '问卷填写开关',
    'ASSIGN_SWITCH': '分配算法开关'
  }
  return names[key] || key
}

const fetchConfigs = async () => {
  try {
    const res = await request({
      url: '/system-config/list',
      method: 'get'
    })
    configs.value = res.data || []
  } catch (error) {
    console.error('获取系统配置失败：', error)
  }
}

const updateSwitch = async (key, value) => {
  try {
    await request({
      url: '/system-config/update',
      method: 'put',
      data: {
        configKey: key,
        configValue: value ? 'ON' : 'OFF'
      }
    })
    message.success('配置更新成功')
    fetchConfigs()
  } catch (error) {
    console.error('更新配置失败：', error)
  }
}

const handleExecute = async () => {
  executing.value = true
  try {
    const res = await executeAssignment()
    message.success(`分配完成！共分配 ${res.data} 名学生`)
    fetchResults()
  } catch (error) {
    console.error('执行分配失败：', error)
  } finally {
    executing.value = false
  }
}

const fetchResults = async () => {
  try {
    const res = await getAssignmentResults()
    results.value = res.data || []
  } catch (error) {
    console.error('获取分配结果失败：', error)
  }
}

onMounted(() => {
  fetchConfigs()
  fetchResults()
})
</script>

<style scoped>
.assignment-manage {
  padding: 24px;
}

.page-header {
  margin-bottom: 24px;
}

.page-title {
  font-size: 24px;
  font-weight: 700;
  color: #8b7ec8;
  margin-bottom: 4px;
}

.page-subtitle {
  font-size: 14px;
  color: #64748b;
}

.switch-section {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 16px;
  margin-bottom: 24px;
}

.switch-card {
  background: white;
  border-radius: 12px;
  padding: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px rgba(139, 126, 200, 0.1);
}

.switch-name {
  font-size: 15px;
  font-weight: 600;
  color: #8b7ec8;
  margin-bottom: 4px;
}

.switch-desc {
  font-size: 12px;
  color: #64748b;
}

.action-section {
  display: flex;
  gap: 12px;
  margin-bottom: 32px;
}

.execute-btn {
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  border: none;
}

.execute-btn:hover {
  background: linear-gradient(135deg, #7a6db5 0%, #b8aee0 100%);
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(198, 204, 255, 0.4);
}

.section-title {
  font-size: 18px;
  font-weight: 700;
  color: #8b7ec8;
  margin-bottom: 16px;
}

.empty-tip {
  text-align: center;
  padding: 40px;
  color: #64748b;
  background: white;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(139, 126, 200, 0.1);
}

.result-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 16px;
}

.result-card {
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(139, 126, 200, 0.1);
}

.result-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid #e5e7eb;
}

.dorm-name {
  font-size: 16px;
  font-weight: 700;
  color: #8b7ec8;
}

.member-count {
  font-size: 12px;
  color: #8b7ec8;
  font-weight: 600;
}

.roommate-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.roommate-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px;
  border-radius: 8px;
  background: #f3f7ff;
}

.roommate-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 700;
  flex-shrink: 0;
}

.roommate-name {
  font-size: 14px;
  font-weight: 600;
  color: #1f2937;
}

.roommate-detail {
  font-size: 12px;
  color: #64748b;
}
</style>