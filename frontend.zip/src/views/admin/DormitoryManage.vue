<template>
  <div class="modern-page">
    <!-- 背景装饰 -->
    <div class="background-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 页面标题 -->
    <div class="page-header">
      <h2 class="page-title">
        <span class="title-icon">🏠</span>
        宿舍管理
      </h2>
      <p class="page-subtitle">管理宿舍信息、分配床位、查看入住情况</p>
    </div>

    <!-- 操作栏 -->
    <div class="action-bar">
      <div class="action-left">
        <button class="modern-btn btn-primary" @click="handleAdd">
          <svg class="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
          </svg>
          新增宿舍
        </button>
        <button class="modern-btn btn-secondary" @click="handleRefresh">
          <svg class="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          刷新
        </button>
      </div>
      
      <div class="search-box">
        <input
          v-model="searchKeyword"
          class="modern-input"
          placeholder="🔍 搜索楼栋或房间号..."
          @keyup.enter="handleSearch"
        />
        <button class="search-btn" @click="handleSearch">搜索</button>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <div class="stat-card stat-primary">
        <div class="stat-icon">🏢</div>
        <div class="stat-content">
          <div class="stat-value">{{ tableData.length }}</div>
          <div class="stat-label">宿舍总数</div>
        </div>
      </div>
      <div class="stat-card stat-success">
        <div class="stat-icon">✅</div>
        <div class="stat-content">
          <div class="stat-value">{{ tableData.filter(d => d.status === 2).length }}</div>
          <div class="stat-label">已满宿舍</div>
        </div>
      </div>
      <div class="stat-card stat-warning">
        <div class="stat-icon">🛏️</div>
        <div class="stat-content">
          <div class="stat-value">{{ tableData.reduce((sum, d) => sum + (d.capacity - d.occupied), 0) }}</div>
          <div class="stat-label">空余床位</div>
        </div>
      </div>
    </div>

    <!-- 现代化表格卡片 -->
    <div class="table-card">
      <n-data-table
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :pagination="pagination"
        :bordered="false"
        striped
      />
    </div>

    <!-- 新增/编辑宿舍弹窗 -->
    <n-modal
      v-model:show="showModal"
      preset="dialog"
      :title="modalTitle"
      :positive-text="'确定'"
      :negative-text="'取消'"
      @positive-click="handleSubmit"
    >
      <n-form
        ref="formRef"
        :model="formData"
        :rules="rules"
        label-placement="left"
        label-width="100px"
      >
        <n-form-item label="选择楼栋" path="buildingId">
          <n-select
            v-model:value="formData.buildingId"
            :options="buildingOptions"
            placeholder="请选择楼栋"
          />
        </n-form-item>
        <n-form-item label="楼层" path="floor">
          <n-input-number 
            v-model:value="formData.floor" 
            :min="1" 
            :max="20"
            placeholder="请输入楼层" 
            style="width: 100%"
          />
        </n-form-item>
        <n-form-item label="房间号" path="roomNo">
          <n-input v-model:value="formData.roomNo" placeholder="请输入房间号，如：101" />
        </n-form-item>
        <n-form-item label="可住人数" path="capacity">
          <n-input-number 
            v-model:value="formData.capacity" 
            :min="formData.occupied || 1" 
            :max="8"
            placeholder="请输入可住人数" 
            style="width: 100%"
          />
        </n-form-item>
        <n-form-item label="已住人数" path="occupied">
          <n-input-number 
            v-model:value="formData.occupied" 
            :min="0" 
            :max="formData.capacity || 4"
            :disabled="formData.id !== null"
            placeholder="已住人数（自动计算）" 
            style="width: 100%"
          />
        </n-form-item>
        <n-form-item label="房间类型" path="roomType">
          <n-select
            v-model:value="formData.roomType"
            :options="[
              { label: '标准间', value: 'STANDARD' },
              { label: '豪华间', value: 'DELUXE' }
            ]"
            placeholder="请选择房间类型"
          />
        </n-form-item>
        <n-form-item label="设施说明" path="facilities">
          <n-input 
            v-model:value="formData.facilities" 
            type="textarea" 
            placeholder="请输入设施说明，如：空调、独立卫浴等" 
            :rows="3"
          />
        </n-form-item>
      </n-form>
    </n-modal>
  </div>
</template>

<script setup>
import { ref, reactive, h, onMounted } from 'vue'
import { NButton, NSpace, NTag, useMessage, useDialog } from 'naive-ui'
import { 
  getDormitoryPage, 
  addDormitory, 
  updateDormitory, 
  deleteDormitory 
} from '@/api/dormitory'

const message = useMessage()
const dialog = useDialog()

const loading = ref(false)
const showModal = ref(false)
const modalTitle = ref('新增宿舍')
const searchKeyword = ref('')
const formRef = ref(null)

const tableData = ref([])

const formData = ref({
  id: null,
  buildingId: null,
  roomNo: '',
  floor: 1,
  capacity: 6,
  occupied: 0,
  roomType: 'STANDARD',
  facilities: ''
})

const rules = {
  buildingId: { required: true, type: 'number', message: '请选择楼栋', trigger: 'blur' },
  roomNo: { required: true, message: '请输入房间号', trigger: 'blur' },
  floor: { required: true, type: 'number', message: '请输入楼层', trigger: 'blur' },
  capacity: { required: true, type: 'number', message: '请输入可住人数', trigger: 'blur' },
  occupied: { required: true, type: 'number', message: '请输入已住人数', trigger: 'blur' }
}

const pagination = reactive({
  page: 1,
  pageSize: 10,
  pageCount: 1,
  itemCount: 0,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  onChange: (page) => {
    pagination.page = page
    fetchData()
  },
  onUpdatePageSize: (pageSize) => {
    pagination.pageSize = pageSize
    pagination.page = 1
    fetchData()
  }
})

const buildingOptions = [
  { label: '1号楼', value: 1 },
  { label: '2号楼', value: 2 },
  { label: '3号楼', value: 3 },
  { label: '4号楼', value: 4 }
]

const getStatusTag = (row) => {
  const available = row.capacity - row.occupied
  if (available === 0) {
    return h(NTag, { type: 'error' }, { default: () => '已满' })
  } else if (available <= 1) {
    return h(NTag, { type: 'warning' }, { default: () => `剩余${available}个床位` })
  } else {
    return h(NTag, { type: 'success' }, { default: () => `剩余${available}个床位` })
  }
}

const columns = [
  { title: '楼栋', key: 'buildingName', width: 120, align: 'center' },
  { title: '房间号', key: 'roomNo', width: 120, align: 'center' },
  { title: '可住人数', key: 'capacity', width: 120, align: 'center' },
  { title: '已住人数', key: 'occupied', width: 120, align: 'center' },
  { 
    title: '状态', 
    key: 'status',
    width: 150,
    align: 'center',
    render: (row) => getStatusTag(row)
  },
  {
    title: '操作',
    key: 'actions',
    width: 180,
    align: 'center',
    fixed: 'right',
    render: (row) => {
      return h(NSpace, { justify: 'center' }, {
        default: () => [
          h(NButton, { size: 'small', type: 'primary', secondary: true, onClick: () => handleEdit(row) }, { default: () => '编辑' }),
          h(NButton, { size: 'small', type: 'error', secondary: true, onClick: () => handleDelete(row) }, { default: () => '删除' })
        ]
      })
    }
  }
]

const fetchData = async () => {
  loading.value = true
  try {
    const res = await getDormitoryPage({
      pageNum: pagination.page,
      pageSize: pagination.pageSize,
      keyword: searchKeyword.value
    })
    tableData.value = res.data.records
    pagination.itemCount = res.data.totalRow
    pagination.pageCount = Math.ceil(res.data.totalRow / pagination.pageSize)
  } catch (error) {
    console.error('获取宿舍列表失败：', error)
    message.error('获取宿舍列表失败')
  } finally {
    loading.value = false
  }
}

const handleAdd = () => {
  modalTitle.value = '新增宿舍'
  formData.value = {
    id: null,
    buildingId: null,
    roomNo: '',
    floor: 1,
    capacity: 6,
    occupied: 0,
    roomType: 'STANDARD',
    facilities: ''
  }
  showModal.value = true
}

const handleEdit = (row) => {
  modalTitle.value = '编辑宿舍'
  formData.value = { ...row }
  showModal.value = true
}

const handleDelete = (row) => {
  if (row.occupied > 0) {
    message.error('该宿舍还有学生入住，无法删除！')
    return
  }
  
  dialog.warning({
    title: '确认删除',
    content: `确定要删除 ${row.buildingName} ${row.roomNo} 吗？`,
    positiveText: '确定',
    negativeText: '取消',
    onPositiveClick: async () => {
      try {
        await deleteDormitory(row.id)
        message.success('删除成功')
        fetchData()
      } catch (error) {
        console.error('删除失败：', error)
      }
    }
  })
}

const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
    
    if (formData.value.occupied > formData.value.capacity) {
      message.error('已住人数不能超过可住人数！')
      return false
    }

    if (formData.value.id) {
      await updateDormitory(formData.value)
      message.success('修改成功')
    } else {
      await addDormitory(formData.value)
      message.success('新增成功')
    }
    
    showModal.value = false
    fetchData()
    return true
  } catch (error) {
    console.error('提交失败：', error)
    return false
  }
}

const handleRefresh = () => {
  searchKeyword.value = ''
  pagination.page = 1
  fetchData()
}

const handleSearch = () => {
  pagination.page = 1
  fetchData()
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.modern-page {
  position: relative;
  min-height: 100vh;
  padding: 24px;
}

.background-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #f3f4d6 0%, #c6ccff 100%);
  top: -200px;
  left: -200px;
  animation-delay: 0s;
}

.orb-2 {
  width: 350px;
  height: 350px;
  background: linear-gradient(135deg, #ebecde 0%, #cfd4f7 100%);
  top: 40%;
  right: -180px;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #dde0ea 0%, #c6ccff 100%);
  bottom: -150px;
  left: 30%;
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(50px, -50px) scale(1.1); }
  66% { transform: translate(-50px, 50px) scale(0.9); }
}

.page-header {
  position: relative;
  z-index: 1;
  margin-bottom: 24px;
}

.page-title {
  font-size: 32px;
  font-weight: 700;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 12px;
}

.page-subtitle {
  font-size: 14px;
  color: #64748b;
  margin: 8px 0 0 48px;
}

.action-bar {
  position: relative;
  z-index: 1;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
  flex-wrap: wrap;
}

.action-left {
  display: flex;
  gap: 12px;
}

.modern-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(139, 126, 200, 0.15);
}

.btn-icon {
  width: 18px;
  height: 18px;
}

.btn-primary {
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  color: white;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(198, 204, 255, 0.4);
}

.btn-secondary {
  background: white;
  color: #8b7ec8;
  border: 2px solid #c6ccff;
}

.btn-secondary:hover {
  background: #c6ccff;
  color: white;
  transform: translateY(-2px);
}

.search-box {
  display: flex;
  gap: 12px;
  background: white;
  padding: 6px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(139, 126, 200, 0.1);
}

.modern-input {
  padding: 8px 16px;
  border: none;
  outline: none;
  font-size: 14px;
  width: 300px;
  background: transparent;
}

.search-btn {
  padding: 8px 24px;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.3s ease;
}

.search-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(198, 204, 255, 0.4);
}

.stats-grid {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-bottom: 24px;
}

.stat-card {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 24px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: 0 8px 24px rgba(139, 126, 200, 0.12);
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.6);
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(139, 126, 200, 0.2);
}

.stat-icon {
  font-size: 40px;
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 32px;
  font-weight: 700;
  line-height: 1;
  margin-bottom: 4px;
}

.stat-label {
  font-size: 13px;
  color: #64748b;
  font-weight: 500;
}

.stat-primary .stat-value {
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.stat-success .stat-value {
  background: linear-gradient(135deg, #cfd4f7 0%, #dde0ea 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.stat-warning .stat-value {
  background: linear-gradient(135deg, #c6ccff 0%, #ebecde 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.table-card {
  position: relative;
  z-index: 1;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 24px;
  box-shadow: 0 8px 32px rgba(139, 126, 200, 0.12);
  border: 1px solid rgba(255, 255, 255, 0.6);
}

.table-card :deep(.n-data-table) {
  background: transparent;
}

.table-card :deep(.n-data-table-th) {
  background: rgba(198, 204, 255, 0.15);
  color: #8b7ec8;
  font-weight: 600;
  border: none;
}

.table-card :deep(.n-data-table-tr:hover) {
  background: rgba(198, 204, 255, 0.08);
}

.table-card :deep(.n-data-table-td) {
  border: none;
}

@media (max-width: 768px) {
  .action-bar {
    flex-direction: column;
    align-items: stretch;
  }
  
  .action-left {
    flex-direction: column;
  }
  
  .search-box {
    width: 100%;
  }
  
  .modern-input {
    width: 100%;
  }
  
  .stats-grid {
    grid-template-columns: 1fr;
  }
}
</style>