<template>
  <div class="modern-page">
    <!-- 背景装饰 -->
    <div class="background-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 页面标题 -->
    <div class="page-header">
      <h2 class="page-title">
        <span class="title-icon">🔧</span>
        报修管理
      </h2>
      <p class="page-subtitle">查看和处理学生提交的报修申请</p>
    </div>

    <!-- 操作栏 -->
    <div class="action-bar">
      <div class="action-left">
        <button class="modern-btn btn-primary" @click="handleRefresh">
          <svg class="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          刷新
        </button>
      </div>
      
      <div class="search-box">
        <input
          v-model="searchKeyword"
          class="modern-input"
          placeholder="🔍 搜索报修标题或学生..."
          @keyup.enter="handleSearch"
        />
        <button class="search-btn" @click="handleSearch">搜索</button>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <div class="stat-card stat-primary">
        <div class="stat-icon">📋</div>
        <div class="stat-content">
          <div class="stat-value">{{ pagination.itemCount }}</div>
          <div class="stat-label">报修总数</div>
        </div>
      </div>
      <div class="stat-card stat-warning">
        <div class="stat-icon">⏳</div>
        <div class="stat-content">
          <div class="stat-value">{{ tableData.filter(r => r.status === 0).length }}</div>
          <div class="stat-label">待审核</div>
        </div>
      </div>
      <div class="stat-card stat-success">
        <div class="stat-icon">✅</div>
        <div class="stat-content">
          <div class="stat-value">{{ tableData.filter(r => r.status === 3).length }}</div>
          <div class="stat-label">已完成</div>
        </div>
      </div>
    </div>

    <!-- 现代化表格卡片 -->
    <div class="table-card">
      <n-data-table
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :pagination="pagination"
        :bordered="false"
        striped
      />
    </div>

    <!-- 审核模态框（管理员） -->
    <n-modal
      v-model:show="showAuditModal"
      preset="card"
      title="审核报修申请"
      :style="{ width: '600px' }"
      :mask-closable="false"
    >
      <n-form ref="auditFormRef" :model="auditForm" label-placement="left" label-width="100px">
        <n-form-item label="审核结果" required>
          <n-select
            v-model:value="auditForm.status"
            :options="[
              { label: '通过', value: 1 },
              { label: '拒绝', value: 4 }
            ]"
          />
        </n-form-item>
        
        <n-form-item v-if="auditForm.status === 1" label="指定维修人员" required>
          <n-select
            v-model:value="auditForm.handlerId"
            :options="staffList"
            placeholder="请选择维修人员"
          />
        </n-form-item>
        
        <n-form-item v-if="auditForm.status === 4" label="拒绝原因" required>
          <n-input
            v-model:value="auditForm.rejectReason"
            type="textarea"
            placeholder="请输入拒绝原因"
            :rows="3"
          />
        </n-form-item>
      </n-form>
      
      <template #footer>
        <div style="display: flex; justify-content: flex-end; gap: 12px;">
          <n-button @click="showAuditModal = false">取消</n-button>
          <n-button type="primary" @click="submitAudit">提交</n-button>
        </div>
      </template>
    </n-modal>

    <!-- 完成模态框（维修人员） -->
    <n-modal
      v-model:show="showCompleteModal"
      preset="card"
      title="完成报修"
      :style="{ width: '600px' }"
      :mask-closable="false"
    >
      <n-form ref="completeFormRef" :model="completeForm" label-placement="left" label-width="100px">
        <n-form-item label="处理备注" required>
          <n-input
            v-model:value="completeForm.handlerRemark"
            type="textarea"
            placeholder="请输入处理备注（例如：已更换损坏部件，问题已解决）"
            :rows="4"
          />
        </n-form-item>
      </n-form>
      
      <template #footer>
        <div style="display: flex; justify-content: flex-end; gap: 12px;">
          <n-button @click="showCompleteModal = false">取消</n-button>
          <n-button type="primary" @click="submitComplete">提交</n-button>
        </div>
      </template>
    </n-modal>
  </div>
</template>

<script setup>
import { ref, reactive, h, onMounted } from 'vue'
import { useMessage, useDialog, NButton, NSpace, NTag, NModal, NForm, NFormItem, NInput, NSelect } from 'naive-ui'
import { getRepairPage, auditRepair, startRepair, completeRepair, deleteRepair, getMaintenanceStaffList } from '@/api/repair'
import { useUserStore } from '@/stores/user'

const message = useMessage()
const dialog = useDialog()
const userStore = useUserStore()

const loading = ref(false)
const searchKeyword = ref('')
const tableData = ref([])
const staffList = ref([])
const showAuditModal = ref(false)
const showCompleteModal = ref(false)
const auditFormRef = ref(null)
const completeFormRef = ref(null)

const auditForm = reactive({
  id: null,
  status: 1, // 1-通过，4-拒绝
  handlerId: null,
  rejectReason: ''
})

const completeForm = reactive({
  id: null,
  status: 3, // 3-已完成
  handlerRemark: ''
})

const pagination = reactive({
  page: 1,
  pageSize: 10,
  pageCount: 1,
  itemCount: 0,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  onChange: (page) => {
    pagination.page = page
    fetchData()
  },
  onUpdatePageSize: (pageSize) => {
    pagination.pageSize = pageSize
    pagination.page = 1
    fetchData()
  }
})

// 状态映射
const statusMap = {
  0: { text: '待审核', type: 'warning' },
  1: { text: '已接受', type: 'info' },
  2: { text: '处理中', type: 'primary' },
  3: { text: '已完成', type: 'success' },
  4: { text: '已拒绝', type: 'error' }
}

const columns = [
  { title: '报修标题', key: 'title', width: 180 },
  { title: '学生姓名', key: 'studentName', width: 100 },
  { title: '宿舍位置', key: 'dormitoryLocation', width: 100 },
  { title: '报修类型', key: 'repairTypeText', width: 100 },
  { 
    title: '状态', 
    key: 'status',
    width: 100,
    render: (row) => {
      const status = statusMap[row.status] || { text: '未知', type: 'default' }
      return h(NTag, { type: status.type, size: 'small' }, { default: () => status.text })
    }
  },
  { title: '处理人', key: 'handlerName', width: 100 },
  { title: '提交时间', key: 'createTime', width: 160 },
  {
    title: '操作',
    key: 'actions',
    width: 250,
    fixed: 'right',
    render: (row) => {
      const actions = []
      const userRole = userStore.userInfo?.role
      
      // 管理员：审核待审核的报修
      if (userRole === 'ADMIN') {
        if (row.status === 0) {
          actions.push(
            h(NButton, 
              { text: true, type: 'primary', size: 'small', onClick: () => handleAudit(row) },
              { default: () => '审核' }
            )
          )
        }
        
        // 管理员可以删除已完成或已拒绝的记录
        if (row.status === 3 || row.status === 4) {
          actions.push(
            h(NButton, 
              { text: true, type: 'error', size: 'small', onClick: () => handleDeleteRepair(row) },
              { default: () => '删除' }
            )
          )
        }
      }
      
      // 维修人员：处理已接受和处理中的报修
      if (userRole === 'STAFF') {
        // 已接受状态：可以开始处理
        if (row.status === 1) {
          actions.push(
            h(NButton, 
              { text: true, type: 'primary', size: 'small', onClick: () => handleStartProcess(row) },
              { default: () => '开始处理' }
            )
          )
        }
        
        // 处理中状态：可以完成
        if (row.status === 2) {
          actions.push(
            h(NButton, 
              { text: true, type: 'success', size: 'small', onClick: () => handleCompleteRepair(row) },
              { default: () => '完成' }
            )
          )
        }
      }
      
      // 查看详情（所有角色都可以）
      actions.push(
        h(NButton, 
          { text: true, type: 'info', size: 'small', onClick: () => handleViewDetail(row) },
          { default: () => '详情' }
        )
      )
      
      return h(NSpace, null, { default: () => actions })
    }
  }
]

// 获取报修列表
const fetchData = async () => {
  loading.value = true
  try {
    const res = await getRepairPage({
      pageNum: pagination.page,
      pageSize: pagination.pageSize,
      keyword: searchKeyword.value
    })
    tableData.value = res.data.records || []
    pagination.itemCount = res.data.totalRow || 0
    pagination.pageCount = Math.ceil(pagination.itemCount / pagination.pageSize)
  } catch (error) {
    console.error('获取报修列表失败：', error)
  } finally {
    loading.value = false
  }
}

// 获取维修人员列表
const fetchStaffList = async () => {
  try {
    const res = await getMaintenanceStaffList()
    staffList.value = res.data.map(staff => ({
      label: staff.name,
      value: staff.id
    }))
  } catch (error) {
    console.error('获取维修人员列表失败：', error)
  }
}

// 管理员：审核报修
const handleAudit = (row) => {
  auditForm.id = row.id
  auditForm.status = 1
  auditForm.handlerId = null
  auditForm.rejectReason = ''
  showAuditModal.value = true
}

// 提交审核
const submitAudit = async () => {
  try {
    await auditFormRef.value?.validate()
    
    if (auditForm.status === 1 && !auditForm.handlerId) {
      message.warning('通过审核时必须指定维修人员')
      return
    }
    
    if (auditForm.status === 4 && !auditForm.rejectReason) {
      message.warning('拒绝时必须填写拒绝原因')
      return
    }
    
    await auditRepair(auditForm)
    message.success(auditForm.status === 1 ? '审核通过' : '已拒绝')
    showAuditModal.value = false
    fetchData()
  } catch (error) {
    console.error('审核失败：', error)
  }
}

// 维修人员：开始处理
const handleStartProcess = (row) => {
  dialog.info({
    title: '开始处理',
    content: `确定开始处理报修：${row.title}？`,
    positiveText: '确定',
    negativeText: '取消',
    onPositiveClick: async () => {
      try {
        await startRepair(row.id)
        message.success('已开始处理')
        fetchData()
      } catch (error) {
        console.error('操作失败：', error)
      }
    }
  })
}

// 维修人员：完成报修
const handleCompleteRepair = (row) => {
  completeForm.id = row.id
  completeForm.status = 3 // 3-已完成
  completeForm.handlerRemark = ''
  showCompleteModal.value = true
}

// 提交完成
const submitComplete = async () => {
  try {
    await completeFormRef.value?.validate()
    
    if (!completeForm.handlerRemark) {
      message.warning('请填写处理备注')
      return
    }
    
    await completeRepair(completeForm)
    message.success('报修已完成')
    showCompleteModal.value = false
    fetchData()
  } catch (error) {
    console.error('完成失败：', error)
  }
}

// 查看详情
const handleViewDetail = (row) => {
  const details = [
    h('p', { style: 'margin: 8px 0;' }, [
      h('strong', '报修标题：'),
      h('span', row.title)
    ]),
    h('p', { style: 'margin: 8px 0;' }, [
      h('strong', '学生姓名：'),
      h('span', row.studentName)
    ]),
    h('p', { style: 'margin: 8px 0;' }, [
      h('strong', '学号：'),
      h('span', row.studentNo || '-')
    ]),
    h('p', { style: 'margin: 8px 0;' }, [
      h('strong', '宿舍位置：'),
      h('span', row.dormitoryLocation)
    ]),
    h('p', { style: 'margin: 8px 0;' }, [
      h('strong', '报修类型：'),
      h('span', row.repairTypeText)
    ]),
    h('p', { style: 'margin: 8px 0;' }, [
      h('strong', '问题描述：'),
      h('span', row.description || '无')
    ]),
    h('p', { style: 'margin: 8px 0;' }, [
      h('strong', '当前状态：'),
      h(NTag, { 
        type: statusMap[row.status]?.type, 
        size: 'small',
        style: 'margin-left: 8px;'
      }, { default: () => statusMap[row.status]?.text })
    ]),
    h('p', { style: 'margin: 8px 0;' }, [
      h('strong', '提交时间：'),
      h('span', row.createTime)
    ])
  ]
  
  // 如果有处理人信息
  if (row.handlerName) {
    details.push(
      h('p', { style: 'margin: 8px 0;' }, [
        h('strong', '处理人：'),
        h('span', row.handlerName)
      ])
    )
  }
  
  // 如果有处理时间
  if (row.handleTime) {
    details.push(
      h('p', { style: 'margin: 8px 0;' }, [
        h('strong', '处理时间：'),
        h('span', row.handleTime)
      ])
    )
  }
  
  // 如果有处理备注
  if (row.handlerRemark) {
    details.push(
      h('p', { style: 'margin: 8px 0;' }, [
        h('strong', '处理备注：'),
        h('span', row.handlerRemark)
      ])
    )
  }
  
  // 如果有完成时间
  if (row.completeTime) {
    details.push(
      h('p', { style: 'margin: 8px 0;' }, [
        h('strong', '完成时间：'),
        h('span', row.completeTime)
      ])
    )
  }
  
  // 如果有拒绝原因
  if (row.rejectReason) {
    details.push(
      h('p', { style: 'margin: 8px 0; color: #d03050;' }, [
        h('strong', '拒绝原因：'),
        h('span', row.rejectReason)
      ])
    )
  }
  
  dialog.info({
    title: '报修详情',
    content: () => h('div', { style: 'padding: 12px 0;' }, details),
    positiveText: '关闭',
    style: { width: '500px' }
  })
}

// 删除报修记录
const handleDeleteRepair = (row) => {
  dialog.error({
    title: '删除报修',
    content: `确定删除报修记录：${row.title}？`,
    positiveText: '确定',
    negativeText: '取消',
    onPositiveClick: async () => {
      try {
        await deleteRepair(row.id)
        message.success('删除成功')
        fetchData()
      } catch (error) {
        console.error('删除失败：', error)
      }
    }
  })
}

// 刷新
const handleRefresh = () => {
  searchKeyword.value = ''
  pagination.page = 1
  fetchData()
}

// 搜索
const handleSearch = () => {
  pagination.page = 1
  fetchData()
}

// 初始化数据
onMounted(() => {
  fetchData()
  fetchStaffList()
})
</script>

<style scoped>
/* 现代化页面容器 */
.modern-page {
  position: relative;
  min-height: 100vh;
  padding: 24px;
}

/* 背景装饰 */
.background-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.6;
  animation: float 20s ease-in-out infinite;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  top: -200px;
  left: -200px;
  animation-delay: 0s;
}

.orb-2 {
  width: 350px;
  height: 350px;
  background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
  top: 40%;
  right: -180px;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #ec4899 0%, #db2777 100%);
  bottom: -150px;
  left: 30%;
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(50px, -50px) scale(1.1);
  }
  66% {
    transform: translate(-50px, 50px) scale(0.9);
  }
}

/* 页面标题 */
.page-header {
  position: relative;
  z-index: 1;
  margin-bottom: 24px;
  animation: slideDown 0.6s ease-out;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.page-title {
  font-size: 32px;
  font-weight: 700;
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 36px;
  filter: drop-shadow(0 4px 8px rgba(0,0,0,0.1));
}

.page-subtitle {
  font-size: 14px;
  color: #64748b;
  margin: 8px 0 0 48px;
}

/* 操作栏 */
.action-bar {
  position: relative;
  z-index: 1;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
  flex-wrap: wrap;
  animation: slideUp 0.6s ease-out 0.1s both;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.action-left {
  display: flex;
  gap: 12px;
}

/* 现代化按钮 */
.modern-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.btn-icon {
  width: 18px;
  height: 18px;
}

.btn-primary {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  color: white;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(245, 158, 11, 0.4);
}

.btn-secondary {
  background: white;
  color: #f59e0b;
  border: 2px solid #f59e0b;
}

.btn-secondary:hover {
  background: #f59e0b;
  color: white;
  transform: translateY(-2px);
}

/* 搜索框 */
.search-box {
  display: flex;
  gap: 12px;
  background: white;
  padding: 6px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.modern-input {
  padding: 8px 16px;
  border: none;
  outline: none;
  font-size: 14px;
  width: 300px;
  background: transparent;
}

.search-btn {
  padding: 8px 24px;
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.3s ease;
}

.search-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4);
}

/* 统计卡片 */
.stats-grid {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-bottom: 24px;
  animation: slideUp 0.6s ease-out 0.2s both;
}

.stat-card {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 24px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.6);
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
}

.stat-icon {
  font-size: 40px;
  filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 32px;
  font-weight: 700;
  line-height: 1;
  margin-bottom: 4px;
}

.stat-label {
  font-size: 13px;
  color: #64748b;
  font-weight: 500;
}

.stat-primary .stat-value {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.stat-warning .stat-value {
  background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.stat-success .stat-value {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* 表格卡片 */
.table-card {
  position: relative;
  z-index: 1;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 24px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.6);
  animation: slideUp 0.6s ease-out 0.3s both;
}

/* 覆盖表格样式 */
.table-card :deep(.n-data-table) {
  background: transparent;
}

.table-card :deep(.n-data-table-th) {
  background: rgba(245, 158, 11, 0.1);
  color: #f59e0b;
  font-weight: 600;
  border: none;
}

.table-card :deep(.n-data-table-tr:hover) {
  background: rgba(245, 158, 11, 0.05);
}

.table-card :deep(.n-data-table-td) {
  border: none;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .action-bar {
    flex-direction: column;
    align-items: stretch;
  }
  
  .action-left {
    flex-direction: column;
  }
  
  .search-box {
    width: 100%;
  }
  
  .modern-input {
    width: 100%;
  }
  
  .stats-grid {
    grid-template-columns: 1fr;
  }
}
</style>


