<template>
  <div class="modern-page">
    <!-- 背景装饰 -->
    <div class="background-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 页面标题 -->
    <div class="page-header">
      <h2 class="page-title">
        <span class="title-icon">📢</span>
        公告管理
      </h2>
      <p class="page-subtitle">发布和管理系统公告通知</p>
    </div>

    <!-- 操作栏 -->
    <div class="action-bar">
      <div class="action-left">
        <button class="modern-btn btn-primary" @click="handleAdd">
          <svg class="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
          </svg>
          发布公告
        </button>
        <button class="modern-btn btn-secondary" @click="handleRefresh">
          <svg class="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          刷新
        </button>
      </div>
      
      <div class="search-box">
        <input
          v-model="searchKeyword"
          class="modern-input"
          placeholder="🔍 搜索公告标题..."
          @keyup.enter="handleSearch"
        />
        <button class="search-btn" @click="handleSearch">搜索</button>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <div class="stat-card stat-primary">
        <div class="stat-icon">📝</div>
        <div class="stat-content">
          <div class="stat-value">{{ tableData.length }}</div>
          <div class="stat-label">公告总数</div>
        </div>
      </div>
      <div class="stat-card stat-success">
        <div class="stat-icon">✅</div>
        <div class="stat-content">
          <div class="stat-value">{{ tableData.filter(n => n.status === 1).length }}</div>
          <div class="stat-label">已发布</div>
        </div>
      </div>
      <div class="stat-card stat-warning">
        <div class="stat-icon">📅</div>
        <div class="stat-content">
          <div class="stat-value">本月</div>
          <div class="stat-label">最近更新</div>
        </div>
      </div>
    </div>

    <!-- 现代化表格卡片 -->
    <div class="table-card">
      <n-data-table
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :bordered="false"
        :pagination="pagination"
        striped
      />
    </div>

    <!-- 发布/编辑公告弹窗 -->
    <n-modal
      v-model:show="showModal"
      preset="card"
      :title="modalTitle"
      style="width: 800px;"
      :segmented="{ content: 'soft', footer: 'soft' }"
    >
      <n-form
        ref="formRef"
        :model="formData"
        :rules="rules"
        label-placement="left"
        label-width="100px"
      >
        <n-form-item label="公告标题" path="title">
          <n-input
            v-model:value="formData.title"
            placeholder="请输入公告标题"
            maxlength="200"
            show-count
          />
        </n-form-item>

        <n-form-item label="公告类型" path="noticeType">
          <n-radio-group v-model:value="formData.noticeType">
            <n-space>
              <n-radio value="SYSTEM">系统公告</n-radio>
              <n-radio value="ACTIVITY">活动通知</n-radio>
              <n-radio value="MAINTENANCE">维修通知</n-radio>
            </n-space>
          </n-radio-group>
        </n-form-item>

        <n-form-item label="优先级" path="priority">
          <n-radio-group v-model:value="formData.priority">
            <n-space>
              <n-radio :value="0">低</n-radio>
              <n-radio :value="1">中</n-radio>
              <n-radio :value="2">高</n-radio>
            </n-space>
          </n-radio-group>
        </n-form-item>

        <n-form-item label="目标角色" path="targetRole">
          <n-radio-group v-model:value="formData.targetRole">
            <n-space>
              <n-radio value="ALL">所有人</n-radio>
              <n-radio value="STUDENT">学生</n-radio>
              <n-radio value="STAFF">维修人员</n-radio>
            </n-space>
          </n-radio-group>
        </n-form-item>

        <n-form-item label="是否置顶" path="isTop">
          <n-switch v-model:value="formData.isTop" />
        </n-form-item>

        <n-form-item label="公告内容" path="content">
          <n-input
            v-model:value="formData.content"
            type="textarea"
            placeholder="请输入公告内容"
            :rows="10"
            maxlength="5000"
            show-count
          />
        </n-form-item>
      </n-form>

      <template #footer>
        <n-space justify="end">
          <n-button @click="showModal = false">取消</n-button>
          <n-button type="primary" @click="handleSubmit" :loading="submitLoading">
            {{ formData.id ? '保存' : '发布' }}
          </n-button>
        </n-space>
      </template>
    </n-modal>
  </div>
</template>

<script setup>
import { ref, reactive, h, onMounted } from 'vue'
import { NButton, NTag, NSpace, NSwitch, NRadio, NRadioGroup, useMessage, useDialog } from 'naive-ui'
import { getNoticePage, publishNotice, updateNotice, deleteNotice } from '@/api/notice'
import { useUserStore } from '@/stores/user'

const message = useMessage()
const dialog = useDialog()
const userStore = useUserStore()

const loading = ref(false)
const tableData = ref([])
const searchKeyword = ref('')
const showModal = ref(false)
const modalTitle = ref('')
const formRef = ref(null)
const submitLoading = ref(false)

// 表单数据
const formData = ref({
  id: null,
  title: '',
  content: '',
  noticeType: 'SYSTEM',
  priority: 1,
  targetRole: 'ALL',
  isTop: false
})

// 校验规则
const rules = {
  title: {
    required: true,
    message: '请输入公告标题',
    trigger: 'blur'
  },
  content: {
    required: true,
    message: '请输入公告内容',
    trigger: 'blur'
  },
  noticeType: {
    required: true,
    message: '请选择公告类型',
    trigger: 'change'
  },
  priority: {
    required: true,
    type: 'number',
    message: '请选择优先级',
    trigger: 'change'
  },
  targetRole: {
    required: true,
    message: '请选择目标角色',
    trigger: 'change'
  }
}

// 分页参数
const pagination = reactive({
  page: 1,
  pageSize: 10,
  itemCount: 0,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
  onChange: (page) => {
    pagination.page = page
    fetchData()
  },
  onUpdatePageSize: (pageSize) => {
    pagination.pageSize = pageSize
    pagination.page = 1
    fetchData()
  }
})

// 公告类型映射
const noticeTypeMap = {
  SYSTEM: { text: '系统公告', type: 'info' },
  ACTIVITY: { text: '活动通知', type: 'success' },
  MAINTENANCE: { text: '维修通知', type: 'warning' }
}

// 状态映射
const statusMap = {
  0: { text: '草稿', type: 'default' },
  1: { text: '已发布', type: 'success' },
  2: { text: '已过期', type: 'error' }
}

// 优先级映射
const priorityMap = {
  0: { text: '低', type: 'default' },
  1: { text: '中', type: 'info' },
  2: { text: '高', type: 'error' }
}

// 表格列定义
const columns = [
  {
    title: '标题',
    key: 'title',
    align: 'center',
    ellipsis: {
      tooltip: true
    },
    render: (row) => {
      return h('div', { style: 'display: flex; align-items: center; gap: 8px;' }, [
        row.isTop ? h(NTag, { type: 'error', size: 'small' }, { default: () => '置顶' }) : null,
        h('span', row.title)
      ])
    }
  },
  {
    title: '类型',
    key: 'noticeType',
    align: 'center',
    render: (row) => {
      const typeInfo = noticeTypeMap[row.noticeType] || { text: row.noticeType, type: 'default' }
      return h(NTag, { type: typeInfo.type }, { default: () => typeInfo.text })
    }
  },
  {
    title: '优先级',
    key: 'priority',
    align: 'center',
    render: (row) => {
      const priorityInfo = priorityMap[row.priority] || { text: '未知', type: 'default' }
      return h(NTag, { type: priorityInfo.type, size: 'small' }, { default: () => priorityInfo.text })
    }
  },
  {
    title: '目标角色',
    key: 'targetRole',
    align: 'center',
    render: (row) => {
      const roleMap = {
        ALL: '所有人',
        STUDENT: '学生',
        ADMIN: '管理员',
        STAFF: '维修人员'
      }
      return roleMap[row.targetRole] || row.targetRole
    }
  },
  {
    title: '发布人',
    key: 'publisherName',
    align: 'center'
  },
  {
    title: '发布时间',
    key: 'publishTime',
    align: 'center'
  },
  {
    title: '浏览量',
    key: 'viewCount',
    align: 'center'
  },
  {
    title: '状态',
    key: 'status',
    align: 'center',
    render: (row) => {
      const statusInfo = statusMap[row.status] || { text: '未知', type: 'default' }
      return h(NTag, { type: statusInfo.type }, { default: () => statusInfo.text })
    }
  },
  {
    title: '操作',
    key: 'actions',
    align: 'center',
    fixed: 'right',
    width: 250,
    render: (row) => {
      return h(NSpace, { justify: 'center' }, {
        default: () => [
          h(NButton, {
            size: 'small',
            type: 'info',
            onClick: () => handleViewDetail(row)
          }, { default: () => '详情' }),
          h(NButton, {
            size: 'small',
            type: 'primary',
            onClick: () => handleEdit(row)
          }, { default: () => '编辑' }),
          h(NButton, {
            size: 'small',
            type: 'error',
            onClick: () => handleDelete(row.id)
          }, { default: () => '删除' })
        ]
      })
    }
  }
]

// 获取数据
const fetchData = async () => {
  loading.value = true
  try {
    const res = await getNoticePage({
      page: pagination.page,
      pageSize: pagination.pageSize,
      keyword: searchKeyword.value
    })
    tableData.value = res.data.records
    pagination.itemCount = res.data.total
  } catch (error) {
    if (!error.showMessage) {
      message.error('获取公告列表失败')
    }
  } finally {
    loading.value = false
  }
}

// 搜索
const handleSearch = () => {
  pagination.page = 1
  fetchData()
}

// 刷新
const handleRefresh = () => {
  searchKeyword.value = ''
  pagination.page = 1
  fetchData()
}

// 发布公告
const handleAdd = () => {
  modalTitle.value = '发布公告'
  // 重置表单
  formData.value = {
    id: null,
    title: '',
    content: '',
    noticeType: 'SYSTEM',
    priority: 1,
    targetRole: 'ALL',
    isTop: false
  }
  showModal.value = true
}

// 编辑
const handleEdit = (row) => {
  modalTitle.value = '编辑公告'
  // 填充表单数据
  formData.value = {
    id: row.id,
    title: row.title,
    content: row.content,
    noticeType: row.noticeType,
    priority: row.priority,
    targetRole: row.targetRole,
    isTop: row.isTop === 1
  }
  showModal.value = true
}

// 提交表单
const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
    submitLoading.value = true
    
    const submitData = {
      ...formData.value,
      isTop: formData.value.isTop ? 1 : 0,
      publisherId: userStore.userInfo?.id || 1,
      publisherName: userStore.userInfo?.realName || '系统管理员'
    }
    
    if (formData.value.id) {
      // 编辑
      await updateNotice(submitData)
      message.success('更新成功')
    } else {
      // 发布
      await publishNotice(submitData)
      message.success('发布成功')
    }
    
    showModal.value = false
    fetchData()
  } catch (error) {
    if (!error.showMessage) {
      console.error('提交失败:', error)
    }
  } finally {
    submitLoading.value = false
  }
}

// 查看详情
const handleViewDetail = (row) => {
  dialog.info({
    title: row.title,
    content: () => h('div', { style: 'white-space: pre-wrap; line-height: 1.6;' }, row.content),
    positiveText: '关闭',
    style: {
      width: '600px'
    }
  })
}

// 删除
const handleDelete = (id) => {
  dialog.warning({
    title: '确认删除',
    content: '确定要删除这条公告吗？删除后将无法恢复。',
    positiveText: '确定',
    negativeText: '取消',
    onPositiveClick: async () => {
      try {
        await deleteNotice(id)
        message.success('删除成功')
        fetchData()
      } catch (error) {
        if (!error.showMessage) {
          message.error('删除失败')
        }
      }
    }
  })
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
/* 现代化页面容器 */
.modern-page {
  position: relative;
  min-height: 100vh;
  padding: 24px;
}

/* 背景装饰 */
.background-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.6;
  animation: float 20s ease-in-out infinite;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
  top: -200px;
  left: -200px;
  animation-delay: 0s;
}

.orb-2 {
  width: 350px;
  height: 350px;
  background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%);
  top: 40%;
  right: -180px;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
  bottom: -150px;
  left: 30%;
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(50px, -50px) scale(1.1);
  }
  66% {
    transform: translate(-50px, 50px) scale(0.9);
  }
}

/* 页面标题 */
.page-header {
  position: relative;
  z-index: 1;
  margin-bottom: 24px;
  animation: slideDown 0.6s ease-out;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.page-title {
  font-size: 32px;
  font-weight: 700;
  background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 36px;
  filter: drop-shadow(0 4px 8px rgba(0,0,0,0.1));
}

.page-subtitle {
  font-size: 14px;
  color: #64748b;
  margin: 8px 0 0 48px;
}

/* 操作栏 */
.action-bar {
  position: relative;
  z-index: 1;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
  flex-wrap: wrap;
  animation: slideUp 0.6s ease-out 0.1s both;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.action-left {
  display: flex;
  gap: 12px;
}

/* 现代化按钮 */
.modern-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.btn-icon {
  width: 18px;
  height: 18px;
}

.btn-primary {
  background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
  color: white;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(59, 130, 246, 0.4);
}

.btn-secondary {
  background: white;
  color: #3b82f6;
  border: 2px solid #3b82f6;
}

.btn-secondary:hover {
  background: #3b82f6;
  color: white;
  transform: translateY(-2px);
}

/* 搜索框 */
.search-box {
  display: flex;
  gap: 12px;
  background: white;
  padding: 6px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.modern-input {
  padding: 8px 16px;
  border: none;
  outline: none;
  font-size: 14px;
  width: 300px;
  background: transparent;
}

.search-btn {
  padding: 8px 24px;
  background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.3s ease;
}

.search-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
}

/* 统计卡片 */
.stats-grid {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-bottom: 24px;
  animation: slideUp 0.6s ease-out 0.2s both;
}

.stat-card {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 24px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.6);
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
}

.stat-icon {
  font-size: 40px;
  filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 32px;
  font-weight: 700;
  line-height: 1;
  margin-bottom: 4px;
}

.stat-label {
  font-size: 13px;
  color: #64748b;
  font-weight: 500;
}

.stat-primary .stat-value {
  background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.stat-success .stat-value {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.stat-warning .stat-value {
  background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* 表格卡片 */
.table-card {
  position: relative;
  z-index: 1;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 24px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.6);
  animation: slideUp 0.6s ease-out 0.3s both;
}

/* 覆盖表格样式 */
.table-card :deep(.n-data-table) {
  background: transparent;
}

.table-card :deep(.n-data-table-th) {
  background: rgba(59, 130, 246, 0.1);
  color: #3b82f6;
  font-weight: 600;
  border: none;
}

.table-card :deep(.n-data-table-tr:hover) {
  background: rgba(59, 130, 246, 0.05);
}

.table-card :deep(.n-data-table-td) {
  border: none;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .action-bar {
    flex-direction: column;
    align-items: stretch;
  }
  
  .action-left {
    flex-direction: column;
  }
  
  .search-box {
    width: 100%;
  }
  
  .modern-input {
    width: 100%;
  }
  
  .stats-grid {
    grid-template-columns: 1fr;
  }
}
</style>


