<template>
  <div class="min-h-full dashboard-bg p-6 relative">
    <!-- 标题区域 -->
    <div class="mb-8 relative" style="z-index: 1;">
      <h1 class="text-3xl font-bold text-gray-900 mb-2">管理页面</h1>
      <p class="text-gray-600">欢迎回来，这是您的宿舍管理概览</p>
    </div>

    <!-- 统计卡片 -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 relative" style="z-index: 1;">
      <!-- 学生总数卡片 -->
      <div class="bg-gradient-to-br from-violet-400 to-purple-400 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-purple-100 text-sm font-medium mb-1">学生总数</p>
            <h3 class="text-4xl font-bold">{{ statistics.studentCount }}</h3>
            <p class="text-purple-100 text-sm mt-2">人</p>
          </div>
          <div class="bg-white bg-opacity-20 rounded-full p-3">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
          </div>
        </div>
      </div>

      <!-- 宿舍总数卡片 -->
      <div class="bg-gradient-to-br from-purple-400 to-indigo-300 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-indigo-100 text-sm font-medium mb-1">宿舍总数</p>
            <h3 class="text-4xl font-bold">{{ statistics.dormitoryCount }}</h3>
            <p class="text-indigo-100 text-sm mt-2">间</p>
          </div>
          <div class="bg-white bg-opacity-20 rounded-full p-3">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
          </div>
        </div>
      </div>

      <!-- 已分配学生卡片 -->
      <div class="bg-gradient-to-br from-indigo-300 to-blue-300 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-indigo-100 text-sm font-medium mb-1">已分配学生</p>
            <h3 class="text-4xl font-bold">{{ statistics.pendingRepairCount }}</h3>
            <p class="text-indigo-100 text-sm mt-2">人</p>
          </div>
          <div class="bg-white bg-opacity-20 rounded-full p-3">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
        </div>
      </div>

      <!-- 本月新增公告卡片 -->
      <div class="bg-gradient-to-br from-blue-300 to-violet-300 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-violet-100 text-sm font-medium mb-1">本月新增公告</p>
            <h3 class="text-4xl font-bold">{{ statistics.noticeCount }}</h3>
            <p class="text-violet-100 text-sm mt-2">条</p>
          </div>
          <div class="bg-white bg-opacity-20 rounded-full p-3">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
            </svg>
          </div>
        </div>
      </div>
    </div>

    <!-- 图表区域 -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8 relative" style="z-index: 1;">
      <!-- 图表1 -->
      <div class="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-6">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">数据趋势</h3>
        <div style="width: 100%; height: 300px;">
          <v-chart :option="repairTrendOption" autoresize style="width: 100%; height: 100%;" />
        </div>
      </div>

      <!-- 图表2 -->
      <div class="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-6">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">宿舍入住率</h3>
        <div style="width: 100%; height: 300px;">
          <v-chart :option="occupancyOption" autoresize style="width: 100%; height: 100%;" />
        </div>
      </div>
    </div>

    <!-- 每月统计柱状图 -->
    <div class="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-6 relative" style="z-index: 1;">
      <h3 class="text-lg font-semibold text-gray-900 mb-4">每月统计对比</h3>
      <div style="width: 100%; height: 350px;">
        <v-chart :option="monthlyStatsOption" autoresize style="width: 100%; height: 100%;" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { LineChart, PieChart, BarChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent
} from 'echarts/components'
import VChart from 'vue-echarts'
import { getDashboardData } from '@/api/dashboard'

use([
  CanvasRenderer,
  LineChart,
  PieChart,
  BarChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent
])

const statistics = reactive({
  studentCount: 0,
  dormitoryCount: 0,
  pendingRepairCount: 0,
  noticeCount: 0
})

const repairTrendOption = reactive({
  tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
  grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
  xAxis: { type: 'category', boundaryGap: false, data: [] },
  yAxis: { type: 'value' },
  series: [{
    name: '数据量',
    type: 'line',
    smooth: true,
    data: [],
    areaStyle: {
      color: {
        type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
        colorStops: [
          { offset: 0, color: 'rgba(139, 126, 200, 0.5)' },
          { offset: 1, color: 'rgba(139, 126, 200, 0.05)' }
        ]
      }
    },
    lineStyle: { color: '#8b7ec8', width: 3 },
    itemStyle: { color: '#8b7ec8' }
  }]
})

const occupancyOption = reactive({
  tooltip: { trigger: 'item', formatter: '{a} <br/>{b}: {c} ({d}%)' },
  legend: { orient: 'horizontal', bottom: 10, left: 'center', itemWidth: 12, itemHeight: 12, textStyle: { fontSize: 12 } },
  series: [{
    name: '入住情况',
    type: 'pie',
    radius: ['45%', '70%'],
    center: ['50%', '45%'],
    avoidLabelOverlap: false,
    itemStyle: { borderRadius: 10, borderColor: '#fff', borderWidth: 2 },
    label: { show: true, formatter: '{b}: {d}%', fontSize: 12 },
    emphasis: { label: { show: true, fontSize: 14, fontWeight: 'bold' } },
    data: []
  }]
})

const monthlyStatsOption = reactive({
  tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
  legend: { data: ['数据一', '数据二', '数据三'], top: 10, left: 'center', itemWidth: 12, itemHeight: 12, textStyle: { fontSize: 12 } },
  grid: { left: '3%', right: '4%', bottom: '3%', top: '15%', containLabel: true },
  xAxis: { type: 'category', data: [] },
  yAxis: { type: 'value' },
  series: [
    {
      name: '数据一',
      type: 'bar',
      data: [],
      itemStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: '#8b7ec8' }, { offset: 1, color: '#c6ccff' }
        ]},
        borderRadius: [8, 8, 0, 0]
      }
    },
    {
      name: '数据二',
      type: 'bar',
      data: [],
      itemStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: '#cfd4f7' }, { offset: 1, color: '#dde0ea' }
        ]},
        borderRadius: [8, 8, 0, 0]
      }
    },
    {
      name: '数据三',
      type: 'bar',
      data: [],
      itemStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: '#ebecde' }, { offset: 1, color: '#f3f4d6' }
        ]},
        borderRadius: [8, 8, 0, 0]
      }
    }
  ]
})

const loadDashboardData = async () => {
  try {
    const res = await getDashboardData()
    const data = res.data
    
    statistics.studentCount = data.statistics.studentCount
    statistics.dormitoryCount = data.statistics.dormitoryCount
    statistics.pendingRepairCount = data.statistics.pendingRepairCount
    statistics.noticeCount = data.statistics.noticeCount
    
    repairTrendOption.xAxis.data = data.repairTrend.months
    repairTrendOption.series[0].data = data.repairTrend.values
    
    occupancyOption.series[0].data = [
      { value: data.occupancy.occupied, name: '已入住', itemStyle: { color: '#8b7ec8' } },
      { value: data.occupancy.vacant, name: '空置', itemStyle: { color: '#c6ccff' } },
      { value: data.occupancy.maintenance, name: '维修中', itemStyle: { color: '#dde0ea' } }
    ]
    
    monthlyStatsOption.xAxis.data = data.monthlyStats.months
    monthlyStatsOption.series[0].data = data.monthlyStats.repairCounts
    monthlyStatsOption.series[1].data = data.monthlyStats.noticeCounts
    monthlyStatsOption.series[2].data = data.monthlyStats.newStudentCounts
    
  } catch (error) {
    console.error('加载仪表盘数据失败:', error)
  }
}

onMounted(() => {
  loadDashboardData()
})
</script>

<style scoped>
.dashboard-bg {
  background: linear-gradient(135deg, 
    #f3f4d6 0%,
    #ebecde 20%,
    #dde0ea 40%,
    #cfd4f7 60%,
    #c6ccff 80%,
    #dde0ea 100%
  );
  background-size: 400% 400%;
  animation: gradientShift 20s ease infinite;
  position: relative;
}

@keyframes gradientShift {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

.bg-gradient-to-br {
  animation: fadeIn 0.5s ease-out;
}

.bg-white\/80 {
  backdrop-filter: blur(10px);
}
</style>