<template>
  <n-layout has-sider class="layout-container">
    <n-layout-sider
      bordered
      show-trigger
      collapse-mode="width"
      :collapsed-width="64"
      :width="240"
      :native-scrollbar="false"
    >
      <div class="logo">
        <h2>不期而宿</h2>
      </div>
      
      <n-menu
        v-model:value="activeKey"
        :collapsed-width="64"
        :collapsed-icon-size="22"
        :options="menuOptions"
        @update:value="handleMenuSelect"
      />
    </n-layout-sider>
    
    <n-layout>
      <n-layout-header bordered class="layout-header">
        <n-text strong>管理员端</n-text>
        
        <n-dropdown :options="userOptions" @select="handleUserAction">
          <n-button text>
            <n-space align="center">
              <n-avatar round :size="32">
                {{ userStore.userInfo.realName?.charAt(0) }}
              </n-avatar>
              <n-text>{{ userStore.userInfo.realName }}</n-text>
            </n-space>
          </n-button>
        </n-dropdown>
      </n-layout-header>
      
      <n-layout-content class="layout-content">
        <router-view />
      </n-layout-content>
    </n-layout>
  </n-layout>
</template>

<script setup>
import { ref, h, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useMessage, NIcon } from 'naive-ui'
import { 
  SpeedometerOutline, 
  PeopleOutline, 
  HomeOutline,
  LogOutOutline
} from '@vicons/ionicons5'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const route = useRoute()
const message = useMessage()
const userStore = useUserStore()

const activeKey = ref('dashboard')

// 所有菜单选项
const allMenuOptions = [
  {
    label: '仪表盘',
    key: 'dashboard',
    icon: renderIcon(SpeedometerOutline),
    roles: ['ADMIN']
  },
  {
    label: '学生管理',
    key: 'student',
    icon: renderIcon(PeopleOutline),
    roles: ['ADMIN']
  },
  {
    label: '宿舍管理',
    key: 'dormitory',
    icon: renderIcon(HomeOutline),
    roles: ['ADMIN']
  },
  {
    label: '分配管理',
    key: 'assignment',
    icon: renderIcon(HomeOutline),
    roles: ['ADMIN']
  }
]

// 根据用户角色过滤菜单选项
const menuOptions = computed(() => {
  const userRole = userStore.userInfo?.role
  return allMenuOptions.filter(menu => menu.roles.includes(userRole))
})

// 用户下拉菜单选项
const userOptions = [
  {
    label: '退出登录',
    key: 'logout',
    icon: renderIcon(LogOutOutline)
  }
]

function renderIcon(icon) {
  return () => h(NIcon, null, { default: () => h(icon) })
}

const handleMenuSelect = (key) => {
  router.push(`/admin/${key}`)
}

const handleUserAction = async (key) => {
  if (key === 'logout') {
    await userStore.logout()
    message.success('退出成功')
    router.push('/login')
  }
}

activeKey.value = route.path.split('/')[2] || 'dashboard'
</script>

<style scoped>
.layout-container {
  height: 100vh;
  background: #f3f7ff;
  position: relative;
}

.logo {
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-bottom: 1px solid rgba(198, 204, 255, 0.3);
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  box-shadow: 0 4px 6px rgba(139, 126, 200, 0.2);
}

.logo h2 {
  font-size: 20px;
  font-weight: 700;
  color: #ffffff;
  margin: 0;
  letter-spacing: 2px;
}

.layout-header {
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
}

.layout-content {
  padding: 0;
  overflow-y: auto;
  background: transparent;
  overflow-x: hidden;
}

:deep(.n-layout-sider) {
  background: rgba(255, 255, 255, 0.95) !important;
  backdrop-filter: blur(10px);
}
</style>