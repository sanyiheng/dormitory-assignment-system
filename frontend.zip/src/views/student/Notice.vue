<template>
  <div class="modern-page">
    <!-- 动态背景装饰 -->
    <div class="background-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 页面标题 -->
    <div class="page-header">
      <h1 class="page-title">📢 公告通知</h1>
      <p class="page-subtitle">及时了解宿舍管理的最新动态</p>
    </div>

    <!-- 公告列表 -->
    <div class="notice-list">
      <div v-if="loading" class="loading-state">
        <div class="loading-spinner"></div>
        <p>加载中...</p>
      </div>
      
      <div v-else-if="notices.length === 0" class="empty-state">
        <div class="empty-icon">📭</div>
        <p class="empty-text">暂无公告通知</p>
        <p class="empty-hint">有新通知时会在这里显示</p>
      </div>

      <div v-else class="notice-cards">
        <div 
          v-for="item in notices" 
          :key="item.id" 
          class="notice-card"
          :class="{ 'is-top': item.isTop }"
          @click="handleNoticeClick(item)"
        >
          <div class="card-header">
            <div class="notice-icon" :class="getIconClass(item.isTop)">
              {{ item.isTop ? '📌' : '📄' }}
            </div>
            <div class="card-main">
              <div class="notice-title-row">
                <h3 class="notice-title">{{ item.title }}</h3>
                <span v-if="item.isTop" class="top-badge">置顶</span>
              </div>
              <p v-if="item.content" class="notice-preview">{{ item.content }}</p>
              <div class="notice-meta">
                <span class="meta-item">
                  <span class="meta-icon">🕒</span>
                  <span class="meta-text">{{ item.publishTime }}</span>
                </span>
                <span v-if="item.publisher" class="meta-item">
                  <span class="meta-icon">👤</span>
                  <span class="meta-text">{{ item.publisher }}</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 公告详情弹窗 -->
    <n-modal 
      v-model:show="showDetail" 
      preset="card"
      :title="currentNotice?.title"
      class="notice-modal"
      style="max-width: 600px;"
    >
      <template #header-extra>
        <span v-if="currentNotice?.isTop" class="modal-top-badge">📌 置顶</span>
      </template>
      <div class="notice-detail">
        <div class="detail-meta">
          <span class="detail-meta-item">
            <strong>发布时间：</strong>{{ currentNotice?.publishTime }}
          </span>
          <span v-if="currentNotice?.publisher" class="detail-meta-item">
            <strong>发布人：</strong>{{ currentNotice?.publisher }}
          </span>
        </div>
        <div class="detail-content">
          {{ currentNotice?.content || '暂无详细内容' }}
        </div>
      </div>
    </n-modal>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { getNoticePage } from '@/api/notice'

const message = useMessage()

const loading = ref(false)
const showDetail = ref(false)
const currentNotice = ref(null)
const notices = ref([])

// 获取公告列表（学生只看已发布且目标角色为ALL或STUDENT的）
const fetchNotices = async () => {
  loading.value = true
  try {
    const res = await getNoticePage({
      page: 1,
      pageSize: 100, // 学生端显示所有公告
      status: 1 // 只查询已发布的
    })
    // 过滤出目标角色为ALL或STUDENT的公告
    notices.value = res.data.records.filter(notice => 
      notice.targetRole === 'ALL' || notice.targetRole === 'STUDENT'
    ).map(notice => ({
      id: notice.id,
      title: notice.title,
      content: notice.content,
      publishTime: notice.publishTime,
      publisher: notice.publisherName,
      isTop: notice.isTop === 1
    }))
  } catch (error) {
    if (!error.showMessage) {
      message.error('获取公告列表失败')
    }
  } finally {
    loading.value = false
  }
}

const getIconClass = (isTop) => {
  return isTop ? 'icon-top' : 'icon-normal'
}

const handleNoticeClick = (notice) => {
  currentNotice.value = notice
  showDetail.value = true
}

onMounted(() => {
  fetchNotices()
})
</script>

<style scoped>
.modern-page {
  position: relative;
  min-height: 100vh;
  padding: 2rem;
  overflow: hidden;
}

/* 动态背景装饰 */
.background-decoration {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.3;
  animation: float 20s infinite ease-in-out;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
  top: -10%;
  left: -5%;
  animation-delay: 0s;
}

.orb-2 {
  width: 350px;
  height: 350px;
  background: linear-gradient(135deg, #5ba3f5 0%, #4a90e2 100%);
  top: 50%;
  right: -5%;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #6bb6ff 0%, #4a90e2 100%);
  bottom: -5%;
  left: 30%;
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  25% { transform: translate(30px, -30px) scale(1.05); }
  50% { transform: translate(-20px, 20px) scale(0.95); }
  75% { transform: translate(20px, 10px) scale(1.02); }
}

/* 页面标题 */
.page-header {
  position: relative;
  z-index: 1;
  margin-bottom: 2rem;
  animation: slideDown 0.6s ease-out;
}

.page-title {
  font-size: 2.5rem;
  font-weight: 800;
  background: linear-gradient(135deg, #4a90e2 0%, #357abd 50%, #5ba3f5 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 0.5rem;
}

.page-subtitle {
  font-size: 1rem;
  color: #666;
  margin: 0;
}

/* 公告列表 */
.notice-list {
  position: relative;
  z-index: 1;
  animation: slideUp 0.6s ease-out 0.2s both;
}

.loading-state {
  text-align: center;
  padding: 4rem 2rem;
  color: #666;
}

.loading-spinner {
  width: 50px;
  height: 50px;
  margin: 0 auto 1rem;
  border: 4px solid rgba(74, 144, 226, 0.2);
  border-top-color: #4a90e2;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.empty-state {
  text-align: center;
  padding: 4rem 2rem;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  border: 1px solid rgba(255, 255, 255, 0.6);
}

.empty-icon {
  font-size: 4rem;
  margin-bottom: 1rem;
  opacity: 0.5;
}

.empty-text {
  font-size: 1.2rem;
  color: #666;
  margin-bottom: 0.5rem;
}

.empty-hint {
  font-size: 0.9rem;
  color: #999;
}

/* 公告卡片 */
.notice-cards {
  display: grid;
  gap: 1.5rem;
}

.notice-card {
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  padding: 1.5rem;
  border: 1px solid rgba(255, 255, 255, 0.6);
  transition: all 0.3s ease;
  cursor: pointer;
  animation: slideUp 0.6s ease-out both;
}

.notice-card:nth-child(1) { animation-delay: 0.2s; }
.notice-card:nth-child(2) { animation-delay: 0.3s; }
.notice-card:nth-child(3) { animation-delay: 0.4s; }
.notice-card:nth-child(4) { animation-delay: 0.5s; }

.notice-card.is-top {
  border: 2px solid rgba(74, 144, 226, 0.4);
  background: rgba(74, 144, 226, 0.05);
}

.notice-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(74, 144, 226, 0.2);
  border-color: rgba(74, 144, 226, 0.4);
}

.card-header {
  display: flex;
  gap: 1rem;
}

.notice-icon {
  flex-shrink: 0;
  width: 50px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.8rem;
  border-radius: 16px;
  transition: all 0.3s ease;
}

.icon-top {
  background: linear-gradient(135deg, #4a90e2 0%, #5ba3f5 100%);
  box-shadow: 0 4px 15px rgba(74, 144, 226, 0.3);
}

.icon-normal {
  background: linear-gradient(135deg, #f0f0f0 0%, #e0e0e0 100%);
}

.card-main {
  flex: 1;
  min-width: 0;
}

.notice-title-row {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.5rem;
}

.notice-title {
  font-size: 1.2rem;
  font-weight: 600;
  color: #333;
  margin: 0;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.top-badge {
  flex-shrink: 0;
  padding: 0.2rem 0.8rem;
  background: linear-gradient(135deg, #4a90e2 0%, #5ba3f5 100%);
  color: white;
  font-size: 0.75rem;
  font-weight: 600;
  border-radius: 12px;
}

.notice-preview {
  font-size: 0.9rem;
  color: #666;
  margin: 0.5rem 0;
  line-height: 1.6;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.notice-meta {
  display: flex;
  gap: 1.5rem;
  margin-top: 0.8rem;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 0.3rem;
  font-size: 0.85rem;
  color: #999;
}

.meta-icon {
  font-size: 1rem;
}

/* 公告详情弹窗 */
:deep(.notice-modal .n-card) {
  border-radius: 24px;
}

:deep(.notice-modal .n-card-header) {
  font-size: 1.5rem;
  font-weight: 700;
  background: linear-gradient(135deg, #4a90e2 0%, #5ba3f5 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.modal-top-badge {
  padding: 0.3rem 1rem;
  background: linear-gradient(135deg, #4a90e2 0%, #5ba3f5 100%);
  color: white;
  font-size: 0.85rem;
  font-weight: 600;
  border-radius: 16px;
}

.notice-detail {
  padding: 1rem 0;
}

.detail-meta {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
  padding-bottom: 1.5rem;
  border-bottom: 2px solid rgba(74, 144, 226, 0.1);
}

.detail-meta-item {
  font-size: 0.9rem;
  color: #666;
}

.detail-meta-item strong {
  color: #333;
  margin-right: 0.5rem;
}

.detail-content {
  font-size: 1rem;
  color: #333;
  line-height: 1.8;
  white-space: pre-wrap;
}

/* 动画 */
@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 响应式设计 */
@media (max-width: 768px) {
  .modern-page {
    padding: 1rem;
  }

  .page-title {
    font-size: 2rem;
  }

  .card-header {
    flex-direction: row;
  }

  .notice-icon {
    width: 45px;
    height: 45px;
    font-size: 1.5rem;
  }

  .notice-title {
    font-size: 1.1rem;
  }

  .notice-meta {
    flex-direction: column;
    gap: 0.5rem;
  }
}
</style>
