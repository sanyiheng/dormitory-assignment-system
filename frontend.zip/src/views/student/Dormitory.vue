<template>
  <div class="modern-page">
    <!-- 背景装饰 -->
    <div class="background-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 页面标题 -->
    <div class="page-header">
      <h2 class="page-title">
        <span class="title-icon">🏠</span>
        我的宿舍
      </h2>
      <p class="page-subtitle">查看宿舍详细信息和室友情况</p>
    </div>

    <!-- 加载状态 -->
    <div v-if="loading" class="loading-container">
      <div class="loading-spinner"></div>
      <p>加载中...</p>
    </div>

    <!-- 未分配宿舍提示 -->
    <div v-else-if="!dormInfo" class="empty-container">
      <div class="empty-icon">🏠</div>
      <p class="empty-text">您还未分配宿舍</p>
      <p class="empty-hint">请联系管理员为您分配宿舍</p>
    </div>

    <!-- 宿舍信息 -->
    <template v-else>
      <!-- 宿舍信息卡片 -->
      <div class="dorm-info-card">
        <div class="dorm-header">
          <div class="building-badge">{{ dormInfo.buildingName }}</div>
          <div class="room-number">{{ dormInfo.roomNo }}</div>
        </div>
        
        <div class="info-grid">
          <div class="info-item">
            <div class="info-icon">🏢</div>
            <div class="info-content">
              <div class="info-label">楼栋</div>
              <div class="info-value">{{ dormInfo.buildingName }}</div>
            </div>
          </div>
          
          <div class="info-item">
            <div class="info-icon">🚪</div>
            <div class="info-content">
              <div class="info-label">房间号</div>
              <div class="info-value">{{ dormInfo.roomNo }}</div>
            </div>
          </div>
          
          <div class="info-item">
            <div class="info-icon">🛏️</div>
            <div class="info-content">
              <div class="info-label">床位号</div>
              <div class="info-value">{{ dormInfo.bedNo || '未指定' }}</div>
            </div>
          </div>
          
          <div class="info-item">
            <div class="info-icon">📅</div>
            <div class="info-content">
              <div class="info-label">入住日期</div>
              <div class="info-value">{{ dormInfo.checkInDate }}</div>
            </div>
          </div>

          <div class="info-item">
            <div class="info-icon">👥</div>
            <div class="info-content">
              <div class="info-label">可住人数</div>
              <div class="info-value">{{ dormInfo.capacity }}人</div>
            </div>
          </div>

          <div class="info-item">
            <div class="info-icon">🏠</div>
            <div class="info-content">
              <div class="info-label">已住人数</div>
              <div class="info-value">{{ dormInfo.occupied }}人</div>
            </div>
          </div>

          <div v-if="dormInfo.facilities" class="info-item full-width">
            <div class="info-icon">🛋️</div>
            <div class="info-content">
              <div class="info-label">设施说明</div>
              <div class="info-value">{{ dormInfo.facilities }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 室友信息 -->
      <div class="roommates-section">
        <h3 class="section-title">👥 室友信息 ({{ dormInfo.roommates?.length || 0 }}/{{ dormInfo.capacity }})</h3>
        <div class="roommates-grid">
          <div 
            v-for="roommate in dormInfo.roommates" 
            :key="roommate.id" 
            class="roommate-card"
          >
            <div class="roommate-avatar">{{ roommate.name.charAt(0) }}</div>
            <div class="roommate-name">{{ roommate.name }}</div>
            <div class="roommate-info">{{ roommate.className }}</div>
            <div class="roommate-bed">{{ roommate.bedNo || '未指定床位' }}</div>
          </div>
          
          <!-- 空床位显示 -->
          <div 
            v-for="i in (dormInfo.capacity - (dormInfo.roommates?.length || 0))" 
            :key="'empty-' + i" 
            class="roommate-card empty"
          >
            <div class="roommate-avatar">空</div>
            <div class="roommate-name">空床位</div>
            <div class="roommate-info">待入住</div>
            <div class="roommate-bed">-</div>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getStudentDormInfo } from '@/api/student'
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()

const loading = ref(true)
const dormInfo = ref(null)

// 获取宿舍信息
const fetchDormInfo = async () => {
  loading.value = true
  try {
    // 从用户信息中获取学生ID
    const userId = userStore.userInfo?.id || 1 // 临时使用ID=1，实际应从登录信息获取
    const res = await getStudentDormInfo(userId)
    dormInfo.value = res.data
  } catch (error) {
    console.error('获取宿舍信息失败：', error)
    dormInfo.value = null
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  fetchDormInfo()
})
</script>

<style scoped>
.modern-page {
  position: relative;
  min-height: 100vh;
  padding: 24px;
}

.background-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.6;
  animation: float 20s ease-in-out infinite;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  top: -200px;
  left: -200px;
}

.orb-2 {
  width: 350px;
  height: 350px;
  background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%);
  top: 40%;
  right: -180px;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
  bottom: -150px;
  left: 30%;
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(50px, -50px) scale(1.1); }
  66% { transform: translate(-50px, 50px) scale(0.9); }
}

.page-header {
  position: relative;
  z-index: 1;
  margin-bottom: 24px;
  animation: slideDown 0.6s ease-out;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.page-title {
  font-size: 32px;
  font-weight: 700;
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 36px;
  filter: drop-shadow(0 4px 8px rgba(0,0,0,0.1));
}

.page-subtitle {
  font-size: 14px;
  color: #64748b;
  margin: 8px 0 0 48px;
}

/* 加载状态 */
.loading-container {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 20px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.loading-spinner {
  width: 48px;
  height: 48px;
  border: 4px solid rgba(16, 185, 129, 0.2);
  border-top-color: #10b981;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-bottom: 16px;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.loading-container p {
  color: rgba(0, 0, 0, 0.6);
  font-size: 14px;
}

/* 空状态 */
.empty-container {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 20px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.empty-icon {
  font-size: 64px;
  margin-bottom: 16px;
  opacity: 0.5;
}

.empty-text {
  font-size: 18px;
  font-weight: 600;
  color: rgba(0, 0, 0, 0.8);
  margin-bottom: 8px;
}

.empty-hint {
  font-size: 14px;
  color: rgba(0, 0, 0, 0.5);
}

.dorm-info-card {
  position: relative;
  z-index: 1;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 32px;
  margin-bottom: 24px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.6);
  animation: slideUp 0.6s ease-out 0.1s both;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dorm-header {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 32px;
}

.building-badge {
  padding: 8px 16px;
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  color: white;
  border-radius: 12px;
  font-weight: 600;
  font-size: 14px;
}

.room-number {
  font-size: 48px;
  font-weight: 700;
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  background: rgba(16, 185, 129, 0.05);
  border-radius: 12px;
  transition: all 0.3s ease;
}

.info-item:hover {
  background: rgba(16, 185, 129, 0.1);
  transform: translateY(-2px);
}

.info-item.full-width {
  grid-column: 1 / -1;
}

.info-icon {
  font-size: 32px;
  filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
}

.info-content {
  flex: 1;
}

.info-label {
  font-size: 12px;
  color: #64748b;
  margin-bottom: 4px;
}

.info-value {
  font-size: 18px;
  font-weight: 600;
  color: #1f2937;
}

.roommates-section {
  position: relative;
  z-index: 1;
  animation: slideUp 0.6s ease-out 0.2s both;
}

.section-title {
  font-size: 24px;
  font-weight: 700;
  color: #1f2937;
  margin: 0 0 20px 0;
}

.roommates-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 20px;
}

.roommate-card {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 24px;
  text-align: center;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.6);
}

.roommate-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
}

.roommate-card.empty {
  opacity: 0.5;
}

.roommate-avatar {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  font-weight: 700;
  margin: 0 auto 12px;
}

.roommate-card.empty .roommate-avatar {
  background: linear-gradient(135deg, #cbd5e1 0%, #94a3b8 100%);
}

.roommate-name {
  font-size: 16px;
  font-weight: 600;
  color: #1f2937;
  margin-bottom: 4px;
}

.roommate-info {
  font-size: 13px;
  color: #64748b;
  margin-bottom: 4px;
}

.roommate-bed {
  font-size: 12px;
  color: #64748b;
}

@media (max-width: 768px) {
  .info-grid {
    grid-template-columns: 1fr;
  }
  
  .roommates-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>


