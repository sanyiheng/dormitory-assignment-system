<template>
  <div class="modern-page">
    <!-- 动态背景装饰 -->
    <div class="background-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 页面标题 -->
    <div class="page-header">
      <h1 class="page-title">👤 个人信息</h1>
      <p class="page-subtitle">管理您的个人资料</p>
    </div>

    <!-- 个人信息卡片 -->
    <div class="profile-container">
      <!-- 头像卡片 -->
      <div class="avatar-card">
        <div class="avatar-wrapper">
          <div class="avatar">
            <span class="avatar-text">{{ getAvatarText(userInfo.name) }}</span>
          </div>
          <button class="edit-avatar-btn">
            <span>📷</span>
          </button>
        </div>
        <h2 class="user-name">{{ userInfo.name }}</h2>
        <p class="user-id">学号：{{ userInfo.studentId }}</p>
      </div>

      <!-- 信息卡片 -->
      <div class="info-card">
        <div class="info-header">
          <h3 class="info-title">📋 基本信息</h3>
          <button class="edit-btn" @click="showEditModal = true">
            <span class="edit-icon">✏️</span>
            <span>编辑</span>
          </button>
        </div>
        
        <div class="info-grid">
          <div class="info-item">
            <div class="info-label">
              <span class="label-icon">🎓</span>
              <span>学号</span>
            </div>
            <div class="info-value">{{ userInfo.studentId }}</div>
          </div>

          <div class="info-item">
            <div class="info-label">
              <span class="label-icon">👨</span>
              <span>姓名</span>
            </div>
            <div class="info-value">{{ userInfo.name }}</div>
          </div>

          <div class="info-item">
            <div class="info-label">
              <span class="label-icon">⚧️</span>
              <span>性别</span>
            </div>
            <div class="info-value">{{ userInfo.gender }}</div>
          </div>

          <div class="info-item">
            <div class="info-label">
              <span class="label-icon">👥</span>
              <span>班级</span>
            </div>
            <div class="info-value">{{ userInfo.className }}</div>
          </div>

          <div class="info-item">
            <div class="info-label">
              <span class="label-icon">📚</span>
              <span>专业</span>
            </div>
            <div class="info-value">{{ userInfo.major }}</div>
          </div>

          <div class="info-item">
            <div class="info-label">
              <span class="label-icon">📱</span>
              <span>手机号</span>
            </div>
            <div class="info-value">{{ userInfo.phone }}</div>
          </div>

          <div class="info-item">
            <div class="info-label">
              <span class="label-icon">📧</span>
              <span>邮箱</span>
            </div>
            <div class="info-value">{{ userInfo.email || '未设置' }}</div>
          </div>

          <div class="info-item">
            <div class="info-label">
              <span class="label-icon">📅</span>
              <span>入学时间</span>
            </div>
            <div class="info-value">{{ userInfo.enrollmentDate || '未设置' }}</div>
          </div>
        </div>
      </div>

      <!-- 账号安全卡片 -->
      <div class="security-card">
        <div class="info-header">
          <h3 class="info-title">🔐 账号安全</h3>
        </div>
        
        <div class="security-items">
          <div class="security-item">
            <div class="security-left">
              <div class="security-icon">🔑</div>
              <div class="security-info">
                <h4 class="security-name">登录密码</h4>
                <p class="security-desc">定期更换密码可保护账号安全</p>
              </div>
            </div>
            <button class="action-btn" @click="showPasswordModal = true">
              修改
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 编辑信息弹窗 -->
    <n-modal 
      v-model:show="showEditModal" 
      preset="dialog"
      title="✏️ 编辑个人信息"
      :show-icon="false"
      class="edit-modal"
    >
      <n-form :model="editForm" ref="editFormRef">
        <n-form-item label="📱 手机号" path="phone">
          <n-input v-model:value="editForm.phone" placeholder="请输入手机号" />
        </n-form-item>
        <n-form-item label="📧 邮箱" path="email">
          <n-input v-model:value="editForm.email" placeholder="请输入邮箱" />
        </n-form-item>
      </n-form>
      <template #action>
        <div class="modal-actions">
          <button class="modal-btn cancel-btn" @click="showEditModal = false">
            取消
          </button>
          <button class="modal-btn submit-btn" @click="handleSaveEdit">
            <span class="btn-icon">💾</span>
            <span>保存</span>
          </button>
        </div>
      </template>
    </n-modal>

    <!-- 修改密码弹窗 -->
    <n-modal 
      v-model:show="showPasswordModal" 
      preset="dialog"
      title="🔑 修改密码"
      :show-icon="false"
      class="password-modal"
    >
      <n-form :model="passwordForm" ref="passwordFormRef">
        <n-form-item label="原密码" path="oldPassword">
          <n-input 
            v-model:value="passwordForm.oldPassword" 
            type="password" 
            placeholder="请输入原密码"
            show-password-on="click"
          />
        </n-form-item>
        <n-form-item label="新密码" path="newPassword">
          <n-input 
            v-model:value="passwordForm.newPassword" 
            type="password" 
            placeholder="请输入新密码（至少6位）"
            show-password-on="click"
          />
        </n-form-item>
        <n-form-item label="确认密码" path="confirmPassword">
          <n-input 
            v-model:value="passwordForm.confirmPassword" 
            type="password" 
            placeholder="请再次输入新密码"
            show-password-on="click"
          />
        </n-form-item>
      </n-form>
      <template #action>
        <div class="modal-actions">
          <button class="modal-btn cancel-btn" @click="showPasswordModal = false">
            取消
          </button>
          <button class="modal-btn submit-btn" @click="handleChangePassword">
            <span class="btn-icon">🔐</span>
            <span>确认修改</span>
          </button>
        </div>
      </template>
    </n-modal>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useMessage } from 'naive-ui'
import { changePassword } from '@/api/auth'

const message = useMessage()
const showEditModal = ref(false)
const showPasswordModal = ref(false)
const editFormRef = ref(null)
const passwordFormRef = ref(null)

const userInfo = ref({
  studentId: '2024001',
  name: '张三',
  gender: '男',
  className: '软件1班',
  major: '软件工程',
  phone: '13900139001',
  email: 'zhangsan@example.com',
  enrollmentDate: '2024-09-01'
})

const editForm = ref({
  phone: userInfo.value.phone,
  email: userInfo.value.email
})

const passwordForm = ref({
  oldPassword: '',
  newPassword: '',
  confirmPassword: ''
})

const getAvatarText = (name) => {
  return name ? name.charAt(0).toUpperCase() : 'U'
}

const handleSaveEdit = async () => {
  try {
    await editFormRef.value?.validate()
    // TODO: 实际保存逻辑
    console.log('保存信息:', editForm.value)
    userInfo.value.phone = editForm.value.phone
    userInfo.value.email = editForm.value.email
    showEditModal.value = false
  } catch (error) {
    console.log('验证失败:', error)
  }
}

const handleChangePassword = async () => {
  try {
    await passwordFormRef.value?.validate()
    
    // 校验两次密码是否一致
    if (passwordForm.value.newPassword !== passwordForm.value.confirmPassword) {
      message.error('两次输入的密码不一致')
      return
    }
    
    // 校验新密码长度
    if (passwordForm.value.newPassword.length < 6) {
      message.error('新密码至少需要6位')
      return
    }
    
    // 调用API修改密码
    await changePassword({
      oldPassword: passwordForm.value.oldPassword,
      newPassword: passwordForm.value.newPassword
    })
    
    message.success('密码修改成功，请重新登录')
    showPasswordModal.value = false
    passwordForm.value = { oldPassword: '', newPassword: '', confirmPassword: '' }
    
    // 3秒后跳转到登录页
    setTimeout(() => {
      window.location.href = '/login'
    }, 3000)
  } catch (error) {
    // 如果 request.js 已经显示了错误消息（error.showMessage = true），就不重复显示
    // 否则显示一个通用错误消息
    if (!error.showMessage) {
      message.error(error.message || '修改密码失败')
    }
    console.error('修改密码失败:', error)
  }
}
</script>

<style scoped>
.modern-page {
  position: relative;
  min-height: 100vh;
  padding: 2rem;
  overflow: hidden;
}

/* 动态背景装饰 */
.background-decoration {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.3;
  animation: float 20s infinite ease-in-out;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #a855f7 0%, #9333ea 100%);
  top: -10%;
  left: -5%;
  animation-delay: 0s;
}

.orb-2 {
  width: 350px;
  height: 350px;
  background: linear-gradient(135deg, #ec4899 0%, #d946ef 100%);
  top: 50%;
  right: -5%;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
  bottom: -5%;
  left: 30%;
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  25% { transform: translate(30px, -30px) scale(1.05); }
  50% { transform: translate(-20px, 20px) scale(0.95); }
  75% { transform: translate(20px, 10px) scale(1.02); }
}

/* 页面标题 */
.page-header {
  position: relative;
  z-index: 1;
  margin-bottom: 2rem;
  animation: slideDown 0.6s ease-out;
}

.page-title {
  font-size: 2.5rem;
  font-weight: 800;
  background: linear-gradient(135deg, #a855f7 0%, #ec4899 50%, #8b5cf6 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 0.5rem;
}

.page-subtitle {
  font-size: 1rem;
  color: #666;
  margin: 0;
}

/* 个人信息容器 */
.profile-container {
  position: relative;
  z-index: 1;
  display: grid;
  gap: 1.5rem;
  max-width: 1200px;
  animation: slideUp 0.6s ease-out 0.2s both;
}

/* 头像卡片 */
.avatar-card {
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  padding: 2rem;
  border: 1px solid rgba(255, 255, 255, 0.6);
  text-align: center;
  transition: all 0.3s ease;
}

.avatar-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(168, 85, 247, 0.2);
}

.avatar-wrapper {
  position: relative;
  display: inline-block;
  margin-bottom: 1rem;
}

.avatar {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8px 30px rgba(168, 85, 247, 0.3);
  transition: all 0.3s ease;
}

.avatar:hover {
  transform: scale(1.05);
}

.avatar-text {
  font-size: 3rem;
  font-weight: 700;
  color: white;
}

.edit-avatar-btn {
  position: absolute;
  bottom: 5px;
  right: 5px;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: white;
  border: 2px solid #a855f7;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 1.2rem;
}

.edit-avatar-btn:hover {
  transform: scale(1.1);
  background: #a855f7;
}

.user-name {
  font-size: 1.8rem;
  font-weight: 700;
  color: #333;
  margin: 0 0 0.5rem 0;
}

.user-id {
  font-size: 1rem;
  color: #999;
  margin: 0;
}

/* 信息卡片 */
.info-card {
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  padding: 2rem;
  border: 1px solid rgba(255, 255, 255, 0.6);
  transition: all 0.3s ease;
  animation-delay: 0.3s;
}

.info-card:hover {
  box-shadow: 0 10px 30px rgba(168, 85, 247, 0.15);
}

.info-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  padding-bottom: 1rem;
  border-bottom: 2px solid rgba(168, 85, 247, 0.1);
}

.info-title {
  font-size: 1.3rem;
  font-weight: 700;
  color: #333;
  margin: 0;
}

.edit-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.3rem;
  padding: 0.5rem 1rem;
  background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%);
  color: white;
  border: none;
  border-radius: 12px;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.edit-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 15px rgba(168, 85, 247, 0.3);
}

.edit-icon {
  font-size: 1rem;
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.info-label {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.85rem;
  color: #999;
  font-weight: 500;
}

.label-icon {
  font-size: 1.1rem;
}

.info-value {
  font-size: 1rem;
  color: #333;
  font-weight: 600;
  padding-left: 1.6rem;
}

/* 安全卡片 */
.security-card {
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  padding: 2rem;
  border: 1px solid rgba(255, 255, 255, 0.6);
  transition: all 0.3s ease;
  animation-delay: 0.4s;
}

.security-card:hover {
  box-shadow: 0 10px 30px rgba(168, 85, 247, 0.15);
}

.security-items {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.security-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  background: rgba(168, 85, 247, 0.03);
  border-radius: 16px;
  transition: all 0.3s ease;
}

.security-item:hover {
  background: rgba(168, 85, 247, 0.08);
}

.security-left {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.security-icon {
  width: 50px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
  background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%);
  border-radius: 14px;
  box-shadow: 0 4px 15px rgba(168, 85, 247, 0.2);
}

.security-info {
  flex: 1;
}

.security-name {
  font-size: 1.1rem;
  font-weight: 600;
  color: #333;
  margin: 0 0 0.3rem 0;
}

.security-desc {
  font-size: 0.85rem;
  color: #999;
  margin: 0;
}

.action-btn {
  padding: 0.6rem 1.5rem;
  background: white;
  color: #a855f7;
  border: 2px solid #a855f7;
  border-radius: 12px;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.action-btn:hover {
  background: #a855f7;
  color: white;
  transform: translateY(-2px);
  box-shadow: 0 4px 15px rgba(168, 85, 247, 0.3);
}

/* 弹窗样式 */
:deep(.edit-modal .n-dialog),
:deep(.password-modal .n-dialog) {
  border-radius: 24px;
}

:deep(.edit-modal .n-dialog__title),
:deep(.password-modal .n-dialog__title) {
  font-size: 1.5rem;
  font-weight: 700;
  background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.modal-actions {
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 1rem;
}

.modal-btn {
  padding: 0.75rem 1.5rem;
  border-radius: 12px;
  font-size: 1rem;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: all 0.3s ease;
  display: inline-flex;
  align-items: center;
  gap: 0.3rem;
}

.cancel-btn {
  background: #f5f5f5;
  color: #666;
}

.cancel-btn:hover {
  background: #e8e8e8;
}

.submit-btn {
  background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%);
  color: white;
  box-shadow: 0 4px 15px rgba(168, 85, 247, 0.3);
}

.submit-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(168, 85, 247, 0.4);
}

.btn-icon {
  font-size: 1.1rem;
}

/* 动画 */
@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 响应式设计 */
@media (max-width: 768px) {
  .modern-page {
    padding: 1rem;
  }

  .page-title {
    font-size: 2rem;
  }

  .avatar {
    width: 100px;
    height: 100px;
  }

  .avatar-text {
    font-size: 2.5rem;
  }

  .info-grid {
    grid-template-columns: 1fr;
    gap: 1rem;
  }

  .security-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 1rem;
  }

  .action-btn {
    width: 100%;
  }

  .modal-actions {
    flex-direction: column;
  }

  .modal-btn {
    width: 100%;
    justify-content: center;
  }
}
</style>
