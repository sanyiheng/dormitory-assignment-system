<template>
  <n-layout has-sider class="layout-container">
    <n-layout-sider
      bordered
      show-trigger
      collapse-mode="width"
      :collapsed-width="64"
      :width="240"
    >
      <div class="logo">
        <h2>学生端</h2>
      </div>
      
      <n-menu
        v-model:value="activeKey"
        :options="menuOptions"
        @update:value="handleMenuSelect"
      />
    </n-layout-sider>
    
    <n-layout>
      <n-layout-header bordered class="layout-header">
        <n-text strong>学生宿舍分配系统</n-text>
        
        <n-dropdown :options="userOptions" @select="handleUserAction">
          <n-button text>
            <n-space align="center">
              <n-avatar round :size="32">
                {{ userStore.userInfo.realName?.charAt(0) }}
              </n-avatar>
              <n-text>{{ userStore.userInfo.realName }}</n-text>
            </n-space>
          </n-button>
        </n-dropdown>
      </n-layout-header>
      
      <n-layout-content class="layout-content">
        <router-view />
      </n-layout-content>
    </n-layout>
  </n-layout>
</template>

<script setup>
import { ref, h } from 'vue'
import { useRouter } from 'vue-router'
import { useMessage, NIcon } from 'naive-ui'
import { HomeOutline, BedOutline, PersonOutline, LogOutOutline } from '@vicons/ionicons5'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const message = useMessage()
const userStore = useUserStore()

const activeKey = ref('home')

const menuOptions = [
  { label: '首页', key: 'home', icon: renderIcon(HomeOutline) },
  { label: '填写问卷', key: 'questionnaire', icon: renderIcon(BedOutline) },
  { label: '我的分配', key: 'assignment', icon: renderIcon(HomeOutline) },
  { label: '个人信息', key: 'profile', icon: renderIcon(PersonOutline) }
]

const userOptions = [
  { label: '退出登录', key: 'logout', icon: renderIcon(LogOutOutline) }
]

function renderIcon(icon) {
  return () => h(NIcon, null, { default: () => h(icon) })
}

const handleMenuSelect = (key) => {
  router.push(`/student/${key}`)
}

const handleUserAction = async (key) => {
  if (key === 'logout') {
    await userStore.logout()
    message.success('退出成功')
    router.push('/login')
  }
}
</script>

<style scoped>
.layout-container {
  height: 100vh;
}

.logo {
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-bottom: 1px solid #f0f0f0;
}

.logo h2 {
  font-size: 20px;
  font-weight: 600;
  margin: 0;
}

.layout-header {
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
}

.layout-content {
  padding: 24px;
  overflow-y: auto;
}
</style>




