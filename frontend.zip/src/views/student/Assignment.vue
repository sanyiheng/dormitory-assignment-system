<template>
  <div class="assignment-page">
    <div class="page-header">
      <h1 class="page-title">🏠 我的宿舍分配</h1>
      <p class="page-subtitle">你的宿舍分配结果和室友信息</p>
    </div>

    <!-- 未分配 -->
    <div v-if="!assignment" class="empty-card">
      <div class="empty-icon">⏳</div>
      <h2>暂未分配宿舍</h2>
      <p>请先填写问卷，等待管理员执行分配</p>
    </div>

    <!-- 已分配 -->
    <div v-else class="assignment-content">
      <!-- 宿舍信息卡片 -->
      <div class="dorm-card">
        <div class="dorm-icon">🏢</div>
        <div class="dorm-info">
          <h2 class="dorm-title">{{ assignment.buildingName }} - {{ assignment.roomNo }}</h2>
          <p class="dorm-bed">床位号：{{ assignment.bedNo }}</p>
        </div>
      </div>

      <!-- 室友列表 -->
      <div class="roommates-section">
        <h3 class="section-title">👥 你的室友</h3>
        <div class="roommate-list">
          <div v-for="(roommate, index) in assignment.roommates" :key="index" class="roommate-card">
            <div class="roommate-avatar">{{ roommate.name?.charAt(0) }}</div>
            <div class="roommate-info">
              <div class="roommate-name">{{ roommate.name }}</div>
              <div class="roommate-detail">
                {{ roommate.major }} · {{ roommate.className }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { getMyAssignment } from '@/api/assignment'

const message = useMessage()
const assignment = ref(null)

const fetchAssignment = async () => {
  try {
    const res = await getMyAssignment()
    assignment.value = res.data
  } catch (error) {
    console.error('获取分配结果失败：', error)
  }
}

onMounted(() => {
  fetchAssignment()
})
</script>

<style scoped>
.assignment-page {
  min-height: 100vh;
  padding: 24px;
  max-width: 800px;
  margin: 0 auto;
}

.page-header {
  margin-bottom: 32px;
  text-align: center;
}

.page-title {
  font-size: 28px;
  font-weight: 700;
  color: #8b7ec8;
  margin-bottom: 8px;
}

.page-subtitle {
  font-size: 14px;
  color: #64748b;
}

.empty-card {
  background: white;
  border-radius: 20px;
  padding: 60px 40px;
  text-align: center;
  box-shadow: 0 4px 20px rgba(139, 126, 200, 0.15);
}

.empty-icon {
  font-size: 60px;
  margin-bottom: 16px;
}

.assignment-content {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.dorm-card {
  background: white;
  border-radius: 20px;
  padding: 32px;
  display: flex;
  align-items: center;
  gap: 20px;
  box-shadow: 0 4px 20px rgba(139, 126, 200, 0.15);
}

.dorm-icon {
  font-size: 48px;
}

.dorm-title {
  font-size: 24px;
  font-weight: 700;
  color: #8b7ec8;
  margin-bottom: 8px;
}

.dorm-bed {
  font-size: 14px;
  color: #64748b;
}

.roommates-section {
  background: white;
  border-radius: 20px;
  padding: 24px;
  box-shadow: 0 4px 20px rgba(139, 126, 200, 0.15);
}

.section-title {
  font-size: 18px;
  font-weight: 700;
  color: #8b7ec8;
  margin-bottom: 16px;
}

.roommate-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 16px;
}

.roommate-card {
  display: flex;
  gap: 16px;
  padding: 16px;
  border-radius: 12px;
  background: #f3f7ff;
  border: 1px solid #e5e7eb;
}

.roommate-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  font-weight: 700;
  flex-shrink: 0;
}

.roommate-name {
  font-size: 16px;
  font-weight: 600;
  color: #1f2937;
  margin-bottom: 4px;
}

.roommate-detail {
  font-size: 13px;
  color: #64748b;
  margin-bottom: 4px;
}
</style>