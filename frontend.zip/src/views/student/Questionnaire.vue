<template>
  <div class="questionnaire-page">
    <div class="page-header">
      <h1 class="page-title">📝 宿舍分配问卷</h1>
      <p class="page-subtitle">请根据你的真实情况填写，系统将根据你的答案智能分配宿舍</p>
    </div>

    <!-- 已填写提示 -->
    <div v-if="submitted" class="submitted-card">
      <div class="submitted-icon">✅</div>
      <h2>你已完成问卷</h2>
      <p>等待管理员执行分配算法</p>
    </div>

    <!-- 问卷已截止提示 -->
    <div v-if="questionnaireClosed" class="submitted-card">
      <div class="submitted-icon">⏰</div>
      <h2>问卷填写已截止</h2>
      <p>如有疑问请联系管理员</p>
    </div>

    <!-- 问卷列表 -->
    <div v-else class="question-list">
      <div v-for="question in questions" :key="question.id" class="question-card">
        <div class="question-header">
          <span class="question-no">{{ question.questionNo }}</span>
          <span class="question-text">{{ question.questionText }}</span>
        </div>
        <div class="option-list">
          <div
            v-for="option in question.options"
            :key="option.id"
            class="option-item"
            :class="{ selected: selectedAnswers[question.id] === option.id }"
            @click="selectOption(question.id, option.id)"
          >
            <span class="option-no">{{ option.optionNo }}</span>
            <span class="option-text">{{ option.optionText }}</span>
          </div>
        </div>
      </div>

      <!-- 提交按钮 -->
      <div class="submit-area">
        <n-button
          type="primary"
          size="large"
          :loading="submitting"
          :disabled="!allAnswered"
          @click="handleSubmit"
          class="submit-btn"
        >
          提交问卷
        </n-button>
        <p v-if="!allAnswered" class="hint-text">
          请完成所有题目（已完成 {{ answeredCount }}/{{ questions.length }}）
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { useRouter } from 'vue-router'
import { getQuestionnaireList, submitQuestionnaire, checkSubmitted } from '@/api/questionnaire'

const message = useMessage()
const router = useRouter()

const questions = ref([])
const selectedAnswers = ref({})
const submitted = ref(false)
const submitting = ref(false)
const questionnaireClosed = ref(false)

const answeredCount = computed(() => Object.keys(selectedAnswers.value).length)
const allAnswered = computed(() => 
  questions.value.length > 0 && answeredCount.value === questions.value.length
)

const selectOption = (questionId, optionId) => {
  selectedAnswers.value[questionId] = optionId
}

const fetchQuestions = async () => {
  try {
    const checkRes = await checkSubmitted()
    if (checkRes.data === true) {
      submitted.value = true
      return
    }
    
    const res = await getQuestionnaireList()
    questions.value = res.data || []
  } catch (error) {
    console.error('获取问卷失败：', error)
    // 问卷已截止
    questionnaireClosed.value = true
  }
}

const handleSubmit = async () => {
  if (!allAnswered.value) {
    message.warning('请完成所有题目')
    return
  }
  
  submitting.value = true
  try {
    const answers = Object.keys(selectedAnswers.value).map(questionId => ({
      questionId: Number(questionId),
      optionId: selectedAnswers.value[questionId]
    }))
    
    await submitQuestionnaire({ answers })
    message.success('问卷提交成功！')
    submitted.value = true
    
    setTimeout(() => {
      router.push('/student/home')
    }, 2000)
  } catch (error) {
    console.error('提交问卷失败：', error)
    submitted.value = true
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  fetchQuestions()
})
</script>

<style scoped>
.questionnaire-page {
  min-height: 100vh;
  padding: 24px;
  max-width: 800px;
  margin: 0 auto;
}

.page-header {
  margin-bottom: 32px;
  text-align: center;
}

.page-title {
  font-size: 28px;
  font-weight: 700;
  color: #8b7ec8;
  margin-bottom: 8px;
}

.page-subtitle {
  font-size: 14px;
  color: #64748b;
}

.submitted-card {
  background: white;
  border-radius: 20px;
  padding: 60px 40px;
  text-align: center;
  box-shadow: 0 4px 20px rgba(139, 126, 200, 0.15);
}

.submitted-icon {
  font-size: 60px;
  margin-bottom: 16px;
}

.question-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.question-card {
  background: white;
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 2px 12px rgba(139, 126, 200, 0.1);
}

.question-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}

.question-no {
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  color: white;
  padding: 4px 10px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 700;
}

.question-text {
  font-size: 16px;
  font-weight: 600;
  color: #1f2937;
}

.option-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.option-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  border-radius: 10px;
  border: 2px solid #e5e7eb;
  cursor: pointer;
  transition: all 0.2s ease;
}

.option-item:hover {
  border-color: #c6ccff;
  background: #f3f7ff;
}

.option-item.selected {
  border-color: #8b7ec8;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
}

.option-no {
  font-weight: 700;
  color: #64748b;
}

.option-item.selected .option-no,
.option-item.selected .option-text {
  color: white;
}

.option-text {
  font-size: 14px;
  color: #374151;
}

.submit-area {
  text-align: center;
  padding: 24px;
}

.submit-btn {
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  border: none;
  font-size: 16px;
  font-weight: 600;
  height: 48px;
  padding: 0 40px;
}

.submit-btn:hover {
  background: linear-gradient(135deg, #7a6db5 0%, #b8aee0 100%);
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(198, 204, 255, 0.4);
}

.hint-text {
  margin-top: 12px;
  font-size: 13px;
  color: #64748b;
}
</style>