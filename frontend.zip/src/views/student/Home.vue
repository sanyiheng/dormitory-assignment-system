<template>
  <div class="modern-page">
    <!-- 背景装饰 -->
    <div class="background-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 欢迎卡片 -->
    <div class="welcome-card">
      <div class="welcome-content">
        <h1 class="welcome-title">👋 你好，欢迎回来！</h1>
        <p class="welcome-text">欢迎使用学生宿舍智能分配系统</p>
      </div>
      <div class="welcome-time">
        <div class="time-display">{{ currentTime }}</div>
        <div class="date-display">{{ currentDate }}</div>
      </div>
    </div>

    <!-- 功能导航卡片 -->
    <div class="quick-actions">
      <router-link to="/student/dormitory" class="action-card action-primary">
        <div class="action-icon">🏠</div>
        <div class="action-content">
          <div class="action-title">我的宿舍</div>
          <div class="action-value">{{ homeInfo.dormitoryInfo }}</div>
        </div>
        <div class="action-arrow">→</div>
      </router-link>

      <router-link to="/student/questionnaire" class="action-card action-warning">
        <div class="action-icon">📝</div>
        <div class="action-content">
          <div class="action-title">填写问卷</div>
          <div class="action-value">智能分配</div>
        </div>
        <div class="action-arrow">→</div>
      </router-link>

      <router-link to="/student/assignment" class="action-card action-info">
        <div class="action-icon">🏠</div>
        <div class="action-content">
          <div class="action-title">我的分配</div>
          <div class="action-value">查看宿舍</div>
        </div>
        <div class="action-arrow">→</div>
      </router-link>

      <router-link to="/student/profile" class="action-card action-success">
        <div class="action-icon">👤</div>
        <div class="action-content">
          <div class="action-title">个人信息</div>
          <div class="action-value">查看资料</div>
        </div>
        <div class="action-arrow">→</div>
      </router-link>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { getStudentHomeInfo } from '@/api/student'
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()

const currentTime = ref('')
const currentDate = ref('')
const homeInfo = ref({
  dormitoryInfo: '加载中...',
  pendingRepairCount: 0,
  unreadNoticeCount: 0,
  hasDormitory: false
})

const updateTime = () => {
  const now = new Date()
  currentTime.value = now.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
  currentDate.value = now.toLocaleDateString('zh-CN', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric',
    weekday: 'long'
  })
}

// 获取首页数据
const fetchHomeData = async () => {
  try {
    const userId = userStore.userInfo?.id || 1
    const res = await getStudentHomeInfo(userId)
    homeInfo.value = res.data
  } catch (error) {
    console.error('获取首页数据失败：', error)
    homeInfo.value.dormitoryInfo = '未分配'
  }
}

let timer
onMounted(() => {
  updateTime()
  timer = setInterval(updateTime, 1000)
  fetchHomeData()
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
})
</script>

<style scoped>
/* 现代化页面容器 */
.modern-page {
  position: relative;
  min-height: 100vh;
  padding: 24px;
}

/* 背景装饰 */
.background-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.5;
  animation: float 20s ease-in-out infinite;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #f3f4d6 0%, #c6ccff 100%);
  top: -200px;
  left: -200px;
  animation-delay: 0s;
}

.orb-2 {
  width: 350px;
  height: 350px;
  background: linear-gradient(135deg, #ebecde 0%, #cfd4f7 100%);
  top: 40%;
  right: -180px;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #dde0ea 0%, #c6ccff 100%);
  bottom: -150px;
  left: 30%;
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(50px, -50px) scale(1.1);
  }
  66% {
    transform: translate(-50px, 50px) scale(0.9);
  }
}

/* 欢迎卡片 */
.welcome-card {
  position: relative;
  z-index: 1;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 40px;
  margin-bottom: 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  animation: slideDown 0.6s ease-out;
  border: 1px solid rgba(255, 255, 255, 0.6);
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.welcome-title {
  font-size: 36px;
  font-weight: 700;
  margin: 0 0 8px 0;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.welcome-text {
  font-size: 16px;
  color: #64748b;
  margin: 0;
}

.time-display {
  font-size: 48px;
  font-weight: 700;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  text-align: right;
}

.date-display {
  font-size: 14px;
  color: #64748b;
  text-align: right;
  margin-top: 4px;
}

/* 快捷入口 */
.quick-actions {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 24px;
  animation: slideUp 0.6s ease-out 0.1s both;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.action-card {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 32px 28px;
  display: flex;
  align-items: center;
  gap: 20px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
  cursor: pointer;
  text-decoration: none;
  border: 1px solid rgba(255, 255, 255, 0.6);
  position: relative;
  overflow: hidden;
  min-height: 120px;
}

.action-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, transparent 0%, rgba(255,255,255,0.1) 100%);
  opacity: 0;
  transition: opacity 0.3s ease;
}

.action-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
}

.action-card:hover::before {
  opacity: 1;
}

.action-icon {
  font-size: 40px;
  filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
}

.action-content {
  flex: 1;
}

.action-title {
  font-size: 16px;
  font-weight: 600;
  color: #1f2937;
  margin-bottom: 8px;
}

.action-value {
  font-size: 20px;
  font-weight: 700;
  line-height: 1.2;
}

.action-primary .action-value {
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.action-warning .action-value {
  background: linear-gradient(135deg, #dde0ea 0%, #8b7ec8 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.action-info .action-value {
  background: linear-gradient(135deg, #8b7ec8 0%, #cfd4f7 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.action-success .action-value {
  background: linear-gradient(135deg, #c6ccff 0%, #8b7ec8 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.action-arrow {
  font-size: 24px;
  color: #cbd5e1;
  transition: all 0.3s ease;
}

.action-card:hover .action-arrow {
  color: #8b7ec8;
  transform: translateX(4px);
}

/* 响应式设计 */
@media (max-width: 768px) {
  .modern-page {
    padding: 16px;
  }

  .welcome-card {
    flex-direction: column;
    text-align: center;
    padding: 24px;
  }
  
  .time-display {
    font-size: 36px;
    text-align: center;
  }
  
  .date-display {
    text-align: center;
  }
  
  .quick-actions {
    grid-template-columns: 1fr;
    gap: 16px;
  }

  .action-card {
    padding: 20px;
  }

  .action-icon {
    font-size: 36px;
  }

  .action-title {
    font-size: 15px;
  }

  .action-value {
    font-size: 18px;
  }
}

@media (min-width: 769px) and (max-width: 1024px) {
  .quick-actions {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (min-width: 1025px) {
  .quick-actions {
    grid-template-columns: repeat(4, 1fr);
  }
}
</style>