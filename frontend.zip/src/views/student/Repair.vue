<template>
  <div class="modern-page">
    <!-- 动态背景装饰 -->
    <div class="background-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 页面标题 -->
    <div class="page-header">
      <h1 class="page-title">🔧 报修申请</h1>
      <p class="page-subtitle">快速提交报修，我们会尽快处理</p>
    </div>

    <!-- 提交按钮 -->
    <div class="action-section">
      <button class="submit-btn" @click="showModal = true">
        <span class="btn-icon">✨</span>
        <span class="btn-text">提交新报修</span>
      </button>
    </div>

    <!-- 报修记录列表 -->
    <div class="repair-list">
      <div v-if="loading" class="loading-state">
        <div class="loading-spinner"></div>
        <p>加载中...</p>
      </div>
      
      <div v-else-if="tableData.length === 0" class="empty-state">
        <div class="empty-icon">📝</div>
        <p class="empty-text">暂无报修记录</p>
        <p class="empty-hint">点击上方按钮提交您的第一个报修申请</p>
      </div>

      <div v-else class="repair-cards">
        <div 
          v-for="item in tableData" 
          :key="item.id" 
          class="repair-card"
        >
          <div class="card-header">
            <div class="card-title">
              <span class="title-icon">🔨</span>
              <span class="title-text">{{ item.title }}</span>
            </div>
            <div class="card-status" :class="getStatusClass(item.statusText)">
              {{ item.statusText }}
            </div>
          </div>
          <div class="card-content">
            <div class="card-info">
              <span class="info-label">📅 提交时间</span>
              <span class="info-value">{{ item.createTime }}</span>
            </div>
            <div v-if="item.handler" class="card-info">
              <span class="info-label">👤 处理人</span>
              <span class="info-value">{{ item.handler }}</span>
            </div>
            <div v-if="item.remark" class="card-info full-width">
              <span class="info-label">💬 备注</span>
              <span class="info-value">{{ item.remark }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 提交报修弹窗 -->
    <n-modal 
      v-model:show="showModal" 
      preset="dialog" 
      title="✨ 提交报修申请"
      :show-icon="false"
      class="repair-modal"
    >
      <n-form :model="formData" ref="formRef" :rules="rules">
        <n-form-item label="📝 报修标题" path="title">
          <n-input 
            v-model:value="formData.title"
            placeholder="请简要描述问题（如：水龙头漏水）" 
            maxlength="50"
            show-count
          />
        </n-form-item>
        
        <n-form-item label="🔧 报修类型" path="repairType">
          <n-select
            v-model:value="formData.repairType"
            :options="repairTypeOptions"
            placeholder="请选择报修类型"
          />
        </n-form-item>
        
        <n-form-item label="👷 维修人员" path="handlerId">
          <n-select
            v-model:value="formData.handlerId"
            :options="staffOptions"
            placeholder="请选择维修人员（可选）"
            clearable
          />
        </n-form-item>
        
        <n-form-item label="📋 问题描述" path="description">
          <n-input 
            v-model:value="formData.description"
            type="textarea" 
            placeholder="请详细描述具体问题，便于我们快速定位和处理"
            :rows="5"
            maxlength="500"
            show-count
          />
        </n-form-item>
      </n-form>
      <template #action>
        <div class="modal-actions">
          <button class="modal-btn cancel-btn" @click="showModal = false">
            取消
          </button>
          <button class="modal-btn submit-btn-primary" @click="handleSubmit">
            <span class="btn-icon">🚀</span>
            <span>提交申请</span>
          </button>
        </div>
      </template>
    </n-modal>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import { useUserStore } from '@/stores/user'
import { getRepairPage, submitRepair, getMaintenanceStaffList } from '@/api/repair'

const message = useMessage()
const userStore = useUserStore()

const loading = ref(false)
const showModal = ref(false)
const formRef = ref(null)
const formData = ref({
  title: '',
  description: '',
  repairType: null,
  handlerId: null,
  dormitoryId: null
})

const rules = {
  title: {
    required: true,
    message: '请输入报修标题',
    trigger: 'blur'
  },
  repairType: {
    required: true,
    message: '请选择报修类型',
    trigger: 'change'
  },
  description: {
    required: true,
    message: '请描述具体问题',
    trigger: 'blur'
  }
}

// 报修类型选项
const repairTypeOptions = [
  { label: '💧 水电维修', value: 'WATER' },
  { label: '🪑 家具维修', value: 'FURNITURE' },
  { label: '🌐 网络维修', value: 'NETWORK' },
  { label: '📦 其他', value: 'OTHER' }
]

// 维修人员选项
const staffOptions = ref([])

const tableData = ref([])

// 获取报修列表
const fetchRepairList = async () => {
  loading.value = true
  try {
    const res = await getRepairPage({
      pageNum: 1,
      pageSize: 100
      // 不需要传 keyword，后端会根据当前登录用户的角色自动过滤
      // 学生只能看到自己的报修，管理员和维修人员可以看到所有
    })
    tableData.value = res.data.records || []
  } catch (error) {
    console.error('获取报修列表失败：', error)
    if (!error.showMessage) {
      message.error('获取报修列表失败')
    }
  } finally {
    loading.value = false
  }
}

const getStatusClass = (status) => {
  const statusMap = {
    '待审核': 'status-pending',
    '已接受': 'status-processing',
    '处理中': 'status-processing',
    '已完成': 'status-completed',
    '已拒绝': 'status-rejected'
  }
  return statusMap[status] || 'status-pending'
}

const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
    
    const userId = userStore.userInfo?.id || 1
    
    // 检查是否已分配宿舍
    if (!formData.value.dormitoryId) {
      message.error('您还未分配宿舍，无法提交报修申请')
      return
    }
    
    const submitData = {
      studentId: userId,
      dormitoryId: formData.value.dormitoryId,
      title: formData.value.title,
      description: formData.value.description,
      repairType: formData.value.repairType,
      priority: 1  // 默认为中等优先级
    }
    
    // 如果选择了维修人员，添加到提交数据
    if (formData.value.handlerId) {
      submitData.handlerId = formData.value.handlerId
    }
    
    await submitRepair(submitData)
    
    message.success('报修申请提交成功')
    showModal.value = false
    // 重置表单，保留dormitoryId
    const currentDormId = formData.value.dormitoryId
    formData.value = { 
      title: '', 
      description: '',
      repairType: null,
      handlerId: null,
      dormitoryId: currentDormId
    }
    
    // 刷新列表
    await fetchRepairList()
  } catch (error) {
    console.error('提交失败:', error)
    message.error(error.response?.data?.msg || '提交失败')
  }
}

// 获取学生宿舍信息
const fetchStudentDorm = async () => {
  try {
    const userId = userStore.userInfo?.id || 1
    const { getStudentDormInfo } = await import('@/api/student')
    const res = await getStudentDormInfo(userId)
    if (res.data && res.data.dormitoryId) {
      formData.value.dormitoryId = res.data.dormitoryId
    }
  } catch (error) {
    console.error('获取宿舍信息失败：', error)
  }
}

// 获取维修人员列表
const fetchMaintenanceStaff = async () => {
  try {
    const res = await getMaintenanceStaffList()
    staffOptions.value = res.data.map(staff => ({
      label: `${staff.name} - ${staff.specialty || '综合维修'}`,
      value: staff.id
    }))
  } catch (error) {
    console.error('获取维修人员列表失败：', error)
    if (!error.showMessage) {
      message.error('获取维修人员列表失败')
    }
  }
}

onMounted(() => {
  fetchRepairList()
  fetchStudentDorm()
  fetchMaintenanceStaff()
})
</script>

<style scoped>
.modern-page {
  position: relative;
  min-height: 100vh;
  padding: 2rem;
  overflow: hidden;
}

/* 动态背景装饰 */
.background-decoration {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.3;
  animation: float 20s infinite ease-in-out;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
  top: -10%;
  left: -5%;
  animation-delay: 0s;
}

.orb-2 {
  width: 350px;
  height: 350px;
  background: linear-gradient(135deg, #ffa500 0%, #ffb347 100%);
  top: 50%;
  right: -5%;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #ff8c42 0%, #ffd700 100%);
  bottom: -5%;
  left: 30%;
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  25% { transform: translate(30px, -30px) scale(1.05); }
  50% { transform: translate(-20px, 20px) scale(0.95); }
  75% { transform: translate(20px, 10px) scale(1.02); }
}

/* 页面标题 */
.page-header {
  position: relative;
  z-index: 1;
  margin-bottom: 2rem;
  animation: slideDown 0.6s ease-out;
}

.page-title {
  font-size: 2.5rem;
  font-weight: 800;
  background: linear-gradient(135deg, #ff6b35 0%, #f7931e 50%, #ffa500 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 0.5rem;
}

.page-subtitle {
  font-size: 1rem;
  color: #666;
  margin: 0;
}

/* 提交按钮区域 */
.action-section {
  position: relative;
  z-index: 1;
  margin-bottom: 2rem;
  animation: slideDown 0.6s ease-out 0.1s both;
}

.submit-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 1rem 2rem;
  font-size: 1.1rem;
  font-weight: 600;
  color: white;
  background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
  border: none;
  border-radius: 16px;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(255, 107, 53, 0.3);
}

.submit-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(255, 107, 53, 0.4);
}

.submit-btn:active {
  transform: translateY(0);
}

.btn-icon {
  font-size: 1.3rem;
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
}

/* 报修列表 */
.repair-list {
  position: relative;
  z-index: 1;
  animation: slideUp 0.6s ease-out 0.2s both;
}

.loading-state {
  text-align: center;
  padding: 4rem 2rem;
  color: #666;
}

.loading-spinner {
  width: 50px;
  height: 50px;
  margin: 0 auto 1rem;
  border: 4px solid rgba(255, 107, 53, 0.2);
  border-top-color: #ff6b35;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.empty-state {
  text-align: center;
  padding: 4rem 2rem;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  border: 1px solid rgba(255, 255, 255, 0.6);
}

.empty-icon {
  font-size: 4rem;
  margin-bottom: 1rem;
  opacity: 0.5;
}

.empty-text {
  font-size: 1.2rem;
  color: #666;
  margin-bottom: 0.5rem;
}

.empty-hint {
  font-size: 0.9rem;
  color: #999;
}

/* 报修卡片 */
.repair-cards {
  display: grid;
  gap: 1.5rem;
}

.repair-card {
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  padding: 1.5rem;
  border: 1px solid rgba(255, 255, 255, 0.6);
  transition: all 0.3s ease;
  animation: slideUp 0.6s ease-out both;
}

.repair-card:nth-child(1) { animation-delay: 0.2s; }
.repair-card:nth-child(2) { animation-delay: 0.3s; }
.repair-card:nth-child(3) { animation-delay: 0.4s; }

.repair-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(255, 107, 53, 0.2);
  border-color: rgba(255, 107, 53, 0.3);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}

.card-title {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1.2rem;
  font-weight: 600;
  color: #333;
}

.title-icon {
  font-size: 1.5rem;
}

.card-status {
  padding: 0.4rem 1rem;
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 600;
  white-space: nowrap;
}

.status-pending {
  background: linear-gradient(135deg, #ffa500 0%, #ffb347 100%);
  color: white;
}

.status-processing {
  background: linear-gradient(135deg, #4a90e2 0%, #5ba3f5 100%);
  color: white;
}

.status-completed {
  background: linear-gradient(135deg, #52c41a 0%, #73d13d 100%);
  color: white;
}

.status-rejected {
  background: linear-gradient(135deg, #ff4d4f 0%, #ff7875 100%);
  color: white;
}

.card-content {
  display: grid;
  gap: 0.8rem;
}

.card-info {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.card-info.full-width {
  flex-direction: column;
  align-items: flex-start;
}

.info-label {
  font-size: 0.9rem;
  color: #666;
  white-space: nowrap;
}

.info-value {
  font-size: 0.95rem;
  color: #333;
  font-weight: 500;
}

/* 弹窗样式 */
:deep(.repair-modal .n-dialog) {
  border-radius: 24px;
  overflow: hidden;
}

:deep(.repair-modal .n-dialog__title) {
  font-size: 1.5rem;
  font-weight: 700;
  background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.modal-actions {
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 1rem;
}

.modal-btn {
  padding: 0.75rem 1.5rem;
  border-radius: 12px;
  font-size: 1rem;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: all 0.3s ease;
  display: inline-flex;
  align-items: center;
  gap: 0.3rem;
}

.cancel-btn {
  background: #f5f5f5;
  color: #666;
}

.cancel-btn:hover {
  background: #e8e8e8;
}

.submit-btn-primary {
  background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
  color: white;
  box-shadow: 0 4px 15px rgba(255, 107, 53, 0.3);
}

.submit-btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(255, 107, 53, 0.4);
}

/* 动画 */
@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 响应式设计 */
@media (max-width: 768px) {
  .modern-page {
    padding: 1rem;
  }

  .page-title {
    font-size: 2rem;
  }

  .submit-btn {
    width: 100%;
    justify-content: center;
  }

  .card-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }

  .modal-actions {
    flex-direction: column;
  }

  .modal-btn {
    width: 100%;
    justify-content: center;
  }
}
</style>
