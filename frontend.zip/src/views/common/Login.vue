<template>
  <div class="login-container">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 登录卡片 -->
    <div class="login-card">
      <!-- 左侧装饰区域 -->
      <div class="login-visual">
        <!-- 漂浮圆点装饰 -->
        <div class="floating-dots">
          <span class="dot dot-1"></span>
          <span class="dot dot-2"></span>
          <span class="dot dot-3"></span>
          <span class="dot dot-4"></span>
          <span class="dot dot-5"></span>
        </div>

        <div class="visual-content">
          <!-- Logo -->
          <div class="logo-wrapper">
            <div class="logo-badge">
              <div class="logo-house">
                <div class="logo-roof"></div>
                <div class="logo-body">
                  <span class="logo-door"></span>
                  <span class="logo-window"></span>
                </div>
              </div>
            </div>
            <h1 class="logo-title">不期而宿</h1>
            <p class="logo-subtitle">宿舍智能分配系统</p>
          </div>
        </div>
      </div>

      <!-- 右侧登录表单 -->
      <div class="login-form-area">
        <div class="form-header">
          <h3 class="form-title">欢迎登录</h3>
          <p class="form-subtitle">请选择您的身份进行登录</p>
        </div>

        <!-- 角色选择 -->
        <div class="role-selector">
          <div 
            v-for="role in roles" 
            :key="role.value"
            class="role-item"
            :class="{ active: loginForm.userType === role.value }"
            @click="selectRole(role.value)"
          >
            <div class="role-icon">{{ role.icon }}</div>
            <div class="role-name">{{ role.label }}</div>
          </div>
        </div>

        <!-- 登录表单 -->
        <n-form
          ref="formRef"
          :model="loginForm"
          :rules="rules"
          size="large"
        >
          <n-form-item path="username">
            <n-input
              v-model:value="loginForm.username"
              :placeholder="currentRolePlaceholder"
              clearable
              @keyup.enter="handleLogin"
            >
              <template #prefix>
                <n-icon :component="PersonOutline" />
              </template>
            </n-input>
          </n-form-item>
          
          <n-form-item path="password">
            <n-input
              v-model:value="loginForm.password"
              type="password"
              show-password-on="click"
              placeholder="请输入密码"
              @keyup.enter="handleLogin"
            >
              <template #prefix>
                <n-icon :component="LockClosedOutline" />
              </template>
            </n-input>
          </n-form-item>
          
          <n-button
            type="primary"
            size="large"
            block
            :loading="loading"
            @click="handleLogin"
            class="login-btn"
          >
            登录
          </n-button>
        </n-form>

       <!-- 提示信息 -->
        <div class="form-footer">
          <span class="footer-text">学生请使用身份证号登录，密码为身份证后六位</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useMessage } from 'naive-ui'
import { PersonOutline, LockClosedOutline } from '@vicons/ionicons5'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const message = useMessage()
const userStore = useUserStore()

const formRef = ref(null)
const loading = ref(false)

const roles = [
  { value: 'STUDENT', label: '学生', icon: '🎓' },
  { value: 'ADMIN', label: '管理员', icon: '👨‍💼' },
]

const loginForm = reactive({
  username: '',
  password: '',
  userType: 'STUDENT'
})

const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' }
  ]
}

const currentRolePlaceholder = computed(() => {
  const placeholders = {
    'STUDENT': '请输入身份证号',
    'ADMIN': '请输入管理员账号',
  }
  return placeholders[loginForm.userType]
})

const selectRole = (roleValue) => {
  loginForm.userType = roleValue
  loginForm.username = ''
  loginForm.password = ''
}

const handleLogin = async () => {
  try {
    await formRef.value?.validate()
    loading.value = true
    
    const data = await userStore.login(loginForm)
    message.success('登录成功')
    
    // 根据用户类型跳转不同页面
    if (data.userType === 'ADMIN') {
      router.push('/admin/dashboard')
    } else {
      router.push('/student/home')
    }
  } catch (error) {
    console.error('登录失败：', error)
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-container {
  position: relative;
  width: 100%;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(135deg, #f3f4d6 0%, #ebecde 30%, #dde0ea 60%, #c6ccff 100%);
  overflow: hidden;
}

/* 背景装饰 */
.bg-decoration {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  overflow: hidden;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.5;
  animation: float 20s infinite ease-in-out;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #f3f4d6 0%, #c6ccff 100%);
  top: -100px;
  left: -100px;
  animation-delay: 0s;
}

.orb-2 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #ebecde 0%, #cfd4f7 100%);
  bottom: -150px;
  right: -150px;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #dde0ea 0%, #c6ccff 100%);
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -50px) scale(1.1);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.9);
  }
}

/* 登录卡片 */
.login-card {
  position: relative;
  z-index: 1;
  display: flex;
  width: 950px;
  min-height: 600px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  box-shadow: 0 20px 60px rgba(139, 126, 200, 0.3);
  overflow: hidden;
}

/* 左侧装饰区域 */
.login-visual {
  flex: 1;
  background: linear-gradient(135deg, #f3f4d6 0%, #ebecde 30%, #c6ccff 100%);
  padding: 60px 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
}

.login-visual::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: url('data:image/svg+xml,<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(139,126,200,0.1)" stroke-width="0.5"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
  opacity: 0.3;
}

.visual-content {
  position: relative;
  z-index: 1;
  text-align: center;
}

/* 漂浮圆点装饰 */
.floating-dots {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
}

.dot {
  position: absolute;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.6);
  animation: dotFloat 6s ease-in-out infinite;
}

.dot-1 {
  width: 12px;
  height: 12px;
  top: 15%;
  left: 20%;
}

.dot-2 {
  width: 8px;
  height: 8px;
  top: 30%;
  right: 25%;
  animation-delay: 1s;
}

.dot-3 {
  width: 10px;
  height: 10px;
  bottom: 20%;
  left: 30%;
  animation-delay: 2s;
}

.dot-4 {
  width: 6px;
  height: 6px;
  top: 50%;
  left: 10%;
  animation-delay: 3s;
}

.dot-5 {
  width: 14px;
  height: 14px;
  bottom: 30%;
  right: 15%;
  animation-delay: 4s;
}

@keyframes dotFloat {
  0%, 100% {
    transform: translateY(0) scale(1);
    opacity: 0.5;
  }
  50% {
    transform: translateY(-20px) scale(1.3);
    opacity: 1;
  }
}

/* Logo */
.logo-wrapper {
  text-align: center;
}

.logo-badge {
  width: 120px;
  height: 120px;
  margin: 0 auto 20px;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8px 32px rgba(139, 126, 200, 0.25);
  border: 3px solid rgba(198, 204, 255, 0.6);
  position: relative;
}

.logo-house {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.logo-roof {
  width: 0;
  height: 0;
  border-left: 28px solid transparent;
  border-right: 28px solid transparent;
  border-bottom: 22px solid #8b7ec8;
  margin-bottom: -4px;
}

.logo-body {
  width: 44px;
  height: 36px;
  background: #c6ccff;
  border-radius: 0 0 6px 6px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  position: relative;
}

.logo-door {
  width: 10px;
  height: 14px;
  background: #8b7ec8;
  border-radius: 2px 2px 0 0;
}

.logo-window {
  width: 8px;
  height: 8px;
  background: white;
  border-radius: 1px;
  position: absolute;
  top: 6px;
  right: 8px;
}

.logo-title {
  font-size: 28px;
  font-weight: 700;
  color: #8b7ec8;
  letter-spacing: 4px;
  margin-bottom: 6px;
}

.logo-subtitle {
  font-size: 13px;
  color: #8b7ec8;
  opacity: 0.7;
  letter-spacing: 1px;
}

/* 右侧表单区域 */
.login-form-area {
  flex: 1;
  padding: 60px 50px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.form-header {
  margin-bottom: 32px;
  text-align: center;
}

.form-title {
  font-size: 32px;
  font-weight: 700;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 8px;
}

.form-subtitle {
  font-size: 14px;
  color: #666;
}

/* 角色选择 */
.role-selector {
  display: flex;
  gap: 12px;
  margin-bottom: 28px;
  justify-content: center;
}

.role-item {
  flex: 1;
  padding: 20px 12px;
  background: #f5f7fa;
  border-radius: 12px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
  border: 2px solid transparent;
}

.role-item:hover {
  background: #e8eaf6;
  transform: translateY(-2px);
}

.role-item.active {
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  border-color: #8b7ec8;
  box-shadow: 0 4px 16px rgba(198, 204, 255, 0.3);
}

.role-icon {
  font-size: 36px;
  margin-bottom: 8px;
}

.role-item.active .role-icon {
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
}

.role-name {
  font-size: 14px;
  font-weight: 600;
  color: #333;
}

.role-item.active .role-name {
  color: white;
}

/* 登录按钮 */
.login-btn {
  margin-top: 8px;
  background: linear-gradient(135deg, #8b7ec8 0%, #c6ccff 100%);
  border: none;
  font-size: 16px;
  font-weight: 600;
  height: 48px;
}

.login-btn:hover {
  background: linear-gradient(135deg, #7a6db5 0%, #b8aee0 100%);
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(198, 204, 255, 0.4);
}

/* 表单底部 */
.form-footer {
  margin-top: 24px;
  text-align: center;
}

.footer-text {
  color: #999;
  font-size: 14px;
  margin-right: 8px;
}

/* 响应式 */
@media (max-width: 1024px) {
  .login-card {
    flex-direction: column;
    width: 90%;
    max-width: 500px;
  }

  .login-visual {
    padding: 40px 30px;
  }

  .visual-title {
    font-size: 24px;
  }

  .login-form-area {
    padding: 40px 30px;
  }
}
</style>