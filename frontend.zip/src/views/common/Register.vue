<template>
  <div class="register-container">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>

    <!-- 注册卡片 -->
    <div class="register-card">
      <div class="card-header">
        <h2 class="register-title">用户注册</h2>
        <p class="register-subtitle">创建您的账号，开始使用宿舍管理系统</p>
      </div>

      <!-- 角色选择 -->
      <div class="role-selector">
        <div 
          v-for="role in roles" 
          :key="role.value"
          class="role-item"
          :class="{ active: registerForm.role === role.value }"
          @click="selectRole(role.value)"
        >
          <div class="role-icon">{{ role.icon }}</div>
          <div class="role-name">{{ role.label }}</div>
        </div>
      </div>

      <!-- 注册表单 -->
      <n-form
        ref="formRef"
        :model="registerForm"
        :rules="rules"
        size="large"
      >
        <n-form-item path="username" label="用户名">
          <n-input
            v-model:value="registerForm.username"
            :placeholder="currentRolePlaceholder"
            clearable
            @keyup.enter="handleRegister"
          >
            <template #prefix>
              <n-icon :component="PersonOutline" />
            </template>
          </n-input>
        </n-form-item>

        <n-form-item path="phone" label="手机号">
          <n-input
            v-model:value="registerForm.phone"
            placeholder="请输入手机号"
            clearable
            @keyup.enter="handleRegister"
          >
            <template #prefix>
              <n-icon :component="PhonePortraitOutline" />
            </template>
          </n-input>
        </n-form-item>
        
        <n-form-item path="password" label="密码">
          <n-input
            v-model:value="registerForm.password"
            type="password"
            show-password-on="click"
            placeholder="请输入密码（6-20位）"
            @keyup.enter="handleRegister"
          >
            <template #prefix>
              <n-icon :component="LockClosedOutline" />
            </template>
          </n-input>
        </n-form-item>

        <n-form-item path="confirmPassword" label="确认密码">
          <n-input
            v-model:value="registerForm.confirmPassword"
            type="password"
            show-password-on="click"
            placeholder="请再次输入密码"
            @keyup.enter="handleRegister"
          >
            <template #prefix>
              <n-icon :component="LockClosedOutline" />
            </template>
          </n-input>
        </n-form-item>
        
        <n-button
          type="primary"
          size="large"
          block
          :loading="loading"
          @click="handleRegister"
          class="register-btn"
        >
          注册
        </n-button>
      </n-form>

      <!-- 返回登录 -->
      <div class="form-footer">
        <span class="footer-text">已有账号？</span>
        <router-link to="/login" class="login-link">立即登录</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useMessage } from 'naive-ui'
import { PersonOutline, LockClosedOutline, PhonePortraitOutline } from '@vicons/ionicons5'
import { register } from '@/api/auth'

const router = useRouter()
const message = useMessage()

const formRef = ref(null)
const loading = ref(false)

const roles = [
  { value: 'STUDENT', label: '学生', icon: '🎓' },
  { value: 'STAFF', label: '维修人员', icon: '🔧' }
]

const registerForm = reactive({
  username: '',
  phone: '',
  password: '',
  confirmPassword: '',
  role: 'STUDENT'
})

const validatePasswordMatch = (rule, value) => {
  if (value !== registerForm.password) {
    return new Error('两次密码输入不一致')
  }
  return true
}

const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, max: 20, message: '用户名长度为3-20个字符', trigger: 'blur' }
  ],
  phone: [
    { required: true, message: '请输入手机号', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度为6-20个字符', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, message: '请再次输入密码', trigger: 'blur' },
    { validator: validatePasswordMatch, trigger: 'blur' }
  ]
}

const currentRolePlaceholder = computed(() => {
  const placeholders = {
    'STUDENT': '请输入学号作为用户名',
    'STAFF': '请输入用户名（3-20个字符）'
  }
  return placeholders[registerForm.role]
})

const selectRole = (roleValue) => {
  registerForm.role = roleValue
}

const handleRegister = async () => {
  try {
    await formRef.value?.validate()
    loading.value = true
    
    await register(registerForm)
    message.success('注册成功，请登录')
    
    // 跳转到登录页面
    setTimeout(() => {
      router.push('/login')
    }, 1000)
  } catch (error) {
    // 错误提示已在request拦截器中处理
    console.error('注册失败：', error)
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.register-container {
  position: relative;
  width: 100%;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  overflow: hidden;
}

/* 背景装饰 */
.bg-decoration {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  overflow: hidden;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.5;
  animation: float 20s infinite ease-in-out;
}

.orb-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
  top: -100px;
  left: -100px;
  animation-delay: 0s;
}

.orb-2 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
  bottom: -150px;
  right: -150px;
  animation-delay: 7s;
}

.orb-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  animation-delay: 14s;
}

@keyframes float {
  0%, 100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -50px) scale(1.1);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.9);
  }
}

/* 注册卡片 */
.register-card {
  position: relative;
  z-index: 1;
  width: 500px;
  padding: 48px 50px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

.card-header {
  text-align: center;
  margin-bottom: 32px;
}

.register-title {
  font-size: 32px;
  font-weight: 700;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 8px;
}

.register-subtitle {
  font-size: 14px;
  color: #666;
}

/* 角色选择 */
.role-selector {
  display: flex;
  gap: 16px;
  margin-bottom: 28px;
}

.role-item {
  flex: 1;
  padding: 20px 12px;
  background: #f5f7fa;
  border-radius: 12px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
  border: 2px solid transparent;
}

.role-item:hover {
  background: #e8eaf6;
  transform: translateY(-2px);
}

.role-item.active {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-color: #667eea;
  box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
}

.role-icon {
  font-size: 36px;
  margin-bottom: 8px;
}

.role-item.active .role-icon {
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
}

.role-name {
  font-size: 14px;
  font-weight: 600;
  color: #333;
}

.role-item.active .role-name {
  color: white;
}

/* 注册按钮 */
.register-btn {
  margin-top: 8px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  font-size: 16px;
  font-weight: 600;
  height: 48px;
}

.register-btn:hover {
  background: linear-gradient(135deg, #5568d3 0%, #6a3d8f 100%);
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(102, 126, 234, 0.4);
}

/* 表单底部 */
.form-footer {
  margin-top: 24px;
  text-align: center;
}

.footer-text {
  color: #999;
  font-size: 14px;
  margin-right: 8px;
}

.login-link {
  color: #667eea;
  font-size: 14px;
  font-weight: 600;
  text-decoration: none;
  transition: all 0.3s ease;
}

.login-link:hover {
  color: #764ba2;
  text-decoration: underline;
}

/* 响应式 */
@media (max-width: 768px) {
  .register-card {
    width: 90%;
    max-width: 400px;
    padding: 40px 30px;
  }
}
</style>
