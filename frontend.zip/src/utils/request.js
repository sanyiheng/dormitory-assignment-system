import axios from 'axios'
import { useUserStore } from '@/stores/user'

// 创建axios实例
const request = axios.create({
  baseURL: '/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求拦截器
request.interceptors.request.use(
  config => {
    const userStore = useUserStore()
    // 添加Token
    if (userStore.token) {
      config.headers['Authorization'] = `Bearer ${userStore.token}`
    }
    return config
  },
  error => {
    console.error('请求错误：', error)
    return Promise.reject(error)
  }
)

// 响应拦截器
request.interceptors.response.use(
  response => {
    const res = response.data
    
    // 如果返回的状态码为200，说明接口请求成功
    if (res.code === 200) {
      return res
    } else {
      // 其他状态码都当作错误，显示后端返回的具体错误信息
      const errorMsg = res.msg || res.message || '请求失败'
      
      // 401: 未登录或登录过期
      if (res.code === 401) {
        window.$message?.error(errorMsg)
        const userStore = useUserStore()
        userStore.logout()
        setTimeout(() => {
          window.location.href = '/login'
        }, 1000)
      } else {
        // 其他业务错误，统一在这里显示错误消息
        window.$message?.error(errorMsg)
      }
      
      // 创建一个错误对象，并附加showMessage标记，表示已经显示过消息了
      const error = new Error(errorMsg)
      error.showMessage = true
      return Promise.reject(error)
    }
  },
  error => {
    console.error('响应错误：', error)
    
    if (error.response) {
      const status = error.response.status
      const data = error.response.data
      
      // 优先显示后端返回的错误信息
      let errorMsg = data?.msg || data?.message || ''
      
      // 如果后端没有返回具体错误信息，使用默认提示
      if (!errorMsg) {
        switch (status) {
          case 401:
            errorMsg = '未登录或登录已过期'
            const userStore = useUserStore()
            userStore.logout()
            setTimeout(() => {
              window.location.href = '/login'
            }, 1000)
            break
          case 403:
            errorMsg = '权限不足'
            break
          case 404:
            errorMsg = '请求的资源不存在'
            break
          case 500:
            errorMsg = '服务器内部错误'
            break
          default:
            errorMsg = '网络请求失败'
        }
      }
      
      window.$message?.error(errorMsg)
    } else if (error.request) {
      // 请求已发出，但没有收到响应
      window.$message?.error('服务器无响应，请检查网络连接')
    } else {
      // 发送请求时出错
      window.$message?.error(error.message || '请求发送失败')
    }
    
    return Promise.reject(error)
  }
)

export default request


