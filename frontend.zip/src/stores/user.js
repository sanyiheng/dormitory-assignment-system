import { defineStore } from 'pinia'
import { ref } from 'vue'
import { login as loginApi, logout as logoutApi } from '@/api/auth'

export const useUserStore = defineStore('user', () => {
  // 状态
  const token = ref(localStorage.getItem('token') || '')
  const userInfo = ref(JSON.parse(localStorage.getItem('userInfo') || '{}'))
  const userType = ref(localStorage.getItem('userType') || '')
  
  // 登录
  const login = async (loginForm) => {
    try {
      const res = await loginApi(loginForm)
      const data = res.data
      
      token.value = data.token
      userInfo.value = {
        userId: data.userId,
        username: data.username,
        realName: data.realName,
        role: data.role,
        avatar: data.avatar
      }
      userType.value = data.userType
      
      // 保存到本地存储
      localStorage.setItem('token', data.token)
      localStorage.setItem('userInfo', JSON.stringify(userInfo.value))
      localStorage.setItem('userType', data.userType)
      
      return data
    } catch (error) {
      throw error
    }
  }
  
  // 登出
  const logout = async () => {
    try {
      await logoutApi()
    } catch (error) {
      console.error('登出失败：', error)
    } finally {
      // 清除本地数据
      token.value = ''
      userInfo.value = {}
      userType.value = ''
      localStorage.removeItem('token')
      localStorage.removeItem('userInfo')
      localStorage.removeItem('userType')
    }
  }
  
  // 判断是否登录
  const isLogin = () => {
    return !!token.value
  }
  
  // 判断是否是管理员
  const isAdmin = () => {
    return userType.value === 'ADMIN'
  }
  
  // 判断是否是学生
  const isStudent = () => {
    return userType.value === 'STUDENT'
  }
  
  return {
    token,
    userInfo,
    userType,
    login,
    logout,
    isLogin,
    isAdmin,
    isStudent
  }
})




